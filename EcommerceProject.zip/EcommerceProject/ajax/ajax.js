//Sign In Data
$('#sign_in').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            $('#sign_in')[0].reset();
            $('#sign_alert').html(data);
            console.log(data);
        }
    })
})

//Register User register

$('#register_data').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            $('#register_data')[0].reset();
            $('#register_alert').html(data);
            console.log(data);
        }
    })
})

//Get Image 


//Update Profile

$('#update_profile').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
          $('#profile_update').html(data);
        }
    })
})



function GetProfileImg(){
    var email = $('#emailid').val();
    console.log(email);
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            GetProfileImgData : 'GetProfileData',
            UserEmail : email,
        },
        success : function(data,status){
          $('#getImg').html(data);
        }
    })
}

GetProfileImg();

$('#UpdateUserPorfileImg').on('submit',function(e){

    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            GetProfileImg();

        }
    })
})


//ShowCart

function showcart(){
    var show_cart = "show_cart";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            show_cart : show_cart,
        },
        success:function(data){
          $('#showcart').html(data);
        }
    })
}

showcart();

//showCarttable

function showcart_table(){
    var show_cart_table = "show_cart_table";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            show_cart_table : show_cart_table,
        },
        success:function(data){
          $('#get_show_cart').html(data);
        }
    })
}

showcart_table();


//showCartcheckout

function showcart__checkout(){
    var show_cart_checkout = "show_cart_checkout";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            show_cart_checkout : show_cart_checkout,
        },
        success:function(data){
          $('#checkout_cart').append(data);
        }
    })
}

showcart__checkout();

//SubTotalItemCount

function subtotal(){
    var subtotalitem = "subtotalitem";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            subtotalitem : subtotalitem,
        },
        success:function(data){
          $('.count').html(data);
        }
    })
}

subtotal();

//TotalMoneyAmount

function totalamount(){
    var totalamount = "total_amount";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            totalamount : totalamount,
        },
        success:function(data){
          $('.total_amount').html(data);
        }
    })
}

totalamount();

//AddToCrat

function addToCart(product_id){
    console.log("ravish");
   $.ajax({
       url : 'phpfunction.php',
       type : 'POST',
       data : {
           product_id : product_id,
       },
       success:function(data){
           console.log(data);
           showcart();
           subtotal();
           totalamount();
          showcart_table();

       }
   })
}



$('#addtocart').on('submit',function(e){
    console.log("ravish");
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            console.log(data);
            showcart();
           subtotal();
           totalamount();
          showcart_table();
        }
    })
})

//form_submit

function addToCart(product_id){
    console.log("ravish");
   $.ajax({
       url : 'phpfunction.php',
       type : 'POST',
       data : {
           product_id : product_id,
       },
       success:function(data){
           console.log(data);
           showcart();
           subtotal();
           totalamount();
          showcart_table();

       }
   })
}

//deleteCartItem


function deletecartitem(cartiddelete){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            cartiddelete : cartiddelete,
        },
        success:function(data){
            showcart();
            subtotal();
            totalamount();
           showcart_table();

        }
    })
}


//updatecart_Qnantity

function update_quantity_plus(update_id,update_quantity){
 update_quantity++;

  $.ajax({
    url : 'phpfunction.php',
    type : 'POST',
    data : {
        update_id :update_id,
        update_quantity : update_quantity,
    },
    success:function(data){
        showcart();
        subtotal();
        totalamount();
        showcart_table();

    }
  })
}

//update_quantity-minus('.$row['id'].')

function update_quantity_minus(update_id,update_quantity){
    update_quantity--;
   
     $.ajax({
       url : 'phpfunction.php',
       type : 'POST',
       data : {
           update_id :update_id,
           update_quantity : update_quantity,
       },
       success:function(data){
           showcart();
           subtotal();
           totalamount();
           showcart_table();
   
       }
     })
   }



//Checkout



//Update Order

$('#update_order').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            $('#update_order_success').html(data);
            console.log(data);
        }
    })
})

// ************** getOrder
function getOrderData(){
    var order_data = "order_date";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
           order_data : order_data,
        },
        success:function(data,status){
            $('#get_order_data').html(data);
        }
    })
}

getOrderData();

// Cancle Order

function cancel_order(cancle_order_id){
    window.alert("Do you want to cancel order");
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            cancle_order_id : cancle_order_id,
        },
        success:function(data,status){
            getOrderData();
            $('#cancel_order').html(data);
        }
    })
}


// ************************* searchproduct ************************

$('#searchproduct').on('keyup',function(){
    console.log("ravish")
    var searchproduct = $('#searchproduct').val();
   
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            searchproduct : searchproduct,
        },
        success:function(data,startus){
            $('#get_shop_product').html(data);
        },
    })
})



// get Wish List

function get_wish_list(){
    var get_wish_list = "get_wish_list";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_wish_list : get_wish_list,
        },
        success:function(data,status){
            $('#get_wish_list').html(data);
        }
    })
};

get_wish_list();

// ********************* add To Wish Cart *******************************

function add_wish_cart(wish_cart){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            wish_cart : wish_cart,
        },
        success:function(data,startus){
            get_wish_list();
        },
    })
}



// &&&&&&&&&&&&&&&&&& wish Cart *************************

function delete_wish_cart(delete_wish_cart){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            delete_wish_cart : delete_wish_cart,
        },
        success:function(data,startus){
            get_wish_list();
        },
    })
}




// function get_review_data(ravi){
//     console.log("ravihs");
//     console.log(ravi);
// }



 
// Review Rating Form

$('#review_form').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            $('#review_form')[0].reset();
            $('#review_form_alert').html(data);
            console.log(data);
        }
    })
})


// Get Top Rated products


//  get_top_rated_products(1);

function pagination(pagination_id){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            top_rated : "toprated",
            pagination_id : pagination_id,
        },
        success:function(data,status){
            $('#top_rated').html(data);
        },
    })
    console.log(pagination_id);
}

pagination(1);




// Get All New Models

function Latest(latest){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            latest_product : "latest",
            latest_id : latest,
        },
        success:function(data,status){
            $('#Latest').html(data);
        },
    })
}

Latest(1);


// Get All Featured Products

function Featured(featured_id){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            Featured : "featured",
            featured_id : featured_id,
        },
        success:function(data,status){
            $('#Featured').html(data);
        },
    })
}

Featured(1);

// ****************** Pagination in product shp




function product_shop_pagination(product_shop_pagination_id){
    console.log(product_shop_pagination_id);
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            product_shop_pagination : "product_shop_pagination_id",
            product_shop_pagination_id : product_shop_pagination_id,
        },
        success:function(data,status){
            $('#get_shop_product').html(data);
        },
    })
}



// pagintaion button
$(document).ready(function () {
    
// function get_top_rated_products(pagination_id){
//     $.ajax({
//         url : 'phpfunction.php',
//         type : 'POST',
//         data : {
//             top_rated : "toprated",
//             pagination_id : pagination_id,
//         },
//         success:function(data,startus){
//             $('#top_rated').html(data);
//         },
//     })
// }

//  get_top_rated_products(1);

// get_top_rated_products(1);

//     $(document).on('click','#pagination a',function(e) {
//         e.preventDefault();    
//         console.log($(this).attr("id"));
//       })
          
})

 
 
  
// *******************

//filter

//****************** 

function searchbyamount(){
   var price = $('.filter-price-range').html();
   var price_split = price.split(" ");
   
   $.ajax({
    url : 'phpfunction.php',
    type : 'POST',
    data : {
        first_price : price_split[0],
        second_price : price_split[2],
    },
    success:function(data,startus){
        $('#get_shop_product').html(data);
        console.log(data);
    },
 })
}

// Update profilr

//UpdateImgName
//





