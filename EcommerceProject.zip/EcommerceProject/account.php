<?php 
include('dbConnection/dbConnection.php'); 

session_start();
if(isset($_SESSION['register_login'])){
	$user_email = $_SESSION['singin_email'];
}else{
	echo "<script> location.href='login-register.php'; </script>";
}

$sql = "SELECT * FROM user_reg WHERE user_email = '{$user_email}'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$first_name = $row['first_name'];
$last_name = $row['last_name'];

$user_name = $row['users_name'];
$users_email = $row['user_email'];
$user_phone = $row['user_mobile'];
$user_pass = $row['user_pass'];




?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

	<title>Mukkar</title>

	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="Donald - Bootstrap eCommerce Template">
	<meta name="author" content="D-THEMES">

	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/icons/favicon.png">

	<script>
		WebFontConfig = {
			google: { families: ['Open+Sans:400,600,700', 'Poppins:400,500,600,700'] }
		};
		(function (d) {
			var wf = d.createElement('script'), s = d.scripts[0];
			wf.src = 'js/webfont.js';
			wf.async = true;
			s.parentNode.insertBefore(wf, s);
		})(document);
	</script>


	<link rel="stylesheet" type="text/css" href="vendor/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.min.css">

	<!-- Plugins CSS File -->
	<link rel="stylesheet" type="text/css" href="vendor/magnific-popup/magnific-popup.min.css">

	<!-- Main CSS File -->
	<link rel="stylesheet" type="text/css" href="css/style.min.css">
</head>

<body>
	<div class="loading-overlay">
		<div class="bounce-loader">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
			<div class="bounce4"></div>
		</div>
	</div>
	<div class="page-wrapper">
	
	<header class="header">				
		<!-- End HeaderTop -->
			<div class="header-middle sticky-header fix-top sticky-content">
				<div class="container">
					<div class="header-left">
						<a href="#" class="mobile-menu-toggle">
							<i class="d-icon-bars2"></i>
						</a>
					</div>
					<div class="header-center">
						<a href="demo1.html" class="logo">
							<img src="images/logo.png" alt="logo" width="163" height="39" />
						</a>
						<!-- End Logo -->
						<nav class="main-nav">
						<ul class="menu">
                                    <li class="active">
                                        <a href="index.php">Home</a>
                                    </li>
									<li>
                                    <a href="product.html">Products</a>
                                    <div class="megamenu">
                                        <div class="row">

                                        <?php
                                        
                                        $sql = "SELECT * FROM catogry_page";
                                        $result = $conn->query($sql);
                                        if($result->num_rows > 0){
                                            while($row = $result->fetch_assoc()){
                                                echo '<div class="col-4 col-sm-4 col-md-3 col-lg-4">
                                                       <h4 class="menu-title">'.$row['catogry_page'].'</h4>
                                                      <ul>
                                                ';
                                                ?>
                                           <?php 
                                           
                                             $sqli = "SELECT * FROM catogry_item WHERE catogry_page = '{$row['catogry_page']}'";
                                             $resulti = $conn->query($sqli);
                                             if($resulti->num_rows > 0){
                                                 while($rowi = $resulti->fetch_assoc()){
                                                  
                                                   echo '<li><a href="product_shop.php?product_catogry='.$rowi['catogry_item'].'">'.$rowi['catogry_item'].'</a></li>';
                                                 }
                                             } 
                                           
                                           ?>
                                        <?php

                                                echo '</ul></div>';
                                            }
                                        }
                                        
                                        ?>
                                            <!-- <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Pages</h4>
                                                <ul>
                                                    <li><a href="product-simple.html">Simple Product</a></li>
                                                    <li><a href="product.html">Variable Product</a></li>
                                                    <li><a href="product-sale.html">Sale Product</a></li>
                                                    <li><a href="product-featured.html">Featured &amp; On Sale</a></li>

                                                    <li><a href="product-left-sidebar.html">With Left Sidebar</a></li>
                                                    <li><a href="product-right-sidebar.html">With Right Sidebar</a></li>
                                                    <li><a href="product-sticky-cart.html">Add Cart Sticky<span
                                                                class="tip tip-hot">Hot</span></a></li>
                                                    <li><a href="product-tabinside.html">Tab Inside</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Layouts</h4>
                                                <ul>
                                                    <li><a href="product-grid.html">Grid Images<span
                                                                class="tip tip-new">New</span></a></li>
                                                    <li><a href="product-masonry.html">Masonry</a></li>
                                                    <li><a href="product-gallery.html">Gallery Type</a></li>
                                                    <li><a href="product-full.html">Full Width Layout</a></li>
                                                    <li><a href="product-sticky.html">Sticky Info</a></li>
                                                    <li><a href="product-sticky-both.html">Left &amp; Right Sticky</a>
                                                    </li>
                                                    <li><a href="product-horizontal.html">Horizontal Thumb</a></li>

                                                    <li><a href="#">Build Your Own</a></li>
                                                </ul>
                                            </div> -->
                                            <div
                                                class="col-6 col-sm-4 col-md-3 col-lg-4 menu-banner menu-banner2 banner banner-fixed">
                                                <figure>
                                                    <img src="images/menu/banner-2.jpg" alt="Menu banner" width="221"
                                                        height="330" />
                                                </figure>
                                                <div class="banner-content x-50 text-center">
                                                    <h3 class="banner-title text-white text-uppercase">Sunglasses</h3>
                                                    <h4 class="banner-subtitle font-weight-bold text-white mb-0">$23.00
                                                        -
                                                        $120.00</h4>
                                                </div>
                                            </div>
                                            <!-- End MegaMenu -->
                                        </div>
                                    </div>
                                </li>

                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <li>
                                        <a href="about-us.html">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                  
                                    <li>
                                        <a href="wishlist.php">Wish Cart</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>
                                </ul>
						</nav>
						<span class="divider"></span>
						<!-- End Divider -->
						<div class="header-search hs-toggle">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End Header Search -->
					</div>
					<div class="header-right">
						<a class="login" href="ajax/login.html">
							<i class="d-icon-user"></i>
							<span>Login</span>
						</a>
						<!-- End Login -->
						<span class="divider"></span>
					
						<div class="dropdown cart-dropdown">
                            <a href="#" class="cart-toggle">
                                <span class="cart-label">
                                    <span class="cart-name">My Cart</span>
                                    <span class="cart-price total_amount"></span>
                                </span>
                                <i class="minicart-icon">
                                    <span class="cart-count count"></span>
                                </i>
                            </a>
                            <!-- End of Cart Toggle -->
                            <div class="dropdown-box">
                                <div class="product product-cart-header">
                                    <span class="product-cart-counts count"> items : </span>
                                    <span><a href="cart.php">View cart</a></span>
                                </div>
                                <div class="products scrollable" id="showcart">

                                   
                                    <!-- End of Cart Product -->
                                       
                                    <!-- End of Cart Product -->
                                </div>
                                <!-- End of Products  -->
                                <div class="cart-total">
                                    <label>Subtotal:</label>
                                    <span class="price total_amount"></span>
                                </div>
                                <!-- End of Cart Total -->
                                <div class="cart-action">
                                    <a href="checkout.php" class="btn btn-dark"><span>Checkout</span></a>
                                </div>
                      
                                <!-- End of Cart Action -->
                            </div>
                            <!-- End of Dropdown Box -->
                        </div>
						<div class="header-search hs-toggle mobile-search">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End of Header Search -->
					</div>
				</div>

			</div>
		</header>
		<!-- End Header -->
		<!-- End Header -->
		<main class="main account">
			<div class="page-header"
				style="background-image: url('images/page-header.jpg'); background-color: #3C63A4;">
				<h1 class="page-title">My Account</h1>
				<ul class="breadcrumb">
					<li><a href="demo1.html"><i class="d-icon-home"></i></a></li>
					<li>My Account</li>
				</ul>
			</div>
			<!-- End PageHeader -->
			<div class="page-content mt-10 mb-10">
				<div class="container pt-1">
					<div class="tab tab-vertical">
						<ul class="nav nav-tabs mb-4" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" href="#dashboard">Dashboard</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="#orders">Orders</a>
							</li>
						
							<li class="nav-item">
								<a class="nav-link" href="#address">Addresses</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="#account">Account details</a>
							</li>
							<li class="nav-item">
								<a href="logout.php">Logout</a>
							</li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane active" id="dashboard">
							<div class="container">
									<div class="row">
										<div class="col-xl-6 col-12" id="getImg"><img src="images/imageProfile/ravi.jpg"></div>
										<div class="col-xl-6 col-12">
											<form action="" method="POST" id="UpdateUserPorfileImg">
												<input type="file" name="UpdateImgName">
												<input type="hidden" type="text" id="emailid" class="bg-dark" name="userEmail" value="<?php if(isset($users_email)){echo $users_email;} ?>">
												<input type="submit"  class="btn btn-success" value="update">
											</form>
										</div>
                                    </div>
								</div>
							</div>
							<div class="tab-pane" id="orders">
								<table class="shop-table cart-table mt-2">
									<thead>
										<tr>
											<th><span>Product</span></th>
											<th><span>Product Name</span></th>
											<th><span>Price</span></th>
											<th>Status</th>
											<th>Subtotal</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody id="get_order_data">
									
									</tbody>
									<div id="cancel_order"></div>
								</table>
								<a href="product_shop.php" class="btn btn-primary">Go Shop</a>
							</div>
						
							<div class="tab-pane" id="address">
								<p class="mb-2">The following addresses will be used on the checkout page by default.
								</p>
								<div class="row">
									<div class="col-lg-6 mb-4">
										<div class="card card-address">
											<div class="card-body">
												<h5 class="card-title">Billing Address</h5>
												<p>User Name<br>
													User Company<br>
													John str<br>
													New York, NY 10001<br>
													1-234-987-6543<br>
													yourmail@mail.com<br>
												</p>
												<a href="#" class="btn btn-link btn-secondary btn-underline">Edit <i
														class="far fa-edit"></i></a>
											</div>
										</div>
									</div>
									<div class="col-lg-6 mb-4">
										<div class="card card-address">
											<div class="card-body">
												<h5 class="card-title">Shipping Address</h5>
												<p>You have not set up this type of address yet.</p>
												<a href="#" class="btn btn-link btn-secondary btn-underline">Edit <i
														class="far fa-edit"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="tab-pane" id="account">
								<form action="" id="update_profile" class="form">
									<div class="row">
										<div class="col-sm-6">
											<label>First Name *</label>
											<input type="text" class="form-control" value="<?php if(isset($first_name)){ echo $first_name; } ?>" name="first_name_update" required="">
										</div>
										<div class="col-sm-6">
											<label>Last Name *</label>
											<input type="text" class="form-control" name="last_name_update" value="<?php if(isset($last_name)){ echo $last_name; } ?>" required="">
										</div>
									</div>

									<label>Display Name *</label>
									<input type="text" class="form-control mb-0" value="<?php if(isset($user_name)){ echo $user_name; } ?>" name="display_name" required="" readonly>
									<small class="d-block form-text mb-4">This will be how your name will be displayed
										in the account section and in reviews</small>

									<label>Email address *</label>
									<input type="email" class="form-control" value="<?php if(isset($user_email)){ echo $user_email; } ?>" name="user_email" required="" readonly>

									<label>Your phone Nu *</label>
									<input type="mobile" class="form-control" value="<?php if(isset($user_phone)){ echo $user_phone; } ?>" name="user_phone" required="">

									<label>Current password (leave blank to leave unchanged)</label>
									<input type="password" class="form-control" value="" name="current_password" name="current_password">

									<label>New password (leave blank to leave unchanged)</label>
									<input type="password" class="form-control" name="new_password">

									<label>Confirm new password</label>
									<input type="password" class="form-control" name="confirm_password">

									<button type="submit" class="btn btn-primary btn-reveal-right">SAVE CHANGES <i
											class="d-icon-arrow-right"></i></button>
								</form>
							</div>
							<div id="profile_update"></div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<!-- End Main -->


		<?php include('include/footer.php'); ?>