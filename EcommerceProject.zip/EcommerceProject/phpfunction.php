<?php 

//Database Connection
include('dbConnection/dbConnection.php');

$user_ip = getUserIp();

// ************* USER LOGIN *******************8 

session_start();

if (!isset($_session['register_login'])) {
    if (isset($_REQUEST['singin_email'])) {
      $singin_email = mysqli_real_escape_string($conn, trim($_REQUEST['singin_email']));
      $singin_password = mysqli_real_escape_string($conn, trim($_REQUEST['singin_password']));

        $sql = "SELECT * FROM user_reg WHERE user_email = '$singin_email'";
        $result = $conn->query($sql);
        $row = $result->num_rows;
        if ($row == 1) {
             $data = $result->fetch_assoc();
             $pass = $data['user_pass'];

            //  echo $pass;

             if(password_verify($singin_password,$pass)){
                     echo '<alert class="alert font-weight-bold text-light alert-primary">Login Sucessfull</alert>';
                      $_SESSION['register_login'] = true;
                      $_SESSION['singin_email'] = $singin_email;
                      if (isset($_REQUEST['signin-remember'])) {
                        setcookie('signin-email', $singin_email, time() + 96500 * 30);
                        setcookie('singin_password', $singin_password, time() + 96500 * 30);
                      }
             }else{
                 echo '<alert class="alert font-weight-bold text-light alert-primary">Password Does Not Match</alert>';
                 
             }

      
        } else {
          echo '<alert class="alert font-weight-bold text-light alert-primary">Login Failed data</alert>';
        } 
    }

  }else{
      echo '<script> Location.href="account.php"; </script>';
  }


//   echo "ravush";

if(isset($_SESSION['register_login'])){
	$_GLOBAL['UserEmail'] = $_SESSION['register_login'];
}

// echo $_GLOBAL['UserEmail'];
// echo 'ravsh';

//userRegistertion

if(isset($_REQUEST['register-agree'])){
  $first_name = $_REQUEST['first_name'];
  $last_name = $_REQUEST['last_name'];
  $register_name = $_REQUEST['register_name'];
  $register_email = $_REQUEST['register_email'];
  $register_phone = $_REQUEST['register_phone'];
  $register_password = $_REQUEST['register_password'];

  $register_password = password_hash($register_password ,PASSWORD_BCRYPT);

   if(strlen($register_password) >= 6){
    $sql = "SELECT * FROM user_reg WHERE users_name = '{$register_name}' || user_email = '{$register_email}'";
    $result = $conn->query($sql);
    if($result->num_rows === 1){
      echo '<div class="alert alert-success text-light p-2">User Name or Email Already Registered</div>';
    }else{
      $sql = "INSERT INTO user_reg (first_name,last_name,user_email,users_name,user_mobile,user_pass) VALUES
      ('$first_name','$last_name','$register_email','$register_name','$register_phone','$register_password')";
      $result = $conn->query($sql);
     if($result){
        echo '<alert class="alert font-weight-bold text-light alert-primary">Register Sucessfull</alert>';
     }else{
         echo 'failed';
     }
    }
   }else{
    echo '<alert class="alert font-weight-bold text-light alert-primary">Please Use Pass More than 6 charactars</alert>';
   }

  
}

// ********************** Update Profile************************

if(isset($_REQUEST['first_name_update'])){
    $first_name_update = $_REQUEST['first_name_update'];
    $last_name_update = $_REQUEST['last_name_update'];
    $user_phone = $_REQUEST['user_phone'];
    $user_email = $_REQUEST['user_email'];

    $sql = "UPDATE user_reg SET first_name = '$first_name_update',last_name='$last_name_update',user_mobile='$user_phone' WHERE user_email = '{$user_email}'";
    $result = $conn->query($sql);
    if($result){
        // echo '<div class="alert alert-success text-light">Update Successfull</div>';
    }else{
        echo 'failed';
    }
}

if(isset($_REQUEST['new_password'])){
    if(($_REQUEST['new_password'] == '') || ($_REQUEST['confirm_password'] == '')){
       echo 'fill all filed';
    }else{
        $current_password = $_REQUEST['current_password'];
        $new_password = $_REQUEST['new_password'];
        $confirm_password = $_REQUEST['confirm_password'];
        $user_email = $_REQUEST['user_email'];
        
      
        if($new_password == $confirm_password){
            $sqli = "SELECT * FROM user_reg WHERE user_email = '{$user_email}'";
            $resulti = $conn->query($sqli);
            if($resulti->num_rows > 0){
                $rowi = $resulti->fetch_assoc();
                $passi = $rowi['user_pass'];
                $updatepass = password_hash($new_password ,PASSWORD_BCRYPT);
                if(password_verify($current_password,$passi)){
                    $sql = "UPDATE user_reg SET user_pass = '$updatepass' WHERE user_email = '{$user_email}'";
                    $result = $conn->query($sql);
                    if($result){
                        echo '<div class="alert alert-success text-light">Update Successfull</div>';
                    }else{
                        echo 'failed';
                    }
                }
            }
        }
    }
}



//Update Profile

if(isset($_FILES['UpdateImgName']))
{
     $userEmail = $_REQUEST['userEmail'];
    $profileImage = $_FILES['UpdateImgName']['name'];
    $folder = 'images/Profile/'.$profileImage;
    $profileImagetmp = $_FILES['UpdateImgName']['tmp_name'];
    move_uploaded_file($profileImagetmp,$folder);
    $sql = "UPDATE user_reg SET user_profile = '$folder' WHERE user_email = '{$userEmail}' ";
    $result = $conn->query($sql);
    if($result){
      echo 'success data';
    }else{
        echo 'no';
    }
   
}



if(isset($_REQUEST['GetProfileImgData'])){
    $userEmail = $_REQUEST['UserEmail'];
    $sql = "SELECT * FROM user_reg WHERE user_email = '{$userEmail}'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        echo '<img src="'.$row['user_profile'].'">';
    }
}







//AddToCartFunction

if(isset($_REQUEST['product_id'])){
    $product_id = $_REQUEST['product_id'];
    $sql = "SELECT * FROM products WHERE id = {$product_id}";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $product_name = $row['product_name'];
    $product_price = $row['product_price'];

    $product_images = $row['product_images'];
   
    if(isset($_REQUEST['product_quantity'])){
        $product_quantity = $_REQUEST['product_quantity'];
    }else{
        $product_quantity = 1;
    }
    
    if(isset($_REQUEST['product_size'])){
        $product_size = $_REQUEST['product_size'];
    }else{
        $product_size = "xl";
    }
   
     $userip = getUserIp();

     $sql = "SELECT * FROM addtocart WHERE product_id = '{$product_id}'";
     $result = $conn->query($sql);
     if($result->num_rows === 1){
         echo "already added this product";
     }else{
        $sqlinsert = "INSERT INTO addtocart (product_id,user_ip,product_name,product_quantity,product_size,product_price,product_images) VALUES 
        ('$product_id','$userip','$product_name','$product_quantity','$product_size','$product_price','$product_images')";
    
        $resultquery = $conn->query($sqlinsert);
        if($resultquery){
          echo 'successfull';
        }else{
            echo 'failed';
        }
     }
}


//AddtoCart 2

if(isset($_REQUEST['product_id_product'])){
    $product_id_product = $_REQUEST['product_id_product'];
    $sql = "SELECT * FROM products WHERE id = '{$product_id_product}'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $product_name = $row['product_name'];
    $product_price = $row['product_price'];
    $product_images = $row['product_images'];
   
    if(isset($_REQUEST['product_quantity'])){
        $product_quantity = $_REQUEST['product_quantity'];
    }else{
        $product_quantity = 1;
    }
    
    if(isset($_REQUEST['product_size'])){
        $product_size = $_REQUEST['product_size'];
    }else{
        $product_size = "xl";
    }
   
     $userip = getUserIp();

     $sql = "SELECT * FROM addtocart WHERE product_id = '{$product_id_product}'";
     $result = $conn->query($sql);
     if($result->num_rows === 1){
         echo "already added this product";
     }else{
        $sqlinsert = "INSERT INTO addtocart (product_id,user_ip,product_name,product_quantity,product_size,product_price,product_images) VALUES 
        ('$product_id_product','$userip','$product_name','$product_quantity','$product_size','$product_price','$product_images')";
    
        $resultquery = $conn->query($sqlinsert);
        if($resultquery){
          echo 'successfull';
        }else{
            echo 'failed';
        }
     }
}

//showcartItem

if(isset($_REQUEST['show_cart'])){ 
    $sql = "SELECT * FROM addtocart WHERE user_ip = '{$user_ip}' ORDER BY id DESC";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        WHILE($row = $result->fetch_assoc()){
           $product_image = $row['product_images'];
            if(isset($product_image)){
               $product_item = explode(',',$product_image);
            }  
            echo '<div class="product product-cart">
            <div class="product-detail">
                <a href="view-product.php?product_id='.$row['product_id'].'" class="product-name">'.$row['product_name'].'</a>
                <div class="price-box">
                    <span class="product-quantity">1</span>
                    <span class="product-price">$'.$row['product_price'].'</span>
                </div>
            </div>
            <figure class="product-media">
                <a href="#">
                    <img src="Admin/ecommerce/images/'.$product_item[0].'" alt="product" width="90"
                        height="90" />
                </a>
                <button onclick="deletecartitem('.$row['id'].')" class="btn btn-link btn-close">
                    <i class="fas fa-times"></i>
                </button>
            </figure>
        </div>';
        }
    }
}


//ShowCartTable

if(isset($_REQUEST['show_cart_table'])){ 
    $sql = "SELECT * FROM addtocart WHERE user_ip = '{$user_ip}' ORDER BY id DESC";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        WHILE($row = $result->fetch_assoc()){
           $product_image = $row['product_images'];
            if(isset($product_image)){
               $product_item = explode(',',$product_image);
            } 
            $total_amount = $row['product_quantity']*$row['product_price'];
            echo '<tr>
            <td class="product-thumbnail">
                <figure>
                    <a href="product-simple.html">
                        <img src="Admin/ecommerce/images/'.$product_item[0].'" width="100" height="100"
                        alt="product">
                    </a>
                    <a  class="product-remove" onclick="deletecartitem('.$row['id'].')" title="Remove this product">
                        <i class="fas fa-times"></i>
                   </a>
                </figure>
            </td>
            <td class="product-name">
                <div class="product-name-section">
                    <a href="product-simple.html">'.$row['product_name'].'</a>
                </div>
            </td>
            <td class="product-subtotal">
                <span class="amount">$: '.$row['product_price'].'</span>
            </td>
            <td class="product-quantity">
                <div class="input-group">
                    <button onclick="update_quantity_minus('.$row['id'].','.$row['product_quantity'].')" class=" d-icon-minus"></button>
                    <input class="form-control" min="1" type="number" id="quantity_item" value="'.$row['product_quantity'].'" readonly>
                    <button onclick="update_quantity_plus('.$row['id'].','.$row['product_quantity'].')" class="btn d-icon-plus"></button>
                </div>
            </td>
            <td class="product-price">
                <span class="amount">$ : '.$total_amount.'</span>
            </td>
            </tr>';
        }
    }
}


// ***************** showcartcheckout

if(isset($_REQUEST['show_cart_checkout'])){ 
    $sql = "SELECT * FROM addtocart WHERE user_ip = '{$user_ip}' ORDER BY id DESC";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        WHILE($row = $result->fetch_assoc()){
            $sub_total = $row['product_quantity']*$row['product_price']; 
            echo '<tr>
            <td class="product-name">'.$row['product_name'].'<strong class="product-quantity">×&nbsp;'.$row['product_quantity'].'</strong></td>
              <td class="product-total">$: '.$sub_total.'</td>
            </tr>';
        }
    }
}

//CartItemDelete


if(isset($_REQUEST['cartiddelete'])){
    $cartiddelete = $_REQUEST['cartiddelete'];
    $sql = "DELETE FROM addtocart WHERE id = '{$cartiddelete}'";
    $result = $conn->query($sql);
    if($result){
        echo 'deleted';
    }else{
        echo 'failed';
    }
}

//CountData

if(isset($_REQUEST['subtotalitem'])){
    $subtotal = $_REQUEST['subtotalitem'];
    $sql = "SELECT * FROM addtocart";
    $result = $conn->query($sql);
    $count = $result->num_rows;
    echo $count;
}

//TotalCount

if(isset($_REQUEST['totalamount'])){
    $totalamount = $_REQUEST['totalamount'];
    $userip = getUserIp();
    $total_amount = 0;
    $sql = "SELECT * FROM addtocart WHERE user_ip = '{$userip}'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
       WHILE($row = $result->fetch_assoc()){
          $sub_total = $row['product_price']*$row['product_quantity'];
          $total_amount += $sub_total;
       }
    }
    echo "$: ".$total_amount;
}


//UpdateCartTable



if(isset($_REQUEST['update_quantity'])){
    $update_quantity = $_REQUEST['update_quantity'];
    $update_id = $_REQUEST['update_id'];
    $sql = "UPDATE addtocart SET product_quantity = '{$update_quantity}' WHERE id = '{$update_id}'";
    $result = $conn->query($sql);
   
}


// ************************* checkout ***********************/

if(isset($_REQUEST['first_name_checkout'])){

    if($_REQUEST['PaymentMethod'] == 'cashondelivery'){
        
        $sql = "SELECT * FROM addtocart WHERE user_ip = '{$user_ip}'";
        $resultitem = $conn->query($sql);
        if($resultitem->num_rows > 0){
        WHILE($row = $resultitem->fetch_assoc()){
        $product_id = $row['product_id'];
        $product_name = $row['product_name'];
        $product_quantity = $row['product_quantity'];
        $product_size = $row['product_size'];
        $product_price = $row['product_price'];
        $product_images = $row['product_images'];

        $user_name = $_REQUEST['user_name'];
        $user_email = $_REQUEST['user_email'];
        $first_name = $_REQUEST['first_name_checkout'];
        $last_name = $_REQUEST['last_name_checkout'];
        $company_name = $_REQUEST['company_name'];
        $country = $_REQUEST['country'];
        $address1 = $_REQUEST['address1'];
        $address2 = $_REQUEST['address2'];
        $city = $_REQUEST['city'];
        $district = $_REQUEST['district'];
        $state = $_REQUEST['state'];
        $postcode = $_REQUEST['postcode'];
        $phone = $_REQUEST['phone'];
        $email_address = $_REQUEST['email_address'];
        $other_notes = $_REQUEST['other_notes'];
        $today_date = date("Y.m.d"); 
        $delivery_status = "Processing";

        $sqlcheckout = "INSERT INTO place_order (product_id,product_name,product_quantity,
        product_size,product_price,product_images,users_name,user_email,first_name,
        last_name,company_name,country,street_adress1,street_adress2,town,district,
        user_state,postcode,phone,email_adress,other_notes,today_date,user_ip,delivery_status) 
        VALUES ('$product_id','$product_name','$product_quantity','$product_size','$product_price','$product_images',
        '$user_name','$user_email','$first_name','$last_name','$company_name','$country','$address1','$address2','$city','$district','$state','$postcode',
        '$phone','$email_address','$other_notes','$today_date','$user_ip','$delivery_status')";
        $result = $conn->query($sqlcheckout );

        if($result){
            echo "<script> location.href='order.php'; </script>";


            $delete = "DELETE FROM addtocart WHERE user_ip = '$user_ip'";
            $resultdelete = $conn->query($delete);


        }
    }
   }
 }
}


// Update Order Data

if(isset($_REQUEST['order_update_id'])){
         $order_update_id = $_REQUEST['order_update_id'];
        //  $product_name = $row['product_name'];
        //  $product_quantity = $row['product_quantity'];
        //  $product_size = $row['product_size'];
        //  $product_price = $row['product_price'];
        //  $product_images = $row['product_images'];
        //  $user_name = $_REQUEST['user_name'];
        //  $user_email = $_REQUEST['user_email'];
         $first_name = $_REQUEST['first_name_update'];
         $last_name = $_REQUEST['last_name_update'];
         $company_name = $_REQUEST['company_name'];
         $country = $_REQUEST['country'];
         $address1 = $_REQUEST['address1'];
         $address2 = $_REQUEST['address2'];
         $city = $_REQUEST['city'];
         $district = $_REQUEST['district'];
         $state = $_REQUEST['state'];
         $postcode = $_REQUEST['postcode'];
         $phone = $_REQUEST['phone'];
         $email_address = $_REQUEST['email_address'];
         $other_notes = $_REQUEST['other_notes'];
         $today_date = date("Y.m.d");
         $delivery_status = "Processing";
 
         $sql = "UPDATE place_order SET first_name = '$first_name', 
         last_name = '$last_name',company_name = '$company_name',country = '$country',street_adress1 = '$address1',street_adress2 = '$address2'
         ,town = '$city',district = '$district',user_state = '$state',postcode='$postcode',phone='$phone',email_adress='$email_address',
         other_notes = '$other_notes',today_date='$today_date' WHERE id = '{$order_update_id}'";
         $result = $conn->query($sql);
         if($result){
             echo "UPDATES SUCESS FULL";
         }else{
             echo 'failed';
         }
 }
 

// ****************** GetOrderData *********************/

if(isset($_REQUEST['order_data'])){ 
    $sql = "SELECT * FROM place_order ORDER BY id DESC";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        WHILE($row = $result->fetch_assoc()){
            $product_image = $row['product_images'];
            $product_item_image = explode(',',$product_image);

            $sub_total = $row['product_quantity']*$row['product_price']; 
            echo '<tr>
            <td class="product-thumbnail">
                <figure>
                    <a href="product-simple.html">
                        <img src="Admin/ecommerce/images/'.$product_item_image[0].'" width="100" height="100"
                        alt="product">
                    </a>
                  
                </figure>
            </td>
            <td class="product-name">'.$row['product_name'].'</td>
            <td>'.$row['product_price'].'X'.$row['product_quantity'].'</td>
            <td>'.$row['delivery_status'].'</td>
            <td class="product-price">
                <span class="amount">$ : '.$sub_total.'</span>
            </td>
            <td><button onclick="cancel_order('.$row['id'].')" class="btn btn-success">Cancel Order</button></td>
            <td><a href="update_order.php?update_order_id='.$row['id'].'"><button class="btn btn-success">Update Order</button></td>
            </tr>';
        }
    }
}

// *************** Cancle Order Data  ********************/

if(isset($_REQUEST['cancle_order_id'])){
    $cancle_order_id = $_REQUEST['cancle_order_id'];

    $sql = "SELECT * FROM place_order WHERE id = '{$cancle_order_id}'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    $order_id = $row['id'];
    $product_id = $row['product_id'];
    $product_name = $row['product_name'];
    $users_name = $row['users_name'];
    $user_email = $row['user_email'];
    $user_phone = $row['phone'];
    $messege = "Request for cancel Order";
    $today_date =  date("Y.m.d");

    $sqlinsertmessege = "INSERT INTO send_messege (users_name,user_email,user_phone,send_messege,order_id,product_id,today_date)
     VALUES ('$users_name','$user_email','$user_phone','$messege','$order_id','$product_id','$today_date')";
    $resultsend = $conn->query($sqlinsertmessege);
    if($resultsend){
        echo '<div class="alert alert-sucess text-light font-weight-bold">We Have Received Your Messege For Cancel Order</div>';
    }else{
        echo 'failed';
    }
    
    $select_notification = "SELECT * FROM notification_itembox WHERE id = 1";
    $result_notification = $conn->query($select_notification);
    $row_notification = $result_notification->fetch_assoc();
    $notification_count = $row_notification['notification_number'];
    $notification_count++;
    $update = "UPDATE notification_itembox SET notification_number = '$notification_count' WHERE id = 1";
    $result_update = $conn->query($update);

}




// ********************************* GET SHOP PRODUCT ************************

if(isset($_REQUEST['searchproduct'])){
    $searchproduct = $_REQUEST['searchproduct'];
    $sql = "SELECT * FROM products WHERE product_name LIKE '%{$searchproduct}%' || 	product_sub_text LIKE '%{$searchproduct}%' ||
    	catogry_section LIKE '%{$searchproduct}%' || meta_title LIKE '%{$searchproduct}%' || meta_keyword LIKE '%{$searchproduct}%' ";
    $result = $conn->query($sql);
    if($result->num_rows> 0 ){
      WHILE($row = $result->fetch_assoc()){
          $product_image = $row['product_images'];
									$item_image_product = explode(',',$product_image);
                                       echo '<div class="product-wrap">
									   <div class="product shadow-media">
										   <figure class="product-media">
											   <a href="view-product.php?product_id='.$row['id'].'">
												   <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product" width="340" style="height:250px;" >
											   </a>
											   <div class="product-label-group">
												   <label class="product-label label-new">new</label>
											   </div>
											   <div class="product-action-vertical">
												   <a href="#" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
													   data-target="#addCartModal" title="Add to cart"><i
														   class="d-icon-bag"></i></a>
											   </div>
											   <div class="product-action">
												   <a href="#" class="btn-product btn-quickview" title="Quick View">Quick
													   View</a>
											   </div>
										   </figure>
										   <div class="product-details">
											   <a href="#" class="btn-wishlist" title="Add to wishlist"><i
													   class="d-icon-heart"></i></a>
											   <div class="product-cat">
												   <a href="shop-grid-3col.html">categories</a>
											   </div>
											   <h3 class="product-name">
												   <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
											   </h3>
											   <div class="product-price">
												   <ins class="new-price">$'.$row['product_price'].'</ins><del class="old-price">$210.00</del>
											   </div>
											   <div class="ratings-container">
												   <div class="ratings-full">
													   <span class="ratings" style="width:'.$row['product_rating'].'%"></span>
													   <span class="tooltiptext tooltip-top"></span>
												   </div>
												   <a href="view-product.php?product_id='.$row['id'].'" class="rating-reviews">( 6 reviews )</a>
											   </div>
										   </div>
									   </div>
								   </div>';
      }
    }
}




// ********************* add To Wish Cart *******************************

if(isset($_REQUEST['wish_cart'])){
    $wish_cart = $_REQUEST['wish_cart'];

    $sql = "SELECT * FROM products WHERE id = {$wish_cart}";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $product_name = $row['product_name'];
    $product_price = $row['product_price'];
    $product_images = $row['product_images'];


     $sqlselect = "SELECT * FROM wish_cart WHERE product_id = '{$wish_cart}'";
     $resultselect = $conn->query($sqlselect);
     if($resultselect->num_rows === 1){
         echo "already added this product";
     }else{
        $sqlinsert = "INSERT INTO wish_cart (user_ip,product_id,product_name,product_price,product_images) 
        VALUES ('$user_ip','$wish_cart','$product_name','$product_price','$product_images')";
       $resultinsert = $conn->query($sqlinsert);
        if($resultinsert){
          echo 'successfull';
        }else{
            echo 'failed';
        }
     }
}

// get Wish List data

if(isset($_REQUEST['get_wish_list'])){

    $sql = "SELECT * FROM wish_cart where user_ip = '{$user_ip}'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        WHILE($row = $result->fetch_assoc()){
            $product_images = $row['product_images'];
            $product_item_image = explode(',',$product_images); 
            echo '<tr>
            <td class="product-thumbnail">
                <a href="view-product.php?product_id='.$row['product_id'].'">
                    <figure>
                        <img src="Admin/ecommerce/images/'.$product_item_image[0].'" width="100" height="100"
                            alt="product">
                    </figure>
                </a>
            </td>
            <td class="product-name">
                <a href="Admin/ecommerce/images/'.$product_item_image[0].'">'.$row['product_name'].'</a>
            </td>
            <td class="product-add-to-cart">
                <a onclick="addToCart('.$row['id'].')" class="btn-product"><span>Add To Cart</span></a>
            </td>
            <td class="product-price">
                <span class="amount">$:'.$row['product_price'].'</span>
            </td>
            <td class="product-stock-status">
                <span class="wishlist-in-stock">In Stock</span>
            </td>
            <td class="product-add-to-cart">
                <a href="Admin/ecommerce/images/'.$product_item_image[0].'" class="btn-product"><span>Select option</span></a>
            </td>
            <td class="product-remove">
                <div>
                    <a onclick="delete_wish_cart('.$row['id'].')" class="remove" title="Remove this product"><i
                            class="d-icon-times"></i></a>
                </div>
            </td>
        </tr>';
        }
    }
}


//Delete Wish cart

if(isset($_REQUEST['delete_wish_cart'])){
    $delete_wish_cart = $_REQUEST['delete_wish_cart'];
    $sql = "DELETE FROM wish_cart WHERE id = '{$delete_wish_cart}'";
    $result = $conn->query($sql);
}




// Top Rated

if(isset($_REQUEST['top_rated'])){

    if(isset($_REQUEST['pagination_id'])){
        $pagination_id = $_REQUEST['pagination_id'];
    }else{
        $pagination_id = 1;
    }
    $limit_per_page = 3;
    $offset = ($pagination_id - 1) * $limit_per_page;

    $top_rated = $_REQUEST['top_rated'];
    $limtproduct = 0;

    $sql = "SELECT * FROM products WHERE product_rating >=80 ORDER BY id DESC LIMIT {$offset},3";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        // $total_row = $result->num_rows;
        // $total_pagination = ceil($total_row / $limit_per_page);

        WHILE($row = $result->fetch_assoc()){
            $product_image = $row['product_images'];
            $item_image_product = explode(',',$product_image);
            echo ' <div class="product product-list-sm">
                <figure class="product-media">
                    <a href="view-product.php?product_id='.$row['id'].'">
                        <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product"
                            width="100" height="100">
                    </a>
                </figure>
                <div class="product-details">
                    <h3 class="product-name">
                        <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                    </h3>
                    <div class="product-price">
                        <span class="price">$: '.$row['product_price'].'</span>
                    </div>
                    <div class="ratings-container">
                        <div class="ratings-full">
                            <span class="ratings" style="width:'.$row['product_rating'].'%"></span>
                            <span class="tooltiptext tooltip-top"></span>
                        </div>
                    </div>
                </div>
            </div>';
        }

        
        echo '<div class="pagination pagination-1 mb-4">';
        $sqli = "SELECT * FROM products WHERE product_rating >=80";
        $resulti = $conn->query($sqli);
        if($resulti->num_rows > 0){
            $total_row = $resulti->num_rows;
            $total_pagination = ceil($total_row / $limit_per_page);
        
            $i=0;
            for($i=1;$i<$total_pagination;$i++){
                echo '<a onclick="pagination('.$i.')">'.$i.'</a>';
            }
        }
        echo '</div>';
    
    
       
    } 
}


// ***************************** Latest Records



if(isset($_REQUEST['latest_product'])){

    if(isset($_REQUEST['latest_id'])){
        $pagination_id = $_REQUEST['latest_id'];
    }else{
        $pagination_id = 1;
    }
    $limit_per_page = 3;
    $offset = ($pagination_id - 1) * $limit_per_page;

    $limtproduct = 0;

    $sql = "SELECT * FROM products ORDER BY id DESC LIMIT {$offset},3";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        // $total_row = $result->num_rows;
        // $total_pagination = ceil($total_row / $limit_per_page);

        WHILE($row = $result->fetch_assoc()){
            $product_image = $row['product_images'];
            $item_image_product = explode(',',$product_image);
            echo ' <div class="product product-list-sm">
                <figure class="product-media">
                    <a href="view-product.php?product_id='.$row['id'].'">
                        <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product"
                            width="100" height="100">
                    </a>
                </figure>
                <div class="product-details">
                    <h3 class="product-name">
                        <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                    </h3>
                    <div class="product-price">
                        <span class="price">$: '.$row['product_price'].'</span>
                    </div>
                    <div class="ratings-container">
                        <div class="ratings-full">
                            <span class="ratings" style="width:'.$row['product_rating'].'%"></span>
                            <span class="tooltiptext tooltip-top"></span>
                        </div>
                    </div>
                </div>
            </div>';
        }

        echo '<div class="pagination pagination-1 mb-4">';
        $sqli = "SELECT * FROM products";
        $resulti = $conn->query($sqli);
        if($resulti->num_rows > 0){
            $total_row = $resulti->num_rows;
            $total_pagination = ceil($total_row / $limit_per_page);
        
            $i=0;
            for($i=1;$i<$total_pagination;$i++){
                echo '<a onclick="Latest('.$i.')">'.$i.'</a>';
            }
        }
        echo '</div>';   
    } 
}







//*****************  */ Get All Featured Product


if(isset($_REQUEST['Featured'])){

    if(isset($_REQUEST['Featured'])){
        $pagination_id = $_REQUEST['featured_id'];
    }else{
        $pagination_id = 1;
    }
    $limit_per_page = 3;
    $offset = ($pagination_id - 1) * $limit_per_page;

    $limtproduct = 0;

    $sql = "SELECT * FROM products WHERE catogry_section='featured' ORDER BY id DESC LIMIT {$offset},3";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        // $total_row = $result->num_rows;
        // $total_pagination = ceil($total_row / $limit_per_page);

        WHILE($row = $result->fetch_assoc()){
            $product_image = $row['product_images'];
            $item_image_product = explode(',',$product_image);
            echo ' <div class="product product-list-sm">
                <figure class="product-media">
                    <a href="view-product.php?product_id='.$row['id'].'">
                        <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product"
                            width="100" height="100">
                    </a>
                </figure>
                <div class="product-details">
                    <h3 class="product-name">
                        <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                    </h3>
                    <div class="product-price">
                        <span class="price">$: '.$row['product_price'].'</span>
                    </div>
                    <div class="ratings-container">
                        <div class="ratings-full">
                            <span class="ratings" style="width:'.$row['product_rating'].'%"></span>
                            <span class="tooltiptext tooltip-top"></span>
                        </div>
                    </div>
                </div>
            </div>';
        }

        echo '<div class="pagination pagination-1 mb-4">';
        $sqli = "SELECT * FROM products WHERE product_rating >=80";
        $resulti = $conn->query($sqli);
        if($resulti->num_rows > 0){
            $total_row = $resulti->num_rows;
            $total_pagination = ceil($total_row / $limit_per_page);
        
            $i=0;
            for($i=1;$i<$total_pagination;$i++){
                echo '<a onclick="Featured('.$i.')">'.$i.'</a>';
            }
        }
        echo '</div>';   
    } 
}


// **************************** Product Shop Pagination Id


if(isset($_REQUEST['product_shop_pagination'])){

    if(isset($_REQUEST['product_shop_pagination_id'])){
        $pagination_id = $_REQUEST['product_shop_pagination_id'];
    }else{
        $pagination_id = 1;
    }
    $limit_per_page = 28;
    $offset = ($pagination_id - 1) * $limit_per_page;

    $limtproduct = 0;
    $sql = "SELECT * FROM products ORDER BY id DESC LIMIT {$offset}, 28";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        WHILE($row = $result->fetch_assoc()){
            $product_image = $row['product_images'];
            $item_image_product = explode(',',$product_image);
            echo '<div class="product-wrap">
            <div class="product shadow-media">
                <figure class="product-media">
                    <a href="view-product.php?product_id='.$row['id'].'">
                        <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product" width="340" style="height:250px;"  height="315">
                    </a>
                    <div class="product-label-group">
                        <label class="product-label label-new">new</label>
                    </div>
                    <div class="product-action-vertical">
                        <a href="#" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
                            data-target="#addCartModal" title="Add to cart"><i
                                class="d-icon-bag"></i></a>
                    </div>
                    <div class="product-action">
                        <a href="#" class="btn-product btn-quickview" title="Quick View">Quick
                            View</a>
                    </div>
                </figure>
                <div class="product-details">
                    <a href="#" onclick="add_wish_cart('.$row['id'].')"  class="btn-wishlist" title="Add to wishlist"><i
                            class="d-icon-heart"></i></a>
                    <div class="product-cat">
                        <a href="shop-grid-3col.html">categories</a>
                    </div>
                    <h3 class="product-name">
                        <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                    </h3>
                    <div class="product-price">
                        <ins class="new-price">$'.$row['product_price'].'</ins><del class="old-price">$210.00</del>
                    </div>
                    <div class="ratings-container">
                        <div class="ratings-full">
                            <span class="ratings" style="width:100%"></span>
                            <span class="tooltiptext tooltip-top"></span>
                        </div>
                        <a href="view-product.php?product_id='.$row['id'].'" class="rating-reviews">( 6 reviews )</a>
                    </div>
                </div>
            </div>
        </div>';
        }
    }

}


// get_review_data()


// Add Review Function


if(isset($_REQUEST['reply_messege'])){
    if(isset($_SESSION['register_login'])){      

        $user_email = $_SESSION['singin_email'];

        $sqlselect = "SELECT * FROM user_reg WHERE user_email = '{$user_email}'";
        $resultselect = $conn->query($sqlselect);
        $row = $resultselect->fetch_assoc();
 
        $user_profile = $row['user_profile'];

        $reply_id = $_REQUEST['reply_id'];
        $reply_messege = $_REQUEST['reply_messege'];
        $reply_name = $_REQUEST['reply_name'];
        $reply_email = $_REQUEST['reply_email'];
        $rating = $_REQUEST['rating'];
        $reply_date =  date("Y.m.d");

        $target = "images/ReviewFiles/";
        $image = $_FILES['ReviewFiles']['name'];
        $filename = implode(",",$image);

        if(!empty($image)){
            foreach($image as $key => $val){
                $targetfilepath = $target . $val;
                move_uploaded_file($_FILES['ReviewFiles']['tmp_name'][$key],$targetfilepath);
              }
              $sql = "INSERT INTO customer_review (product_id,users_name,user_email,user_comment,star_rating,reply_date,user_profile,comment_img) VALUES
              ('$reply_id','$reply_name','$reply_email','$reply_messege','$rating','$reply_date','$user_profile','$filename') ";
              $result = $conn->query($sql);
              if($result){
                  // $updateproduct
                   echo '<alert class="alert text-light alert-success">Successfull Send</alert>';
                  $sqli = "SELECT * FROM customer_review WHERE product_id = {$reply_id}";
                  $resulti = $conn->query($sqli);
                  if($resulti->num_rows > 0){
                      $product_rating = 0;
                      while($rowi = $resulti->fetch_assoc()){
                          $product_rating += $rowi['star_rating'];
                          $total_comments = $resulti->num_rows;
      
                          $total_rating = 5*$total_comments;
                          $rating = ($product_rating/$total_comments)*20;
      
                          $UpdateProductRating = "UPDATE products set product_rating = '$rating', total_cmts = '$total_comments' WHERE id = {$reply_id}";
                          $resultUpdate = $conn->query($UpdateProductRating);
                          if($resultUpdate){
                              
                          }
                      }
                  }
              }
      
        }

      
    }else {
        echo '<script> location.href="login-register.php"; </script>';
    }
}


// *******************
//filter
//****************** 

if(isset($_REQUEST['first_price'])){
   $first_price = $_REQUEST['first_price'];
   $second_price = $_REQUEST['second_price'];



   $sql = "SELECT * FROM products WHERE product_price BETWEEN {$first_price} AND {$second_price}";
   $result = $conn->query($sql);
   if($result->num_rows > 0){
       WHILE($row = $result->fetch_assoc()){
        $product_image = $row['product_images'];
        $item_image_product = explode(',',$product_image);

                echo '<div class="col-md-3 col-6 mb-4">
                <div class="product text-center">
                    <figure class="product-media">
                        <a href="view-product.php?product_id='.$row['id'].'">
                            <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product"
                                width="280" height="315" style="height:245px;">
                        </a>
                        <div class="product-label-group">
                            <label class="product-label label-sale">'.$row['product_discount'].'% off</label>
                        </div>
                        <div class="product-action-vertical">
                        
                            <a href="" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
                                data-target="#addCartModal" title="Add to cart"><i
                                    class="d-icon-bag"></i></a>
                            <a href="#" onclick="add_wish_cart('.$row['id'].')" class="btn-product-icon btn-wishlist"
                                title="Add to wishlist"><i class="d-icon-heart"></i></a>
                        </div>
                        <div class="product-action">
                            <a href="#"  class="btn-product btn-quickview"
                                title="Quick View">Quick View</a>
                        </div>
                    </figure>
                    <div class="product-details">
                        <div class="product-cat">
                            <a href="view-product.php?product_id='.$row['id'].'">categories</a>
                        </div>
                        <h3 class="product-name">
                            <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                        </h3>
                        <div class="product-price">
                            <ins class="new-price">$'.$row['product_price'].'</ins><del
                                class="old-price">$210.00</del>
                        </div>
                        <div class="ratings-container">
                            <div class="ratings-full">
                                <span class="ratings" style="width:100%"></span>
                                <span class="tooltiptext tooltip-top"></span>
                            </div>
                            <a href=""view-product.php?product_id='.$row['id'].'"" class="rating-reviews">( 6 reviews )</a>
                        </div>
                    </div>
                </div>
            </div>';
       }
   }else{
       echo '<div class="alert alert-success text-light">No Record Found</alert>';
   }
}



?>


