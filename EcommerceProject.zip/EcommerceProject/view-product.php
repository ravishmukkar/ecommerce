<?php include('include/header.php'); ?>
		
		<main class="main mt-4">
			<div class="page-content mb-10">
				<div class="container">
					<div class="product product-single row mb-4">


					 <?php 
					   if(isset($_GET['product_id'])){
						   $product_id = $_GET['product_id'];
						   $sql = "SELECT * FROM products WHERE id = '{$product_id}'";
						   $result = $conn->query($sql);
						   $row = $result->fetch_assoc();

						    $product_id = $row['id'];
							$product_name = $row['product_name'];
							$product_sub_text = $row['product_sub_text'];
							$catogry = $row['catogry'];
							$product_status = $row['product_status'];
							$product_description = $row['product_description'];
							$product_price = $row['product_price'];
							$product_discount = $row['product_discount'];
							$meta_title = $row['meta_title'];
							$meta_keyword = $row['meta_keyword'];
							$product_brand = $row['product_brand'];
							$product_color = $row['product_color'];
							$product_matrial= $row['product_matrial'];
							$date_data = $row['date_data'];
							$total_cmts = $row['total_cmts'];
							$product_rating = $row['product_rating'];
                              // Catogry section
							$_GLOBAL['catogry_section'] = $row['catogry_section'];  
						
							$product_images = $row['product_images'];
							$product_item_image = explode(',',$product_images); 
					   }
					 ?>

						<div class="col-md-6">
							<div class="product-gallery">
								<div class="product-single-carousel owl-carousel owl-theme owl-nav-inner row cols-1">
									<figure class="product-image">
										<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[0]; } ?>"
											
											alt="Blue Pinafore Denim Dress" width="800" height="900" style="height:35rem">
									</figure>
									<figure class="product-image">
										<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[1]; } ?>"
											
											alt="Blue Pinafore Denim Dress" width="800" height="900" style="height:35rem">
									</figure>
									<figure class="product-image">
										<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[2]; } ?>"
											
											alt="Blue Pinafore Denim Dress" width="800" height="900" style="height:35rem">
									</figure>
									<figure class="product-image">
										<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[3]; } ?>"
											
											alt="Blue Pinafore Denim Dress" width="800" height="900" style="height:35rem">
									</figure>
									<figure class="product-image">
										<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[4]; } ?>"
											
											alt="Blue Pinafore Denim Dress" width="800" height="900" style="height:35rem">
									</figure>
									<figure class="product-image">
										<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[5]; } ?>"
											
											alt="Blue Pinafore Denim Dress" width="800" height="900" style="height:35rem">
									</figure>
								</div>
								<div class="product-thumbs-wrap">
									<div class="product-thumbs">
										<div class="product-thumb active">
											<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[0]; } ?>"
												alt="product thumbnail" width="137" height="154" style="height:110px;">
										</div>
										<div class="product-thumb">
											<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[1]; } ?>"
												alt="product thumbnail" width="137" height="154" style="height:110px;">
										</div>
										<div class="product-thumb">
											<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[2]; } ?>"
												alt="product thumbnail" width="137" height="154" style="height:110px;">
										</div>
										<div class="product-thumb">
											<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[3]; } ?>"
												alt="product thumbnail" width="137" height="154" style="height:110px;">
										</div>
										<div class="product-thumb">
											<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[4]; } ?>"
												alt="product thumbnail" width="137" height="154" style="height:110px;">
										</div>
										<div class="product-thumb">
											<img src="Admin/ecommerce/images/<?php if(isset($product_item_image)){ echo $product_item_image[5]; } ?>"
												alt="product thumbnail" width="137" height="154" style="height:110px;">
										</div>
									</div>
									<button class="thumb-up disabled"><i class="fas fa-chevron-left"></i></button>
									<button class="thumb-down disabled"><i class="fas fa-chevron-right"></i></button>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="product-details">
								
								<h1 class="product-name"><?php if(isset($product_name)) { echo $product_name; } ?></h1>
								<div class="product-meta">
									SKU: <span class="product-sku">12345670</span>
									BRAND: <span class="product-brand"><?php if(isset($product_brand)) { echo $product_brand; } ?></span>
								</div>
								<div class="product-price">$<?php if(isset($product_price)) { echo $product_price; } ?></div>
								<div class="ratings-container">
									<div class="ratings-full">
										<span class="ratings" style="width:<?php echo $product_rating; ?>%"></span>
										<span class="tooltiptext tooltip-top"></span>
									</div>
									<a href="#product-tab-reviews" class="link-to-tab rating-reviews">( <?php if(isset($total_cmts)){echo $total_cmts;} ?> )</a>
								</div>
								<p class="product-short-desc"><?php if(isset($product_sub_text)) { echo $product_sub_text; } ?>.</p>


								<form action="" method="post" id="addtocart">
								<input type="text" name="product_id_product" value="<?php if(isset($product_id)){ echo $product_id; } ?>">
								<div class="product-form product-size">
									<label>Size:</label>
									<div class="product-form-group">
										<div class="product-variations">
										  <select name="product_size">
										    <option value="small">S</option>
										    <option value="mesium">M</option>
										    <option value="large">L</option>
										    <option value="xtra-large">XL</option>
										    <option value="2xl">2XL</option>
										  </select>
											
										</div>
									</div>
								</div>
								
								<hr class="product-divider">
								<div class="product-form product-qty">
									<label>QTY:</label>
									<div class="product-form-group">
										<div class="input-group">
											<button type="button" class="quantity-minus d-icon-minus"></button>
											<input class="quantity form-control" name="product_quantity" type="number" min="1" max="5">
											<button type="button" class="quantity-plus d-icon-plus"></button>
										</div>
										<button type="submit" class="btn"><i class="d-icon-bag"></i>Add To
											Cart</button>
									</div>
								</div>
				         	</form>	

								<hr class="product-divider mb-3">

								<div class="product-footer">
									<div class="social-links">
										<a href="#" class="social-link social-facebook fab fa-facebook-f"></a>
										<a href="#" class="social-link social-twitter fab fa-twitter"></a>
										<a href="#" class="social-link social-vimeo fab fa-vimeo-v"></a>
									</div>
									<div class="product-action">
										<a href="#" class="btn-product btn-wishlist"><i class="d-icon-heart"></i>Add To
											Wishlist</a>
										<span class="divider"></span>
										
									</div>
								</div>

								<ul class="product-status mt-4 list-type-check list-style-none pl-0">
									<li>Order your pair before 00:00 and receive it between tomorrow - 26th September.
									</li>
									<li>Free worldwide shipping</li>
									<li>Free replenishment service: laces &amp; insoles</li>
								</ul>
							</div>
						</div>
					</div>

					<div class="tab tab-nav-simple product-tabs mb-4">
						<ul class="nav nav-tabs" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" href="#product-tab-description">Description</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="#product-tab-additional">Additional</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="#product-tab-shipping-returns">Shipping &amp; Returns</a>
							</li>
							<?php 
							$sql = "SELECT * FROM customer_review WHERE product_id = '{$product_id}'";
							$result = $conn->query($sql);
							$total_review = $result->num_rows;
							?>
							<li class="nav-item">
								<a class="nav-link" href="#product-tab-reviews">Reviews (<?php echo $total_review; ?>)</a>
							</li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane active in" id="product-tab-description">
								<p>
									<?php 
									  if(isset($product_description)){
										  echo $product_description;
									  }
									?>
								</p>
							</div>
							<div class="tab-pane" id="product-tab-additional">
								<ul class="list-none">
									<li><label>Color:</label>
										<p><?php if(isset($product_color)){ echo $product_color; }?></p>
									</li>
									<li><label>Style:</label>
										<p>Vintage</p>
									</li>
									<li><label>Material:</label>
										<p>PU, Faux Leather</p>
									</li>
									<li><label>Closure Type:</label>
										<p>Hasp</p>
									</li>
									<li><label>Bags Structure:</label>
										<p>Cell phone Pocket, Zipper Pouch</p>
									</li>
									<li><label>Size:</label>
										<p><?php if(isset($product_size)){ echo $product_size; }?></p>
									</li>
									<li><label>Capacity:</label>
										<p>15.6 Inch Laptop</p>
									</li>
								</ul>
							</div>
							<div class="tab-pane " id="product-tab-shipping-returns">
								<h6 class="mb-2">Free Shipping</h6>
								<p class="mb-0">We deliver to over 100 countries around the world. For full details of
									the delivery options we offer, please view our <a href="#"
										class="text-primary">Delivery
										information</a><br />We hope you’ll love every
									purchase, but if you ever need to return an item you can do so within a month of
									receipt. For full details of how to make a return, please view our <br /><a href="#"
										class="text-primary">Returns information</a></p>
							</div>
							<div class="tab-pane " id="product-tab-reviews">
								<div class="d-flex align-items-center mb-5">
									<h4 class="mb-0 mr-2">Average Rating:</h4>
									<div class="ratings-container average-rating mb-0">
										<div class="ratings-full">
											<span class="ratings" style="width:<?php echo $product_rating; ?>%"></span>
											<span class="tooltiptext tooltip-top">4.00</span>
										</div>
									</div>
								</div>

								<div class="comments mb-6">
		
									<ul>

									<?php 
									
									   $sql = "SELECT * FROM customer_review WHERE product_id = '{$product_id}'";
									   $result = $conn->query($sql);
									   if($result->num_rows > 0){
										   WHILE($row = $result->fetch_assoc()){
											   $rating = 20 * ($row['star_rating']);

											   $review_images_string = $row['comment_img'];
							                   $review_images_array = explode(',',$product_images);

											   $arr_size = count($review_images_array);

											
										
                                               echo '<li>
											   <div class="comment">
												   <figure class="comment-media">
													   <a href="#">
														   <img src="images/blog/comments/1.jpg" alt="avatar">
													   </a>
												   </figure>
												   <div class="comment-body">
													   <div class="comment-rating ratings-container mb-0">
														   <div class="ratings-full">
															   <span class="ratings" style="width:'.$rating.'%"></span>
															   <span class="tooltiptext tooltip-top">2.00</span>
														   </div>
													   </div>
													   <div class="comment-user">
														   <h4><a href="#">'.$row['users_name'].'</a></h4>
														   <span class="comment-date">'.$row['reply_date'].'</span>
													   </div>
   
													   <div class="comment-content">
														   <p>'.$row['user_comment'].'</p>
													   </div>
												   </div>
											   </div>';
											   ?>
											   <div class="container"> 
											      <div class="row">
													  <?php 
													   
													   for($i = 0;$i<$arr_size;$i++){
														echo '<div class="product_image col-xl-3 col-3"><img src="images/ReviewFiles/'.$review_images_array[$i].'"></div>';
													   }
													 
													 ?>
												  </div>
											   </div>
											  <?php

										   echo '</li>';
										   }
									   }
									
									?>
									
									</ul>
								</div>
								<!-- End Comments -->
								<div class="reply">
									<div class="title-wrapper text-left">
										<h3 class="title title-simple text-left text-normal">Add a Review</h3>
										<p>Your email address will not be published. Required fields are marked *</p>
									</div>
									<div class="rating-form">
										<label for="rating">Your rating: </label>
										<!-- <span class="rating-stars selected">
											<a class="star-1" href="#">1</a>
											<a class="star-2" href="#">2</a>
											<a class="star-3" href="#">3</a>
											<a class="star-4 active" href="#">4</a>
											<a class="star-5" href="#">5</a>
										</span> -->

										
									</div>
									<form action="" method="POST" id="review_form" >
										<div class="form-group"><input type="file" name="ReviewFiles[]" multiple></div>
										
									<select name="rating"  id="rating" required="" class="form-control mb-1">
											<option value="">Rate…</option>
											<option value="5">Perfect</option>
											<option value="4">Good</option>
											<option value="3">Average</option>
											<option value="2">Not that bad</option>
											<option value="1">Very poor</option>
										</select>

										<textarea id="reply-message" name="reply_messege" cols="30" rows="4" class="form-control mb-4"
											placeholder="Comment *" required></textarea>
										<div class="row">
											<div class="col-md-6 mb-5 d-none">
												<input type="hidden" class="form-control" id="reply-id"
													name="reply_id" value="<?php if(isset($product_id)) echo $product_id; ?>" placeholder="Product Id *" required />
											</div>
											<div class="col-md-6 mb-5">
												<input type="email" class="form-control" id="reply-email"
													name="reply_email" placeholder="Email *" required />
											</div>
											<div class="col-md-6 mb-5">
												<input type="text" class="form-control" id="reply-username"
													name="reply_name" placeholder="Name *" required />
											</div>
										</div>
										<button type="submit" class="btn btn-primary btn-md">Submit<i
												class="d-icon-arrow-right"></i></button>
									</form>
								</div>
								<div id="review_form_alert"></div>
								<!-- End Reply -->
							</div>
						</div>
					</div>

					<section>
						<h2 class="title">Our Featured</h2>

						<div class="owl-carousel owl-theme owl-nav-full row cols-2 cols-md-3 cols-lg-4"
							data-owl-options="{
							'items': 5,
							'nav': false,
							'loop': false,
							'dots': true,
							'margin': 20,
							'responsive': {
								'0': {
									'items': 2
								},
								'768': {
									'items': 3
								},
								'992': {
									'items': 4,
									'dots': false,
									'nav': true
								}
							}
						}">


						 <?php 
						
						 $sql = "SELECT * FROM products WHERE catogry_section = '{$_GLOBAL['catogry_section']}' ORDER BY id DESC LIMIT 0,20";
						 $result = $conn->query($sql);
						 if($result->num_rows > 0){
							 WHILE($row = $result->fetch_assoc()){
								 $product_image = $row['product_images'];
								 $item_image_product = explode(',',$product_image);
								 echo '
		
								 <div class="product shadow-media">
								 <figure class="product-media">
									 <a href="view-product.php?product_id='.$row['id'].'">
										 <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product" width="280" style="height:35rem">
									 </a>
									 <div class="product-label-group">
										 <label class="product-label label-new">new</label>
									 </div>
									 <div class="product-action-vertical">
										 <a href="" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
											 data-target="#addCartModal" title="Add to cart"><i
												 class="d-icon-bag"></i></a>
									 </div>
									 <div class="product-action">
										 <a href="#" class="btn-product btn-quickview" title="Quick View">Quick View</a>
									 </div>
								 </figure>
								 <div class="product-details">
									 <a href="#" onclick="add_wish_cart('.$row['id'].')" class="btn-wishlist" title="Add to wishlist"><i
											 class="d-icon-heart"></i></a>
									 <div class="product-cat">
										 <a href="view-product.php?product_id='.$product_id.'">categories</a>
									 </div>
									 <h3 class="product-name">
										 <a href="view-product.php?product_id='.$product_id.'">'.$row['product_name'].'</a>
									 </h3>
									 <div class="product-price">
										 <ins class="new-price">$'.$row['product_price'].'</ins><del class="old-price"></del>
									 </div>
									 <div class="ratings-container">
										 <div class="ratings-full">
											 <span class="ratings" style="width:'.$row['product_rating'].'%"></span>
											 <span class="tooltiptext tooltip-top"></span>
										 </div>
										 <a href="#" class="rating-reviews">( <span class="review-count">'.$row['total_cmts'].'</span> reviews
											 )</a>
									 </div>
								 </div>
							 </div>';
							 }
							}
						 ?>

						</div>
					</section>
				</div>
			</div>
		</main>
		<!-- End Main -->

		<?php include('include/footer.php'); ?>
