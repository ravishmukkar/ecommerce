<?php
$name =  'ravish';
$hash = password_hash($name, PASSWORD_BCRYPT);

echo $hash;

$verfy = password_verify("ravishw",$hash);
echo '</br>';
echo $verfy;


?>