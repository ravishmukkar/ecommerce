<?php 
include('dbConnection/dbConnection.php'); 

session_start();
if(isset($_SESSION['register_login'])){
	$user_email = $_SESSION['singin_email'];
}else{
	echo "<script> location.href='login-register.php'; </script>";
}

$sql = "SELECT * FROM user_reg WHERE user_email = '{$user_email}'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$first_name = $row['first_name'];
$last_name = $row['last_name'];

$user_name = $row['users_name'];
$user_email = $row['user_email'];
$user_phone = $row['user_mobile'];
$user_pass = $row['user_pass'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

	<title>Mukkar</title>

	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="Donald - Bootstrap eCommerce Template">
	<meta name="author" content="D-THEMES">

	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/icons/favicon.png">

	<script>
		WebFontConfig = {
			google: { families: ['Open+Sans:400,600,700', 'Poppins:400,500,600,700'] }
		};
		(function (d) {
			var wf = d.createElement('script'), s = d.scripts[0];
			wf.src = 'js/webfont.js';
			wf.async = true;
			s.parentNode.insertBefore(wf, s);
		})(document);
	</script>


	<link rel="stylesheet" type="text/css" href="vendor/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.min.css">

	<!-- Plugins CSS File -->
	<link rel="stylesheet" type="text/css" href="vendor/magnific-popup/magnific-popup.min.css">

	<!-- Main CSS File -->
	<link rel="stylesheet" type="text/css" href="css/style.min.css">
</head>

<body>
	<div class="loading-overlay">
		<div class="bounce-loader">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
			<div class="bounce4"></div>
		</div>
	</div>
	<div class="page-wrapper">
	<header class="header">				
		<!-- End HeaderTop -->
			<div class="header-middle sticky-header fix-top sticky-content">
				<div class="container">
					<div class="header-left">
						<a href="#" class="mobile-menu-toggle">
							<i class="d-icon-bars2"></i>
						</a>
					</div>
					<div class="header-center">
						<a href="demo1.html" class="logo">
							<img src="images/logo.png" alt="logo" width="163" height="39" />
						</a>
						<!-- End Logo -->
						<nav class="main-nav">
						<ul class="menu">
                                    <li class="active">
                                        <a href="index.php">Home</a>
                                    </li>
									<li>
                                    <a href="product.html">Products</a>
                                    <div class="megamenu">
                                        <div class="row">

                                        <?php
                                        
                                        $sql = "SELECT * FROM catogry_page";
                                        $result = $conn->query($sql);
                                        if($result->num_rows > 0){
                                            while($row = $result->fetch_assoc()){
                                                echo '<div class="col-4 col-sm-4 col-md-3 col-lg-4">
                                                       <h4 class="menu-title">'.$row['catogry_page'].'</h4>
                                                      <ul>
                                                ';
                                                ?>
                                           <?php 
                                           
                                             $sqli = "SELECT * FROM catogry_item WHERE catogry_page = '{$row['catogry_page']}'";
                                             $resulti = $conn->query($sqli);
                                             if($resulti->num_rows > 0){
                                                 while($rowi = $resulti->fetch_assoc()){
                                                  
                                                   echo '<li><a href="product_shop.php?product_catogry='.$rowi['catogry_item'].'">'.$rowi['catogry_item'].'</a></li>';
                                                 }
                                             } 
                                           
                                           ?>
                                        <?php

                                                echo '</ul></div>';
                                            }
                                        }
                                        
                                        ?>
										</li>
                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <li>
                                        <a href="about-us.html">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                  
                                    <li>
                                        <a href="wishlist.php">Wish Cart</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>
                                </ul>
						</nav>
						<span class="divider"></span>
						<!-- End Divider -->
						<div class="header-search hs-toggle">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End Header Search -->
					</div>
					<div class="header-right">
						<a class="login" href="ajax/login.html">
							<i class="d-icon-user"></i>
							<span>Login</span>
						</a>
						<!-- End Login -->
						<span class="divider"></span>
					
						<div class="dropdown cart-dropdown">
                            <a href="#" class="cart-toggle">
                                <span class="cart-label">
                                    <span class="cart-name">My Cart</span>
                                    <span class="cart-price total_amount"></span>
                                </span>
                                <i class="minicart-icon">
                                    <span class="cart-count count"></span>
                                </i>
                            </a>
                            <!-- End of Cart Toggle -->
                            <div class="dropdown-box">
                                <div class="product product-cart-header">
                                    <span class="product-cart-counts count"> items : </span>
                                    <span><a href="cart.php">View cart</a></span>
                                </div>
                                <div class="products scrollable" id="showcart">

                                   
                                    <!-- End of Cart Product -->
                                       
                                    <!-- End of Cart Product -->
                                </div>
                                <!-- End of Products  -->
                                <div class="cart-total">
                                    <label>Subtotal:</label>
                                    <span class="price total_amount"></span>
                                </div>
                                <!-- End of Cart Total -->
                                <div class="cart-action">
                                    <a href="checkout.php" class="btn btn-dark"><span>Checkout</span></a>
                                </div>
                      
                                <!-- End of Cart Action -->
                            </div>
                            <!-- End of Dropdown Box -->
                        </div>
						<div class="header-search hs-toggle mobile-search">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End of Header Search -->
					</div>
				</div>

			</div>
		</header>
		<!-- End Header -->
		<main class="main order">
			<div class="page-content pt-10 pb-10">
				<div class="step-by pt-2 pb-2 pr-4 pl-4">
					<h3 class="title title-simple title-step visited"><a href="cart.php">1. Shopping Cart</a></h3>
					<h3 class="title title-simple title-step active"><a href="checkout.php">2. Checkout</a></h3>
					<h3 class="title title-simple title-step"><a href="order.php">3. Order Complete</a></h3>
				</div>
				<div class="container mt-8">
					<div class="order-message">
						<i class="fas fa-check"></i>Thank you, <?php if(isset($user_name)){ echo $user_name; } ?> Your order has been received.
					</div>
			</div>
		</main>
	

		<?php include('include/footer.php'); ?>