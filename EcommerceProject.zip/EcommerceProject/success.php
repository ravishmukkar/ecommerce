<?php

include('dbConnection/dbConnection.php');
$user_ip = getUserIp();
if(isset($_REQUEST['user_name']))
{
    $sql = "SELECT * FROM addtocart WHERE user_ip = '{$user_ip}'";
    $resultitem = $conn->query($sql);
    if($resultitem->num_rows > 0){
    WHILE($row = $resultitem->fetch_assoc()){
    $product_id = $row['product_id'];
    $product_name = $row['product_name'];
    $product_quantity = $row['product_quantity'];
    $product_size = $row['product_size'];
    $product_price = $row['product_price'];
    $product_images = $row['product_images'];

    $user_name = $_REQUEST['user_name'];
    $user_email = $_REQUEST['user_email'];
    $first_name = $_REQUEST['first_name'];
    $last_name = $_REQUEST['last_name'];
    $company_name = $_REQUEST['company_name'];
    $country = $_REQUEST['country'];
    $address1 = $_REQUEST['address1'];
    $address2 = $_REQUEST['address2'];
    $city = $_REQUEST['city'];
    $district = $_REQUEST['district'];
    $state = $_REQUEST['state'];
    $postcode = $_REQUEST['postcode'];
    $phone = $_REQUEST['phone'];
    $email_address = $_REQUEST['email_address'];
    $other_notes = $_REQUEST['other_notes'];
    $today_date = date("Y.m.d"); 
    $delivery_status = "Processing";
    // echo $_REQUEST['user_name'];



    $sqlcheckout = "INSERT INTO place_order (product_id,product_name,product_quantity,
    product_size,product_price,product_images,users_name,user_email,first_name,
    last_name,company_name,country,street_adress1,street_adress2,town,district,
    user_state,postcode,phone,email_adress,other_notes,today_date,user_ip,delivery_status) 
    VALUES ('$product_id','$product_name','$product_quantity','$product_size','$product_price','$product_images',
    '$user_name','$user_email','$first_name','$last_name','$company_name','$country','$address1','$address2','$city','$district','$state','$postcode',
    '$phone','$email_address','$other_notes','$today_date','$user_ip','$delivery_status')";
    $result = $conn->query($sqlcheckout );

    if($result){
        echo "<script> location.href='order.php'; </script>";


        $delete = "DELETE FROM addtocart WHERE user_ip = '$user_ip'";
        $resultdelete = $conn->query($delete);


        }
      }
    }
}
?>