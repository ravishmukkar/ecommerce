<?php

include('dbConnection/dbConnection.php');

$user_ip = getUserIp();

 session_start();
 session_destroy();

if(!isset($_REQUEST['register_login'])){
    $delete = "DELETE FROM addtocart WHERE user_ip = '$user_ip'";
    $resultdelete = $conn->query($delete);
}

 echo "<script> location.href='index.php'; </script>";
?>