<?php include('dbConnection/dbConnection.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

	<title>Donald - Bootstrap eCommerce Template</title>

	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="Donald - Bootstrap eCommerce Template">
	<meta name="author" content="D-THEMES">

	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/icons/favicon.png">

	<script>
		WebFontConfig = {
			google: { families: ['Open+Sans:400,600,700', 'Poppins:400,500,600,700'] }
		};
		(function (d) {
			var wf = d.createElement('script'), s = d.scripts[0];
			wf.src = 'js/webfont.js';
			wf.async = true;
			s.parentNode.insertBefore(wf, s);
		})(document);
	</script>


	<link rel="stylesheet" type="text/css" href="vendor/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.min.css">

	<!-- Plugins CSS File -->
	<link rel="stylesheet" type="text/css" href="vendor/magnific-popup/magnific-popup.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/nouislider/nouislider.min.css">

	<!-- Main CSS File -->
	<link rel="stylesheet" type="text/css" href="css/style.min.css">
</head>

<body>
	<div class="loading-overlay">
		<div class="bounce-loader">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
			<div class="bounce4"></div>
		</div>
	</div>
	<div class="page-wrapper">
	
	<header class="header">				
		<!-- End HeaderTop -->
			<div class="header-middle sticky-header fix-top sticky-content">
				<div class="container">
					<div class="header-left">
						<a href="#" class="mobile-menu-toggle">
							<i class="d-icon-bars2"></i>
						</a>
					</div>
					<div class="header-center">
						<a href="index.php" class="logo">
							<img src="images/logo.png" alt="logo" width="163" height="39" />
						</a>
						<!-- End Logo -->
						<nav class="main-nav">
						<ul class="menu">
                                    <li class="active">
                                        <a href="index.php">Home</a>
                                    </li>
                                    <li>
                                        <a href="index.php">Categories</a>
                                        <div class="megamenu">
                                            <div class="row">
                                                <div class="col-6 col-sm-4 col-md-4 col-lg-4">
                                                    <h4 class="menu-title">Variations 1</h4>
                                                    <ul>
                                                    <?php
                                                            $sql = "SELECT * FROM cloth_catogry";
                                                            $result = $conn->query($sql);
                                                            if($result->num_rows > 0){
                                                                while ($row = $result->fetch_assoc()) {
                                                                    # code...
                                                                    if(!empty($row['cloth_catogry'])){
                                                                        echo ' <li><a href="product_shop.php?product_catogry='.$row['cloth_catogry'].'"><i class="d-icon-camera1"></i>'.$row['cloth_catogry'].'</a></li>';
                                                                    }
                                                                }
                                                            }
                                                        ?>
                                                    </ul>
                                                </div>
                                               
                                                <div
                                                    class="col-6 col-sm-4 col-md-4 col-lg-4 menu-banner menu-banner1 banner banner-fixed">
                                                    <figure>
                                                        <img src="images/menu/banner-1.jpg" alt="Menu banner"
                                                            width="221" height="330" />
                                                    </figure>
                                                    <div class="banner-content y-50">
                                                        <h4 class="banner-subtitle font-weight-bold text-primary ls-m">
                                                            Sale.
                                                        </h4>
                                                        <h3 class="banner-title font-weight-bold"><span
                                                                class="text-uppercase">Up to</span>70% Off</h3>
                                                        <a href="#" class="btn btn-link btn-underline">shop now<i
                                                                class="d-icon-arrow-right"></i></a>
                                                    </div>
                                                </div>
                                                <!-- End of Megamenu -->
                                            </div>
                                        </div>
                                    </li>
                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <li>
                                        <a href="about-us.html">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                  
                                    <li>
                                        <a href="wishlist.php">Wish Cart</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>
									</ul>
						</nav>
						<span class="divider"></span>
						<!-- End Divider -->
						<div class="header-search hs-toggle">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="#" class="input-wrapper">
								<input type="text" class="form-control" name="search" id="searchproduct" autocomplete="off"
									placeholder="Search your keyword..." required />
								<button class="btn btn-search" type="submit">
									<i class="d-icon-search"></i>
								</button>
							</form>
						</div>
						<!-- End Header Search -->
					</div>
					<div class="header-right">
						<a class="login" href="ajax/login.html">
							<i class="d-icon-user"></i>
							<span>Login</span>
						</a>
						<!-- End Login -->
						<span class="divider"></span>
					
						<div class="dropdown cart-dropdown">
                            <a href="#" class="cart-toggle">
                                <span class="cart-label">
                                    <span class="cart-name">My Cart</span>
                                    <span class="cart-price total_amount"></span>
                                </span>
                                <i class="minicart-icon">
                                    <span class="cart-count count"></span>
                                </i>
                            </a>
                            <!-- End of Cart Toggle -->
                            <div class="dropdown-box">
                                <div class="product product-cart-header">
                                    <span class="product-cart-counts count"> items : </span>
                                    <span><a href="cart.php">View cart</a></span>
                                </div>
                                <div class="products scrollable" id="showcart">

                                   
                                    <!-- End of Cart Product -->
                                       
                                    <!-- End of Cart Product -->
                                </div>
                                <!-- End of Products  -->
                                <div class="cart-total">
                                    <label>Subtotal:</label>
                                    <span class="price total_amount"></span>
                                </div>
                                <!-- End of Cart Total -->
                                <div class="cart-action">
                                    <a href="checkout.php" class="btn btn-dark"><span>Checkout</span></a>
                                </div>
                      
                                <!-- End of Cart Action -->
                            </div>
                            <!-- End of Dropdown Box -->
                        </div>
						<div class="header-search hs-toggle mobile-search">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="#" class="input-wrapper">
								<input type="text" class="form-control" name="search" autocomplete="off"
									placeholder="Search your keyword..." required />
								<button class="btn btn-search" type="submit">
									<i class="d-icon-search"></i>
								</button>
							</form>
						</div>
						<!-- End of Header Search -->
					</div>
				</div>

			</div>
		</header>
		<!-- End Header -->
		<main class="main">
			<div class="page-header bg-dark"
				style="background-image: url('images/shop/page-header-back.jpg'); background-color: #3C63A4;">
				<h3 class="page-subtitle">Categories</h3>
				<h1 class="page-title">Grid 7 Columns</h1>
				<ul class="breadcrumb">
					<li><a href="index.php"><i class="d-icon-home"></i></a></li>
					<li><a href="shop.html">Categories</a></li>
					<li>Grid 7 Columns</li>
				</ul>
			</div>
			<!-- End PageHeader -->
			<div class="page-content mb-10">
				<div class="container-fluid">
					<div class="main-content">
						<nav class="toolbox sticky-toolbox sticky-content fix-top">
							<div class="toolbox-left">
								<a href="#"
									class="left-sidebar-toggle toolbox-item btn btn-sm btn-outline btn-primary">Filters<i
										class="d-icon-arrow-right"></i></a>
								<div class="toolbox-item toolbox-sort select-box">
									<label>Sort By :</label>
									<select name="orderby" class="form-control">
										<option value="default">Default</option>
										<option value="popularity" selected="selected">Most Popular</option>
										<option value="rating">Average rating</option>
										<option value="date">Latest</option>
										<option value="price-low">Sort forward price low</option>
										<option value="price-high">Sort forward price high</option>
										<option value="">Clear custom sort</option>
									</select>
								</div>
								
							</div>
							<div class="toolbox-right">
								<div class="toolbox-item toolbox-show select-box">
									<label>Show :</label>
									<select name="count" class="form-control">
										<option value="12">12</option>
										<option value="24">24</option>
										<option value="36">36</option>
									</select>
								</div>
								
							</div>
						</nav>

						<div class="row cols-2 cols-sm-3 cols-md-4 cols-lg-5 cols-xl-7 product-wrapper" id="get_shop_product">

						  <?php
						   if(isset($_GET['product_catogry'])){
							   $product_catogry = $_GET['product_catogry'];
							   $sql = "SELECT * FROM products WHERE catogry = '{$product_catogry}' ORDER BY id DESC LIMIT 0, 28";
							   $result = $conn->query($sql);
							   if($result->num_rows > 0){
								   WHILE($row = $result->fetch_assoc()){
									$product_image = $row['product_images'];
									$item_image_product = explode(',',$product_image);
                                       echo '<div class="product-wrap">
									   <div class="product shadow-media">
										   <figure class="product-media">
											   <a href="view-product.php?product_id='.$row['id'].'">
												   <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product" width="340" style="height:250px;" >
											   </a>
											   <div class="product-label-group">
												   <label class="product-label label-new">new</label>
											   </div>
											   <div class="product-action-vertical">
												   <a href="#" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
													   data-target="#addCartModal" title="Add to cart"><i
														   class="d-icon-bag"></i></a>
											   </div>
											   <div class="product-action">
												   <a href="#" class="btn-product btn-quickview" title="Quick View">Quick
													   View</a>
											   </div>
										   </figure>
										   <div class="product-details">
											   <a href="#" onclick="add_wish_cart('.$row['id'].')"  class="btn-wishlist" title="Add to wishlist"><i
													   class="d-icon-heart"></i></a>
											   <div class="product-cat">
												   <a href="shop-grid-3col.html">categories</a>
											   </div>
											   <h3 class="product-name">
												   <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
											   </h3>
											   <div class="product-price">
												   <ins class="new-price">$'.$row['product_price'].'</ins><del class="old-price">$210.00</del>
											   </div>
											   <div class="ratings-container">
												   <div class="ratings-full">
													   <span class="ratings" style="width:100%"></span>
													   <span class="tooltiptext tooltip-top"></span>
												   </div>
												   <a href="view-product.php?product_id='.$row['id'].'" class="rating-reviews">( 6 reviews )</a>
											   </div>
										   </div>
									   </div>
								   </div>';
								   }
							   }
						   } else if(isset($_REQUEST['search'])){
							$search = $_REQUEST['search'];
							$sql = "SELECT * FROM products WHERE product_name LIKE '%{$search}%' || meta_title LIKE '%{$search}%' || meta_keyword LIKE '%{$search}%' ||
							 product_sub_text LIKE '%{$search}%' || product_description LIKE '%{$search}%'
							";
							$result = $conn->query($sql);
							if($result->num_rows > 0){
								WHILE($row = $result->fetch_assoc()){
									$product_image = $row['product_images'];
									$item_image_product = explode(',',$product_image);
									echo '<div class="product-wrap">
									<div class="product shadow-media">
										<figure class="product-media">
											<a href="view-product.php?product_id='.$row['id'].'">
												<img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product" width="340" style="height:250px;"  height="315">
											</a>
											<div class="product-label-group">
												<label class="product-label label-new">new</label>
											</div>
											<div class="product-action-vertical">
												<a href="#" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
													data-target="#addCartModal" title="Add to cart"><i
														class="d-icon-bag"></i></a>
											</div>
											<div class="product-action">
												<a href="#" class="btn-product btn-quickview" title="Quick View">Quick
													View</a>
											</div>
										</figure>
										<div class="product-details">
											<a href="#" onclick="add_wish_cart('.$row['id'].')"  class="btn-wishlist" title="Add to wishlist"><i
													class="d-icon-heart"></i></a>
											<div class="product-cat">
												<a href="shop-grid-3col.html">categories</a>
											</div>
											<h3 class="product-name">
												<a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
											</h3>
											<div class="product-price">
												<ins class="new-price">$'.$row['product_price'].'</ins><del class="old-price">$210.00</del>
											</div>
											<div class="ratings-container">
												<div class="ratings-full">
													<span class="ratings" style="width:100%"></span>
													<span class="tooltiptext tooltip-top"></span>
												</div>
												<a href="view-product.php?product_id='.$row['id'].'" class="rating-reviews">( 6 reviews )</a>
											</div>
										</div>
									</div>
								</div>';
								}
							}
						   }else if(isset($_GET['section_catogry'])){
						   $section_catogry = $_GET['section_catogry'];
						   $sql = "SELECT * FROM products WHERE catogry_section = '{$section_catogry}'";
						   $result = $conn->query($sql);
						   if($result->num_rows > 0){
							   WHILE($row = $result->fetch_assoc()){
								   $product_image = $row['product_images'];
								   $item_image_product = explode(',',$product_image);
								   echo '<div class="product-wrap">
								   <div class="product shadow-media">
									   <figure class="product-media">
										   <a href="view-product.php?product_id='.$row['id'].'">
											   <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product" width="340" style="height:250px;"  height="315">
										   </a>
										   <div class="product-label-group">
											   <label class="product-label label-new">new</label>
										   </div>
										   <div class="product-action-vertical">
											   <a href="#" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
												   data-target="#addCartModal" title="Add to cart"><i
													   class="d-icon-bag"></i></a>
										   </div>
										   <div class="product-action">
											   <a href="#" class="btn-product btn-quickview" title="Quick View">Quick
												   View</a>
										   </div>
									   </figure>
									   <div class="product-details">
										   <a href="#" onclick="add_wish_cart('.$row['id'].')"  class="btn-wishlist" title="Add to wishlist"><i
												   class="d-icon-heart"></i></a>
										   <div class="product-cat">
											   <a href="shop-grid-3col.html">categories</a>
										   </div>
										   <h3 class="product-name">
											   <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
										   </h3>
										   <div class="product-price">
											   <ins class="new-price">$'.$row['product_price'].'</ins><del class="old-price">$210.00</del>
										   </div>
										   <div class="ratings-container">
											   <div class="ratings-full">
												   <span class="ratings" style="width:100%"></span>
												   <span class="tooltiptext tooltip-top"></span>
											   </div>
											   <a href="view-product.php?product_id='.$row['id'].'" class="rating-reviews">( 6 reviews )</a>
										   </div>
									   </div>
								   </div>
							   </div>';
						   }
						 }
						}else{
							$sql = "SELECT * FROM products ORDER BY id DESC LIMIT 0, 28";
							$result = $conn->query($sql);
							if($result->num_rows > 0){
								WHILE($row = $result->fetch_assoc()){
									$product_image = $row['product_images'];
									$item_image_product = explode(',',$product_image);
									echo '<div class="product-wrap">
									<div class="product shadow-media">
										<figure class="product-media">
											<a href="view-product.php?product_id='.$row['id'].'">
												<img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product" width="340" style="height:250px;"  height="315">
											</a>
											<div class="product-label-group">
												<label class="product-label label-new">new</label>
											</div>
											<div class="product-action-vertical">
												<a href="#" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
													data-target="#addCartModal" title="Add to cart"><i
														class="d-icon-bag"></i></a>
											</div>
											<div class="product-action">
												<a href="#" class="btn-product btn-quickview" title="Quick View">Quick
													View</a>
											</div>
										</figure>
										<div class="product-details">
											<a href="#" onclick="add_wish_cart('.$row['id'].')"  class="btn-wishlist" title="Add to wishlist"><i
													class="d-icon-heart"></i></a>
											<div class="product-cat">
												<a href="shop-grid-3col.html">categories</a>
											</div>
											<h3 class="product-name">
												<a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
											</h3>
											<div class="product-price">
												<ins class="new-price">$'.$row['product_price'].'</ins><del class="old-price">$210.00</del>
											</div>
											<div class="ratings-container">
												<div class="ratings-full">
													<span class="ratings" style="width:100%"></span>
													<span class="tooltiptext tooltip-top"></span>
												</div>
												<a href="view-product.php?product_id='.$row['id'].'" class="rating-reviews">( 6 reviews )</a>
											</div>
										</div>
									</div>
								</div>';
								}
							 }
							}
						  ?>

							
						
							
						</div>
						<nav class="toolbox toolbox-pagination">
							<p class="show-info">Showing <span>12 of 56</span> Products</p>
							<ul class="pagination">
								<li class="page-item disabled">
									<a class="page-link page-link-prev" href="#" aria-label="Previous" tabindex="-1"
										aria-disabled="true">
										<i class="d-icon-arrow-left"></i>Prev
									</a>
								</li>
								<li class="page-item active" aria-current="page"><a class="page-link" href="#">1</a>
								</li>
								<li class="page-item"><a class="page-link" href="#">2</a></li>
								<li class="page-item"><a class="page-link" href="#">3</a></li>
								<li class="page-item page-item-dots"><a class="page-link" href="#">6</a></li>
								<li class="page-item">
									<a class="page-link page-link-next" href="#" aria-label="Next">
										Next<i class="d-icon-arrow-right"></i>
									</a>
								</li>
							</ul>
						</nav>
					</div>
					<aside class="col-lg-3 sidebar shop-sidebar">
						<div class="sidebar-overlay">
							<a class="sidebar-close" href="#"><i class="d-icon-times"></i></a>
						</div>
						<div class="sidebar-content">
							<div class="filter-actions">
								<a href="#" class="sidebar-toggle-btn btn btn-sm btn-outline btn-primary">Filters<i
										class="d-icon-arrow-left"></i></a>
								<a href="#" class="filter-clean text-primary">Clean All</a>
							</div>
							<div class="widget widget-collapsible">
								<h3 class="widget-title">All Categories</h3>
								<ul class="widget-body filter-items search-ul">
							   	<?php
									$sql = "SELECT * FROM cloth_catogry";
									$result = $conn->query($sql);
									if($result->num_rows > 0){
										while ($row = $result->fetch_assoc()) {
											# code...
											if(!empty($row['cloth_catogry'])){
												echo '<li><a href="product_shop.php?product_catogry='.$row['cloth_catogry'].'">'.$row['cloth_catogry'].'</a></li>';
											}
										}
									}
								?>
									
								
								</ul>
							</div>
							<div class="widget widget-collapsible">
								<h3 class="widget-title">Price</h3>
								<div class="widget-body">
									<form action="#">
										<div class="filter-price-slider"></div>

										<div class="filter-actions">
											<button type="button" onclick="searchbyamount()" class="btn btn-sm btn-primary">Filter</button>

											<div class="filter-price-text">Price INR:
												<span class="filter-price-range"></span>
											</div>
										</div>
									</form><!-- End Filter Price Form -->
								</div>
							</div>
							<div class="widget widget-collapsible">
								<h3 class="widget-title">Size</h3>
								<ul class="widget-body filter-items">
									<li><a href="#">Small<span>(2)</span></a></li>
									<li><a href="#">Medium<span>(1)</span></a></li>
									<li><a href="#">Large<span>(9)</span></a></li>
									<li><a href="#">Extra Large<span>(1)</span></a></li>
								</ul>
							</div>
							<div class="widget widget-collapsible">
								<h3 class="widget-title">Color</h3>
								<ul class="widget-body filter-items">
									<li><a href="ravi.html">Black<span></span></a></li>
									<li><a href="#">Blue<span></span></a></li>
									<li><a href="#">Green<span></span></a></li>
								</ul>
							</div>
						
							<div class="widget widget-products mt-2">
								<h4 class="widget-title">Our Featured</h4>
								<div class="widget-body">
									<div class="owl-carousel owl-nav-top row cols-1" data-owl-options="{
										'items': 1,
										'loop': true,
										'nav': true,
										'dots': false,
										'margin': 20
									}">
										<div class="products-col">
											<div class="product product-list-sm">
												<figure class="product-media">
													<a href="view-product.php?product_id='.$row['id'].'">
														<img src="images/shop/product-widget1.jpg" alt="product"
															width="100" height="100">
													</a>
												</figure>
												<div class="product-details">
													<h3 class="product-name">
														<a href="view-product.php?product_id='.$row['id'].'">Daisy Bag Sonia by Sonia Rykiel</a>
													</h3>
													<div class="product-price">
														<span class="price">$'.$row['product_price'].'</span>
													</div>
													<div class="ratings-container">
														<div class="ratings-full">
															<span class="ratings" style="width:100%"></span>
															<span class="tooltiptext tooltip-top"></span>
														</div>
													</div>
												</div>
											</div>
											<div class="product product-list-sm">
												<figure class="product-media">
													<a href="view-product.php?product_id='.$row['id'].'">
														<img src="images/shop/product-widget2.jpg" alt="product"
															width="100" height="100">
													</a>
												</figure>
												<div class="product-details">
													<h3 class="product-name">
														<a href="view-product.php?product_id='.$row['id'].'">Osaka Entry Tee Supery</a>
													</h3>
													<div class="product-price">
														<span class="price">$19.00</span>
													</div>
													<div class="ratings-container">
														<div class="ratings-full">
															<span class="ratings" style="width:100%"></span>
															<span class="tooltiptext tooltip-top"></span>
														</div>
													</div>
												</div>
											</div>
											<div class="product product-list-sm">
												<figure class="product-media">
													<a href="view-product.php?product_id='.$row['id'].'">
														<img src="images/shop/product-widget3.jpg" alt="product"
															width="100" height="100">
													</a>
												</figure>
												<div class="product-details">
													<h3 class="product-name">
														<a href="view-product.php?product_id='.$row['id'].'">Pima SS O-Neck NOOS Selected Homme</a>
													</h3>
													<div class="product-price">
														<ins class="new-price">$99.00</ins><del
															class="old-price">$150.00</del>
													</div>
													<div class="ratings-container">
														<div class="ratings-full">
															<span class="ratings" style="width:100%"></span>
															<span class="tooltiptext tooltip-top"></span>
														</div>
													</div>
												</div>
											</div>
										</div><!-- End Products Col -->
										<div class="products-col">
											<div class="product product-list-sm">
												<figure class="product-media">
													<a href="view-product.php?product_id='.$row['id'].'">
														<img src="images/shop/product-widget1.jpg" alt="product"
															width="100" height="100">
													</a>
												</figure>
												<div class="product-details">
													<h3 class="product-name">
														<a href="view-product.php?product_id='.$row['id'].'">Daisy Bag Sonia by Sonia Rykiel</a>
													</h3>
													<div class="product-price">
														<span class="price">$'.$row['product_price'].'</span>
													</div>
													<div class="ratings-container">
														<div class="ratings-full">
															<span class="ratings" style="width:100%"></span>
															<span class="tooltiptext tooltip-top"></span>
														</div>
													</div>
												</div>
											</div>
											<div class="product product-list-sm">
												<figure class="product-media">
													<a href="view-product.php?product_id='.$row['id'].'">
														<img src="images/shop/product-widget2.jpg" alt="product"
															width="100" height="100">
													</a>
												</figure>
												<div class="product-details">
													<h3 class="product-name">
														<a href="view-product.php?product_id='.$row['id'].'">Osaka Entry Tee Supery</a>
													</h3>
													<div class="product-price">
														<span class="price">$19.00</span>
													</div>
													<div class="ratings-container">
														<div class="ratings-full">
															<span class="ratings" style="width:100%"></span>
															<span class="tooltiptext tooltip-top"></span>
														</div>
													</div>
												</div>
											</div>
											<div class="product product-list-sm">
												<figure class="product-media">
													<a href="view-product.php?product_id='.$row['id'].'">
														<img src="images/shop/product-widget3.jpg" alt="product"
															width="100" height="100">
													</a>
												</figure>
												<div class="product-details">
													<h3 class="product-name">
														<a href="view-product.php?product_id='.$row['id'].'">Pima SS O-Neck NOOS Selected Homme</a>
													</h3>
													<div class="product-price">
														<ins class="new-price">$99.00</ins><del
															class="old-price">$150.00</del>
													</div>
													<div class="ratings-container">
														<div class="ratings-full">
															<span class="ratings" style="width:100%"></span>
															<span class="tooltiptext tooltip-top"></span>
														</div>
													</div>
												</div>
											</div>
										</div><!-- End Products Col -->
									</div>
								</div>
							</div>
						</div>
					</aside>
				</div>
			</div>
		</main>
		<!-- End Main -->










<?php include('include/footer.php'); ?>

    
	