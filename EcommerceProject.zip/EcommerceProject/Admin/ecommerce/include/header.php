<?php

include('../../dbConnection/dbConnection.php'); 
session_start();
if(isset($_SESSION['admin_login'])){
	$admin_email = $_SESSION['admin_email'];
}else{
	echo '<script> location.href="admin_login.php"; </script>';
}

$sql = "SELECT * FROM admin_login";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$first_name = $row['first_name'];
$last_name = $row['last_name'];
$admin_user_name = $row['admin_user_name'];

$password = $row['admin_password'];
$admin_profile_image = $row['admin_profile_image'];

?>

<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="https://www.multipurposethemes.com/admin/master-admin-template/images/favicon.ico">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Dashboard</title>
    
	<!-- Vendors Style-->
	<link rel="stylesheet" href="css/vendors_css.css">
	  
	<!-- Style-->  
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/skin_color.css">
      
  </head>

<body class="hold-transition light-skin sidebar-mini theme-primary fixed">
	
<div class="wrapper">

  <header class="main-header">
	<div class="d-flex align-items-center logo-box justify-content-between">
		<a href="#" class="waves-effect waves-light nav-link rounded d-none d-md-inline-block mx-10 push-btn" data-toggle="push-menu" role="button">
			<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/collapse.svg" class="img-fluid svg-icon" alt="">
		</a>	
		<!-- Logo -->
		<a href="dashboared.php" class="logo">
		  <!-- logo-->
		  <div class="logo-lg">
			  <span class="light-logo"><img src="../images/logo-dark-text.png" alt="logo"></span>
			  <span class="dark-logo"><img src="../images/logo-light-text.png" alt="logo"></span>
		  </div>
		</a>	
	</div>  
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top pl-10">
      <!-- Sidebar toggle button-->
	  <div class="app-menu">
		<ul class="header-megamenu nav">
			<!-- <li class="btn-group nav-item d-md-none">
				<a href="#" class="waves-effect waves-light nav-link rounded push-btn" data-toggle="push-menu" role="button">
					 <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/collapse.svg" class="img-fluid svg-icon" alt=""> 
			    </a>
			</li>
			<li class="btn-group nav-item d-none d-lg-inline-block">
				<a href="contact_app_chat.html" class="waves-effect waves-light nav-link rounded svg-bt-icon" title="">
				 <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/sms.svg" class="img-fluid svg-icon" alt="">
			    </a>
			</li>
			<li class="btn-group nav-item d-none d-lg-inline-block">
				<a href="#" class="waves-effect waves-light nav-link rounded svg-bt-icon" title="">
					 <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/sidebar-menu/mailbox.svg" class="img-fluid svg-icon" alt=""> 
			    </a>
			</li>
			<li class="btn-group nav-item d-none d-lg-inline-block">
				<a href="#" class="waves-effect waves-light nav-link rounded svg-bt-icon" title="">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/correct.svg" class="img-fluid svg-icon" alt="">
			    </a>
			</li>
			<li class="btn-group nav-item d-none d-lg-inline-block">
				<a href="extra_calendar.html" class="waves-effect waves-light nav-link rounded svg-bt-icon" title="">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/event.svg" class="img-fluid svg-icon" alt="">
			    </a>
			</li>
			<li class="btn-group nav-item d-none d-lg-inline-block">
				<a href="#" class="waves-effect waves-light nav-link rounded svg-bt-icon" title="">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/star.svg" class="img-fluid svg-icon" alt="">
			    </a>
			</li> -->
		</ul> 
	  </div>
		
      <div class="navbar-custom-menu r-side">
        <ul class="nav navbar-nav">	
			<li class="btn-group nav-item">
				<a href="#" data-provide="fullscreen" class="waves-effect waves-light nav-link rounded full-screen" title="Full Screen">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/fullscreen.svg" class="img-fluid svg-icon" alt="">
			    </a>
			</li>	  
			<li class="btn-group d-lg-inline-flex d-none">
				<div class="app-menu">
					<div class="search-bx mx-5">
						<form>
							<div class="input-group">
							  <input type="search" class="form-control" placeholder="Search" aria-label="Search" aria-describedby="button-addon2">
							  <div class="input-group-append">
								<button class="btn" type="submit" id="button-addon3"><img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/search.svg" class="img-fluid" alt="search"></button>
							  </div>
							</div>
						</form>
					</div>
				</div>
			</li>
		  <!-- Notifications -->
		  <li class="dropdown notifications-menu">
			<a href="#" class="waves-effect waves-light dropdown-toggle" data-toggle="dropdown" title="Notifications">
			  <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/notifications.svg" class="img-fluid svg-icon" alt="">
			</a>
			<ul class="dropdown-menu animated bounceIn">

			  <li class="header">
				<div class="p-20">
					<div class="flexbox">
						<div>
							<h4 class="mb-0 mt-0">Notifications</h4>
						</div>
						<div>
							<a href="#" class="text-danger">Clear All</a>
						</div>
					</div>
				</div>
			  </li>

			  <li>
				<!-- inner menu: contains the actual data -->
				<ul class="menu sm-scrol" id="get_notification">
				 
				 
				</ul>
			  </li>
			  <li class="footer">
				  <a href="#">View all</a>
			  </li>
			</ul>
		  </li>	
		  
	      <!-- User Account-->
          <li class="dropdown user user-menu">
            <a href="#" class="waves-effect waves-light dropdown-toggle" data-toggle="dropdown" title="User">
				<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/user.svg" class="rounded svg-icon" alt="" />
            </a>
            <ul class="dropdown-menu animated flipInX">
              <!-- User image -->
              <li class="user-header bg-img" style="background-image: url(../images/user-info.jpg)" data-overlay="3">
				  <div class="flexbox align-self-center">					  
				  	<img src="../images/avatar/7.jpg" class="float-left rounded-circle" alt="User Image">					  
					<h4 class="user-name align-self-center">
					  <span>Samuel Brus</span>
					  <small>samuel@gmail.com</small>
					</h4>
				  </div>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
				    <a class="dropdown-item" href="javascript:void(0)"><i class="ion ion-person"></i> My Profile</a>
					<a class="dropdown-item" href="javascript:void(0)"><i class="ion ion-bag"></i> My Balance</a>
					<a class="dropdown-item" href="javascript:void(0)"><i class="ion ion-email-unread"></i> Inbox</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="javascript:void(0)"><i class="ion ion-settings"></i> Account Setting</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="javascript:void(0)"><i class="ion-log-out"></i> Logout</a>
					<div class="dropdown-divider"></div>
					<div class="p-10"><a href="javascript:void(0)" class="btn btn-sm btn-rounded btn-success">View Profile</a></div>
              </li>
            </ul>
          </li>	
		  
          <!-- Control Sidebar Toggle Button -->
          <li>
              <a href="#" data-toggle="control-sidebar" title="Setting" class="waves-effect waves-light">
			  	<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/settings.svg" class="img-fluid svg-icon" alt="">
			  </a>
          </li>
			
        </ul>
      </div>
    </nav>
  </header>
  
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar position-relative">	
	    <div class="user-profile px-30 py-15">
			<div class="d-flex align-items-center">			
				<div class="image">
				  <img src="<?php if(isset($admin_profile_image)){echo $admin_profile_image;} ?>" class="avatar avatar-lg" alt="User Image">
				</div>
				<div class="info ml-10">
					<p class="mb-0">Welcome</p>
					<h5 class="mb-0"><?php if(isset($first_name)){echo $first_name;} if(isset($last_name)){echo $last_name;} ?></h5>
				</div>
			</div>
        </div>
	  <div class="multinav">
		  <div class="multinav-scroll" style="height: 100%;">
			  <!-- sidebar menu-->
			  <ul class="sidebar-menu" data-widget="tree">
				<li>
				  <a href="dashboared.php">
				  <i class="fa fa-tachometer" aria-hidden="true"></i>
					<!-- <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/dashboard.svg" class="svg-icon" alt=""> -->
					<span>Overview</span>
				  </a>
				</li>
				<!-- <li>
				  <a href="sales.html">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/ecommerce.svg" class="svg-icon" alt="">
					<span>Sales</span>
				  </a>
				</li>
				<li>
				  <a href="members.html">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/user.svg" class="svg-icon" alt="">
					<span>Members</span>
				  </a>
				</li> -->
				<!-- <li>
				  <a href="analysis.html">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/chart.svg" class="svg-icon" alt="">
					<span>Analysis</span>
				  </a>
				</li>
				<li>
				  <a href="post.php">
					<img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/dashboard.svg" class="svg-icon" alt="">
					<span>Post</span>
				  </a>
				</li> -->
				<li class="header">PRODUCTS SECTION</li>
				<li>
				  <a href="add_products.php">
				  <i class="fa fa-product-hunt" aria-hidden="true"></i>
					<!-- <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/image.svg" class="svg-icon" alt=""> -->
					<span>Add Products</span>
				  </a>
				</li>
				<li>
				  <a href="ecommerce_products.php">
				  <i class="fa fa-first-order" aria-hidden="true"></i>
					<!-- <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/image.svg" class="svg-icon" alt=""> -->
					<span>Products</span>
				  </a>
				</li>
				
				<li>
				  <a href="ecommerce_orders.php">
				  <i class="fa fa-puzzle-piece" aria-hidden="true"></i>
					<!-- <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/star.svg" class="svg-icon" alt=""> -->
					<span>Product Orders</span>
				  </a>
				</li>

					
				<li>
				  <a href="manage_pages.php">
				  <i class="fa fa-pagelines" aria-hidden="true"></i>
					<!-- <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/star.svg" class="svg-icon" alt=""> -->
					<span>Pages</span>
				  </a>
				</li>
			
				<li class="header">ADDITIONALS</li>		
				<li class="treeview">
				  <a href="#">
					<!-- <img src="https://www.multipurposethemes.com/admin/master-admin-template/images/svg-icon/authentication.svg" class="svg-icon" alt=""> -->
					<span>Authentication</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  </a>
				  <ul class="treeview-menu">
					<li><a href="AdminProfile.php"><i class="ti-more"></i>Admin Profile</a></li>
					<!-- <li><a href="auth_register.html"><i class="ti-more"></i>Register</a></li>
					<li><a href="auth_lockscreen.html"><i class="ti-more"></i>Lockscreen</a></li>
					<li><a href="auth_user_pass.html"><i class="ti-more"></i>Recover password</a></li>	 -->
				  </ul>
				</li>	  

			  </ul>
		 </div>
	  </div>
    </section>
    <div class="sidebar-footer">
		<!-- item-->
		<a href="javascript:void(0)" class="link" data-toggle="tooltip" title="" data-original-title="Settings"><i class="fa fa-cog fa-spin"></i></a>
		<!-- item-->
		<a href="javascript:void(0)" class="link" data-toggle="tooltip" title="" data-original-title="Email"><i class="fa fa-envelope"></i></a>
		<!-- item-->
		<a href="../../logout.php" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i class="fa fa-power-off"></i></a>
	</div>
  </aside>
