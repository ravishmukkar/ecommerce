<?php include('include/header.php'); ?>
<style>

#add_catogry{
	position:absolute;
	top:20px;
	right:20px;
	z-index:9 !important;
}

</style>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">Edit</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">e-Commerce</li>
								<li class="breadcrumb-item active" aria-current="page">Edit</li>
							</ol>
						</nav>
					</div>
				</div>
				<div class="right-title">
					<div class="d-flex mt-10 justify-content-end">
						<div class="d-lg-flex mr-20 ml-10 d-none">
							<div class="chart-text mr-10">
								<h6 class="mb-0"><small>THIS MONTH</small></h6>
								<h4 class="mt-0 text-primary">$12,125</h4>
							</div>
							<div class="spark-chart">
								<div id="thismonth"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
							</div>
						</div>
						<div class="d-lg-flex mr-20 ml-10 d-none">
							<div class="chart-text mr-10">
								<h6 class="mb-0"><small>LAST YEAR</small></h6>
								<h4 class="mt-0 text-danger">$22,754</h4>
							</div>
							<div class="spark-chart">
								<div id="lastyear"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>



		<!-- Main content -->
		<section class="content">                
			<div class="row">
			  <div class="col-6">
				  <div class="box-body">
				     <form action="" id="AddPage" method="post">
                        <div class="form-group">
                            <label>Page Name</label>
                            <input type="text" name="PageName" placeholder="Page Name" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-success">Add New Page</button>
                     
                     </form>
                     <div id="page_alert" class="mt-5"></div>
				  </div>
             </div>
             <div class="col-6">
				  <div class="box-body">
				     <form  id="PageCatogry" action="" method="post">
                        <div class="form-group">
						<label>Add New Page Catogry </label>
                            <input type="text" name="CatogryName" placeholder="Page Name" class="form-control">
                        </div>
                        <div class="form-group">
                         
							<label>Page Name</label>
                            <select id="get_pages_data" name="PageNameData" class="form-control">
                               
                            </select>
                        </div>
                        <button class="btn btn-success">Add</button>
                     </form>
                     <div id="catogry_alert" class="mt-5"></div>
				  </div>
             </div>
             <div class=" col-xl-6 col-12 box-shadow">
				  <div class="box-body ">
				  <table class="table table-bordered">
						<thead>
							<tr>
							<th scope="col">#</th>
							<th scope="col">Page Name</th>
							<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody id="GetPageData">
							<tr>
							<th scope="row">1</th>
							<td>Mark</td>
							<td>Otto</td>
						
							</tr>
							<tr>
							<th scope="row">2</th>
							<td>Jacob</td>
							<td>Thornton</td>
						
							</tr>
							
						</tbody>
						</table>
				  </div>
             </div>

			 <div class=" col-xl-6 col-12 box-shadow">
				  <div class="box-body ">
				  <table class="table table-bordered">
						<thead>
							<tr>
							<th scope="col">#</th>
							<th scope="col">Page Name</th>
							<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody id="GetPageCatogryData">
							<tr>
							<th scope="row">1</th>
							<td>Mark</td>
							<td>Otto</td>
						
							</tr>
							<tr>
							<th scope="row">2</th>
							<td>Jacob</td>
							<td>Thornton</td>
						
							</tr>
							
						</tbody>
						</table>
				  </div>
             </div>
           
         </div>		
		</section> 
		<!-- /.content -->
	  </div>
  </div>
  <!-- /.content-wrapper -->
 
 
  <!-- /.control-sidebar -->
  
  <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php include('include/footer.php') ?>

<script>

  $('#add-catogry-cloth').click(function(){
	  $('.pop-up').toggleClass('active');
	  $('.pop-up-catogry').removeClass('active');

  })

  $('#add-catogry-section').click(function(){
	  $('.pop-up-catogry').toggleClass('active');
	  $('.pop-up').removeClass('active');
  })

  $('#close').click(function(){
	$('.pop-up').toggleClass('active');
	  $('.pop-up-catogry').removeClass('active');

  })
  $('#close2').click(function(){
	$('.pop-up-catogry').toggleClass('active');
	  $('.pop-up').removeClass('active');

  })
</script>


