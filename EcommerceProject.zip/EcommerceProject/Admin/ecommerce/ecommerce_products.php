<?php include('include/header.php'); ?>



<style>
#add_product{
position:absolute;
bottom:4%;
left:4%;
padding: .5rem 1.6rem;
background: gold;
color:#fff;
font-size: 1.5rem;
box-shadow:  0 0 20px rgba(0,0,0,0.8);
border-radius: 10px;
z-index:999
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">

				<div class="mr-auto">
					<h3 class="page-title">Products</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">e-Commerce</li>
								<li class="breadcrumb-item active" aria-current="page">Products</li>
							</ol>
						</nav>
					</div>
				</div>
				<div class="right-title">
					<div class="d-flex mt-10 justify-content-end">
						<div class="d-lg-flex mr-20 ml-10 d-none">
							<div class="chart-text mr-10">
								<h6 class="mb-0"><small>THIS MONTH</small></h6>
								<h4 class="mt-0 text-primary">$12,125</h4>
							</div>
							<div class="spark-chart">
								<div id="thismonth"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
							</div>
						</div>
						<div class="d-lg-flex mr-20 ml-10 d-none">
							<div class="chart-text mr-10">
								<h6 class="mb-0"><small>LAST YEAR</small></h6>
								<h4 class="mt-0 text-danger">$22,754</h4>
							</div>
							<div class="spark-chart">
								<div id="lastyear"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			

			<!----  searchingheader----->
			<div class="d-flex align-items-center mt-3 mb-3">
				<div class="mr-auto">
					<div class="d-inline-block align-items-center">
					   <input type="text" class="form-control" id="searchbyid" placeholder="search id">
					</div>
					<div class="d-inline-block align-items-center">
					   <input type="text" class="form-control" id="searchbyproductname" placeholder="Seacrh Product">
					</div>
					<!-- <div class="d-inline-block align-items-center">
					   <input type="text" class="form-control" id="searchbyproducttags" placeholder="search by Tags">
					</div> -->
					<div class="d-inline-block align-items-center">
					   <select class="form-control" onchange="cloth_catogry_option($(this).val())">
						  <?php 
							$sql = "SELECT * FROM catogry_item";
							$result = $conn->query($sql);
							if($result->num_rows > 0){
								echo '<option value="">None</option>';
								WHILE($row = $result->fetch_assoc()){
									if(!empty($row['catogry_item'])){
										echo '<option value="'.$row['catogry_item'].'">'.$row['catogry_item'].'</option>';
									}
								}
							} 
						  ?>
					   </select>
					</div>
					<!-- <div class="d-inline-block align-items-center">
					   <select class="form-control" onchange="section_catogry_option($(this).val())">
						  <?php  
							// $sql = "SELECT * FROM cloth_catogry";
							// $result = $conn->query($sql);
							// if($result->num_rows > 0){
							// 	echo '<option value="none">None</option>';
							// 	WHILE($row = $result->fetch_assoc()){
							// 		if(!empty($row['cloth_catogry_section'])){
							// 			echo '<option value="'.$row['cloth_catogry_section'].'">'.$row['cloth_catogry_section'].'</option>';
							// 		}
							// 	}
							// } 
						  ?>
					    </select>
					</div> -->
				</div>
				<div class="right-title">
					<div class="d-flex mt-10 justify-content-end">
						<div class="d-lg-flex mr-20 ml-10 d-none">
					    	<div class="d-inline-block align-items-center">
					          <input type="date" class="form-control" id="first_date" placeholder="search by first date">
					        </div>
						</div>
						<div class="d-lg-flex mr-20 ml-10 d-none">
						   <div class="d-inline-block align-items-center">
					          <input type="date" class="form-control" onchange="getdateselect($(this).val())" id="last_date" placeholder="search by last date">
					        </div>
						</div>
					</div>
				</div>
			</div>
		</div>   <!----  searchingheader----->

		<!-- Main content -->
		<section class="content">

			<div class="row">
				<div class="col-12">
				  <div class="box">
					<div class="box-body">
					  <div class="table-responsive">
						  <table id="productorder" class="table table-hover no-wrap product-order" data-page-size="10">
							  <thead>
								  <tr>
									   <th>Product Id</th>
									   <th>Photo</th>
									   <th>Product</th>
									   <th>Date</th>
									   <th>Status</th>
									   <th>Actions</th>
								  </tr>
							  </thead>
							  <tbody id="GetAllProductData"> 
								
							
							  </tbody>						
						  </table>
					  </div>
					</div>
				  </div>
				  <!--- product add button=---->
				  <div id="add_product"><a href="add_products.php">Add New product</a></div>
				  <!--- product add button=---->
				</div>		  
			</div>
		  </section>

		  
		 
		<!-- /.content -->
	  </div>
  </div>
  <!-- /.content-wrapper -->
 
 <?php include('include/footer.php'); ?>
