<?php 
include('../../dbConnection/dbConnection.php');
 
//Get All Data 
if(isset($_REQUEST['getdata'])){
    $getdata = $_REQUEST['getdata'];
    $sql = "SELECT * FROM products ORDER BY id DESC";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
            
           echo '<tr>
           <td>'.$row['id'].'</td>
           <td><a href="ecommerce_details.php?product_detail='.$row['id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td>'.$row['product_name'].'</td>
           <td>'.$row['date_data'].'</td>
           <td><span class="badge badge-pill badge-success">'.$row['product_status'].'</span></td>
           <td><a href="ecommerce_products_edit.php?edit_product='.$row['id'].'" style="cursor:pointer;" class="text-info mr-10" data-toggle="tooltip" data-original-title="Edit">
                   <i class="ti-marker-alt"></i>
               </a> 
               <a  onclick="delete_product('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
                   <i class="ti-trash"></i>
               </a>
           </td>
       </tr>';
        }
    }
}


// Product Data

if(isset($_REQUEST['product_name'])){
    if( ($_REQUEST['product_name'] == '') || ($_REQUEST['product_sub_text'] == '') || ($_REQUEST['product_catogry'] == '') || 
    ($_REQUEST['product_price'] == '') || ($_REQUEST['product_discount'] == '') || ($_REQUEST['product_description'] == '') || ($_REQUEST['product_meta_title'] == '') ||
    ($_REQUEST['product_name'] == '')){
        echo '<div class="alert">Fill The Fields</alert>';
    }else{
        $product_name = $_REQUEST['product_name'];
        $product_sub_text = $_REQUEST['product_sub_text'];
        $product_catogry = $_REQUEST['product_catogry'];
        $product_catogry_section = $_REQUEST['product_catogry_section'];
        $product_price = $_REQUEST['product_price'];
        $product_oringinal_price = $_REQUEST['product_oringinal_price'];
        $product_discount = $_REQUEST['product_discount'];
        $product_description = $_REQUEST['product_description'];
        $product_meta_title = $_REQUEST['product_meta_title']; 
        $product_meta_keyword= $_REQUEST['product_meta_keyword'];
        $product_brand = $_REQUEST['product_brand'];
        $product_color = $_REQUEST['product_color']; 
        $date_data = date("Y.m.d");
        $product_status = "running";
        $target = "images/";
        $image = $_FILES['fileupload']['name']; 
        $filename = implode(",",$image);
        if(!empty($image)){
            foreach($image as $key => $val){
              $targetfilepath = $target . $val;
              move_uploaded_file($_FILES['fileupload']['tmp_name'][$key],$targetfilepath);
            }
            $sql = "INSERT INTO products (product_name,product_sub_text,catogry,catogry_section,product_status,
            product_description,product_price,product_oringinal_price,product_discount,meta_title,meta_keyword,
            product_brand,product_color,date_data,product_images) VALUES 
            ('$product_name','$product_sub_text','$product_catogry','$product_catogry_section','$product_status',
            '$product_description','$product_price','$product_oringinal_price','$product_discount','$product_meta_title','$product_meta_keyword','$product_brand','$product_color','$date_data','$filename')";
            $result = $conn->query($sql);
            if($result){
                echo '<div class="alert alert-success p-2">Successfully Added Data</div>';
            }else{
                echo 'failed';
            }
        }
    }
}



//DeleteProductData

if(isset($_REQUEST['deleteproductid'])){
    $deleteproductid = $_REQUEST['deleteproductid'];
    $sql = "DELETE FROM products WHERE id = '{$deleteproductid}'";
    $result = $conn->query($sql);
    if($result){
        echo 'deletedata';
    }
}



//product_name_update

if(isset($_REQUEST['product_name_update'])){
    if( ($_REQUEST['product_name_update'] == '') || ($_REQUEST['product_sub_text'] == '') || ($_REQUEST['product_catogry'] == '') ||
    ($_REQUEST['product_price'] == '') || ($_REQUEST['product_discount'] == '') || ($_REQUEST['product_description'] == '') || ($_REQUEST['product_meta_title'] == '')){
        echo '<div class="alert">Fill The Fields</alert>';
    }else{
        $updateid = $_REQUEST['updateid'];
        $product_name_update = $_REQUEST['product_name_update'];
        $product_sub_text = $_REQUEST['product_sub_text'];
        $product_catogry = $_REQUEST['product_catogry'];
        // $radiostatus = $_REQUEST['radiostatus'];
        $product_price = $_REQUEST['product_price'];
        $product_discount = $_REQUEST['product_discount'];
        $product_description = $_REQUEST['product_description'];
        $product_meta_title = $_REQUEST['product_meta_title'];
        $product_meta_keyword= $_REQUEST['product_meta_keyword'];
        $product_brand = $_REQUEST['product_brand'];
        $product_color = $_REQUEST['product_color'];
        $date_data = date("Y.m.d");
       
            $sql = "UPDATE products SET
             product_name = '$product_name_update', product_sub_text = '$product_sub_text',
             catogry = '$product_catogry', product_description = '$product_description',
             product_price = '$product_price', product_discount = '$product_discount', 	meta_title = '$product_meta_title',
             meta_keyword = '$product_meta_keyword', product_brand = '$product_brand', product_color = '$product_color',
             date_data = '$date_data' WHERE id = '{$updateid}'";
            $result = $conn->query($sql);
            if($result){
                echo '<div class="alert alert-success p-2">Successfully Updated Data</div>';
            }else{
                echo 'failed';
            }
    }
}


//UpdataImageData

if(isset($_REQUEST['updateidimagedata'])){
    $updateidimagedata = $_REQUEST['updateidimagedata'];

    $target = "images/";
    $image = $_FILES['fileupload']['name'];
    $filename = implode(",",$image);
    if(!empty($image)){
        foreach($image as $key => $val){
          $targetfilepath = $target . $val;
          move_uploaded_file($_FILES['fileupload']['tmp_name'][$key],$targetfilepath);
        }
        $sql = "UPDATE products SET product_images = '$filename' WHERE id = '{$updateidimagedata}'";
        $result = $conn->query($sql);
        if($result){
            echo '<div class="alert alert-success p-2">Successfully Updated Data</div>';
        }else{
            echo 'failed';
        }
    }
}



//Get All Data by id

if(isset($_REQUEST['searchbyid'])){
    $searchbyid = $_REQUEST['searchbyid'];
    $sql = "SELECT * FROM products WHERE id LIKE '%{$searchbyid}%'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
           echo '<tr>
           <td>'.$row['id'].'</td>
           <td><a href="product_detail.php?href=product_detail='.$row['id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td>'.$row['product_name'].'</td>
           <td>'.$row['date_data'].'</td>
           <td><span class="badge badge-pill badge-success">'.$row['product_status'].'</span></td>
           <td><a href="ecommerce_products_edit.php?edit_product='.$row['id'].'" style="cursor:pointer;" class="text-info mr-10" data-toggle="tooltip" data-original-title="Edit">
                   <i class="ti-marker-alt"></i>
               </a> 
               <a  onclick="delete_product('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
                   <i class="ti-trash"></i>
               </a>
           </td>
       </tr>';
        }
    }
}


//SearchByProductName

if(isset($_REQUEST['searchbyproductname'])){
    $searchbyproductname = $_REQUEST['searchbyproductname'];
    $sql = "SELECT * FROM products WHERE product_name LIKE '%{$searchbyproductname}%' || product_sub_text LIKE '%{$searchbyproductname}%' ||
    meta_title LIKE '%{$searchbyproductname}%' || meta_keyword LIKE '%{$searchbyproductname}%'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
           echo '<tr>
           <td>'.$row['id'].'</td>
           <td><a href="product_detail.php?href=product_detail='.$row['id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td>'.$row['product_name'].'</td>
           <td>'.$row['date_data'].'</td>
           <td><span class="badge badge-pill badge-success">'.$row['product_status'].'</span></td>
           <td><a href="ecommerce_products_edit.php?edit_product='.$row['id'].'" style="cursor:pointer;" class="text-info mr-10" data-toggle="tooltip" data-original-title="Edit">
                   <i class="ti-marker-alt"></i>
               </a> 
               <a  onclick="delete_product('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
                   <i class="ti-trash"></i>
               </a>
           </td>
       </tr>';
        }
    }
}


// getOptionData

if(isset($_REQUEST['option_cloth'])){
    $option_cloth = $_REQUEST['option_cloth'];
    $sql = "SELECT * FROM products WHERE catogry_section = '{$option_cloth}'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
           echo '<tr>
           <td>'.$row['id'].'</td>
           <td><a href="product_detail.php?href=product_detail='.$row['id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td>'.$row['product_name'].'</td>
           <td>'.$row['date_data'].'</td>
           <td><span class="badge badge-pill badge-success">'.$row['product_status'].'</span></td>
           <td><a href="ecommerce_products_edit.php?edit_product='.$row['id'].'" style="cursor:pointer;" class="text-info mr-10" data-toggle="tooltip" data-original-title="Edit">
                   <i class="ti-marker-alt"></i>
               </a> 
               <a  onclick="delete_product('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
                   <i class="ti-trash"></i>
               </a>
           </td>
       </tr>';
        }
    }
}


// if(isset($_REQUEST['option_section'])){
//     $option_section = $_REQUEST['option_section'];
//     $sql = "SELECT * FROM products WHERE product_name = '{$option_section}'";
//     $result = $conn->query($sql);
//     if($result->num_rows > 0){
//         while ($row = $result->fetch_assoc()) {
//             $item_image = $row['product_images'];
//             $item_image_store = explode(",",$item_image);
//            echo '<tr>
//            <td>'.$row['id'].'</td>
//            <td><a href="product_detail.php?href=product_detail='.$row['id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
//            <td>'.$row['product_name'].'</td>
//            <td>'.$row['date_data'].'</td>
//            <td><span class="badge badge-pill badge-success">'.$row['product_status'].'</span></td>
//            <td><a href="ecommerce_products_edit.php?edit_product='.$row['id'].'" style="cursor:pointer;" class="text-info mr-10" data-toggle="tooltip" data-original-title="Edit">
//                    <i class="ti-marker-alt"></i>
//                </a> 
//                <a  onclick="delete_product('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
//                    <i class="ti-trash"></i>
//                </a>
//            </td>
//        </tr>';
//         }
//     }
// }

// ******************** Add_Catogry

if(isset($_REQUEST['add_catogry'])){
    $add_catogry = $_REQUEST['add_catogry'];
    if(($_REQUEST['add_catogry'] == '')){
        echo '<div class="alert alert-success p-1">Please Fill The field!</div>';
    }else{
        $sql = "INSERT INTO cloth_catogry (cloth_catogry) VALUES('$add_catogry')";
        $result = $conn->query($sql);
        if($result){
            echo '<alert class="alert alert-success">Successfull Added</alert>';
        }
    }
}



// **************** FirstDate

if(isset($_REQUEST['FirstDate'])){
    $FirstDate = $_REQUEST['FirstDate'];
    $SecondDate = $_REQUEST['LastDate'];
    $sql = "SELECT * FROM products WHERE date_data BETWEEN '{$FirstDate}' AND '{$SecondDate}'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
           echo '<tr>
           <td>'.$row['id'].'</td>
           <td><a href="product_detail.php?href=product_detail='.$row['id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td>'.$row['product_name'].'</td>
           <td>'.$row['date_data'].'</td>
           <td><span class="badge badge-pill badge-success">'.$row['product_status'].'</span></td>
           <td><a href="ecommerce_products_edit.php?edit_product='.$row['id'].'" style="cursor:pointer;" class="text-info mr-10" data-toggle="tooltip" data-original-title="Edit">
                   <i class="ti-marker-alt"></i>
               </a> 
               <a  onclick="delete_product('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
                   <i class="ti-trash"></i>
               </a>
           </td>
       </tr>';
      }
    }
}

// ***************** getCtogry

if(isset($_REQUEST['get_catogry'])){
    $get_catogry = $_REQUEST['get_catogry'];
    $sql = "SELECT * FROM cloth_catogry";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $id = 1;
        WHILE($row = $result->fetch_assoc()){
            if(!empty($row['cloth_catogry'])){
                echo '<tr>
                <td>'.$id.'</td>
                <td>'.$row['cloth_catogry'].'</td>
                <td><button class="btn btn-success" onclick="delete_catogry('.$row['id'].')">Delete</button></td>
               </tr>';
            }
            $id++;
        }
    }
}


//GetAll CatogryData

if(isset($_REQUEST['get_catogry_cloth_data'])){
    $get_catogry_cloth_data = $_REQUEST['get_catogry_cloth_data'];
    $sql = "SELECT * FROM catogry_page";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        echo '<option value="none">none</option>';

        WHILE($row = $result->fetch_assoc()){
            if(!empty($row['catogry_page'])){
            echo '<option value="'.$row['catogry_page'].'">'.$row['catogry_page'].'</option>';
            }
        }
    }
}



///*************  delete_catogry **** */

if(isset($_REQUEST['delete_catogry'])){
    $delete_catogry = $_REQUEST['delete_catogry'];
    $sql = "DELETE FROM cloth_catogry WHERE id = '{$delete_catogry}'";
    $result = $conn->query($sql);
}



// ************&&&&&&&&&&&&&&&&&&&&  Section


if(isset($_REQUEST['add_catogry_section'])){
    $add_catogry_section = $_REQUEST['add_catogry_section'];
    if(($_REQUEST['add_catogry_section'] == '')){
        echo '<div class="alert alert-success p-1">Please Fill field !</div>';
    }else{
        $sql = "INSERT INTO cloth_catogry (cloth_catogry_section) VALUES ('$add_catogry_section')";
        $result = $conn->query($sql);
        if($result){
            echo '<alert class="alert alert-success">Successfull Added</alert>';
        }
    }
}


// ***************** getCtogry

if(isset($_REQUEST['get_catogry_section'])){
    $get_catogry_section = $_REQUEST['get_catogry_section'];
    $sql = "SELECT * FROM cloth_catogry";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $id = 1;
        WHILE($row = $result->fetch_assoc()){
            if(!empty($row['cloth_catogry_section'])){
                echo '<tr>
                <td>'.$id.'</td>
                <td>'.$row['cloth_catogry_section'].'</td>
                <td><button class="btn btn-success" onclick="delete_catogry_section('.$row['id'].')">Delete</button></td>
               </tr>';
            }
            $id++;
        }
    }
}


//GetAll CatogryData

if(isset($_REQUEST['SelectCatogry'])){
    $sql = "SELECT * FROM catogry_item WHERE catogry_page = '{$_REQUEST['SelectCatogry']}'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            echo '<option value="'.$row['catogry_item'].'">'.$row['catogry_item'].'</option>';
        }
    }
}


// if(isset($_REQUEST['get_catogry_section_data'])){
//     $get_catogry_section_data = $_REQUEST['get_catogry_section_data'];
//     $sql = "SELECT * FROM cloth_catogry";
//     $result = $conn->query($sql);
//     if($result->num_rows > 0){
//         echo '<option value="none">none</option>';
//         echo '<option value="featured">Featured</option>';
//         echo '<option value="toprated">Top Rated</option>';

//         WHILE($row = $result->fetch_assoc()){
//             if(!empty($row['cloth_catogry_section'])){
//                 echo '<option value="'.$row['cloth_catogry_section'].'">'.$row['cloth_catogry_section'].'</option>';
//             }
//         }
//     }
// }



///*************  delete_catogry **** */

if(isset($_REQUEST['delete_catogry_section'])){
    $delete_catogry_section = $_REQUEST['delete_catogry_section'];
    $sql = "DELETE FROM cloth_catogry WHERE id = '{$delete_catogry_section}'";
    $result = $conn->query($sql);
}






// ********************* Get All Product ***********************  //

if(isset($_REQUEST['get_all_order'])){
    $sql = "SELECT * FROM place_order WHERE delivery_status = 'processing' ORDER BY id DESC";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
           echo '<tr>
           <td>'.$row['users_name'].'</td>
           <td>'.$row['id'].'</td>
           <td>'.$row['product_id'].'</td>
           <td><a href="ecommerce_details.php?product_detail='.$row['product_id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td><a href="ecommerce_details.php?product_detail='.$row['product_id'].'">'.$row['product_name'].'</a></td>
           <td>'.$row['product_quantity'].'</td>
           <td>'.$row['phone'].'</td>
           <td>'.$row['street_adress1'].','. $row['street_adress2'].'</td>
           <td>'.$row['town'].'</td>
           <td>'.$row['today_date'].'</td>
           <td><span onclick="order_complete('.$row['id'].')" class="badge badge-pill badge-success">'.$row['delivery_status'].'</span></td>
           <td>
               <a href="#" onclick="delete_order('.$row['id'].')" class="text-danger" data-original-title="Delete" data-toggle="tooltip">
                   <i class="ti-trash"></i>
               </a>
           </td>
       </tr>';
        }
    }
}

//DeleteOrder


if(isset($_REQUEST['order_id_delete'])){
    $order_id_delete = $_REQUEST['order_id_delete'];
    $sql = "DELETE FROM place_order WHERE id = '{$order_id_delete}'";
    $result = $conn->query($sql);
}

// order_complete

if(isset($_REQUEST['order_complete_id'])){
    $order_complete_id = $_REQUEST['order_complete_id'];
    $today_date = date("Y.m.d");
    $deliverystatus = 'order_complete';
    
    $sqlselect = "SELECT * FROM place_order WHERE id = '{$order_complete_id}'";
    $resultselect = $conn->query($sqlselect);
    $row = $resultselect->fetch_assoc();
    $deliverystatus = $row['delivery_status'];

    if($deliverystatus === 'Processing'){
        $deliverystatus = "order_complete";
        $sql = "UPDATE place_order SET delivery_status = '$deliverystatus',today_date = '$today_date' WHERE id = '{$order_complete_id}'";
        $result = $conn->query($sql);
    }else{
        $deliverystatus = "Processing";
        $sql = "UPDATE place_order SET delivery_status = '$deliverystatus',today_date = '$today_date' WHERE id = '{$order_complete_id}'";
        $result = $conn->query($sql);
    }


}


// GetRecentOrders


if(isset($_REQUEST['get_recent_orders'])){
    $sql = "SELECT * FROM place_order ORDER BY id DESC LIMIT 0, 10";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
           echo '<tr>
           <td>'.$row['today_date'].'</td>
           <td>'.$row['users_name'].'</td>
           <td>'.$row['id'].'</td>
           <td>'.$row['product_id'].'</td>
           <td><a href="ecommerce_details.php?product_detail='.$row['product_id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td><a href="ecommerce_details.php?product_detail='.$row['product_id'].'">'.$row['product_name'].'</a></td>
           <td>'.$row['product_quantity'].'</td>
           <td>'.$row['phone'].'</td>
           <td>'.$row['street_adress1'].','. $row['street_adress2'].'</td>
           <td>'.$row['town'].'</td>
           <td><span onclick="order_complete('.$row['id'].')" class="badge badge-pill badge-success">'.$row['delivery_status'].'</span></td>
           <td>
               <a href="#" onclick="delete_order('.$row['id'].')" class="text-danger" data-original-title="Delete" data-toggle="tooltip">
                   <i class="ti-trash"></i>
               </a>
           </td>
       </tr>';
        }
    }
}



//Get Complete Orders


if(isset($_REQUEST['Complete_Orders'])){
    $sql = "SELECT * FROM place_order WHERE delivery_status = 'order_complete' ORDER BY id DESC LIMIT 0, 10";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
            $item_image = $row['product_images'];
            $item_image_store = explode(",",$item_image);
           echo '<tr>
           <td>'.$row['today_date'].'</td>
           <td>'.$row['first_name'].'</td>
           <td>'.$row['id'].'</td>
           <td>'.$row['product_id'].'</td>
           <td><a href="ecommerce_details.php?product_detail='.$row['product_id'].'"><img src="images/'.$item_image_store[0].'" alt="product" width="80"></a></td>
           <td><a href="ecommerce_details.php?product_detail='.$row['product_id'].'">'.$row['product_name'].'</a></td>
           <td>'.$row['product_quantity'].'</td>
           <td>'.$row['phone'].'</td>
           <td>'.$row['street_adress1'].','. $row['street_adress2'].'</td>
           <td>'.$row['town'].'</td>
           <td><span onclick="order_complete('.$row['id'].')" class="badge badge-pill badge-success">'.$row['delivery_status'].'</span></td>
           <td>
               
           </td>
       </tr>';
        }
    }
}


// Get Notification



// get_notofication

if(isset($_REQUEST['get_notofication'])){
    $sql = "SELECT * FROM send_messege ORDER BY id ";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
          
           echo '<li>
           <a href="#">
             <i class="fa fa-users text-info"></i>Order id : '.$row['order_id'].' => Request For Cancel Order.
           </a>
         </li>';
        }
    }
}

// **************** page section  code

//Get Pages

if(isset($_REQUEST['get_pages'])){
    $sql = "SELECT * FROM catogry_page";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()) {
          
           echo '<option value="'.$row['catogry_page'].'" class="form-control">'.$row['catogry_page'].'</option>';
        }
    }
}


// Add Pages

if(isset($_REQUEST['PageName'])){
  $PageName = $_REQUEST['PageName'];

  if(empty($PageName)){
    echo '<alert class="alert alert-success text-light">please Type a Catohry</div>';
     
  }else{
    $sql = "SELECT * FROM catogry_page WHERE catogry_page = '{$PageName}'";
    $result = $conn->query($sql);
    if($result->num_rows == 0){
      $sql = "INSERT INTO catogry_page (catogry_page) values ('$PageName')";
      $result = $conn->query($sql);
      if($result){
         echo '<alert class="alert alert-success text-light">Added Successfully</div>';
      }else{
           echo '<alert class="alert alert-success text-light">Alreary Exists This Catogry</div>';
      }
    }else{
      echo '<alert class="alert alert-success text-light">Alreary Exists This Catogry</div>';
        
    }
  }
}

//CatogryName

if(isset($_REQUEST['CatogryName'])){
    $CatogryName = $_REQUEST['CatogryName'];
    $PageName = $_REQUEST['PageNameData'];
  
    if(empty($CatogryName)){
      echo '<alert class="alert alert-success text-light">please Type a Catogry</div>';
       
    }else{
      $sqli = "SELECT * FROM catogry_item WHERE catogry_item = '{$CatogryName}' && catogry_page ='{$PageName}' LIMIT 1";
      $resulti = $conn->query($sqli);
      if($resulti->num_rows == 0){
        $sql = "INSERT INTO catogry_item (catogry_item,catogry_page) values ('$CatogryName','$PageName')";
        $result = $conn->query($sql);
        if($result){
            echo '<alert class="alert alert-success text-light">Added Successfully</div>';
        }else{
            echo '<alert class="alert alert-success text-light">Alreary Exists This Catogry</div>';
        }
      }else{
        echo '<alert class="alert alert-success text-light">Alreary Exists This Catogry</div>';
          
      }
    }
  }


// ************** GetPageData

if(isset($_REQUEST['get_page_data'])){
    $sql = "SELECT * FROM catogry_page";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $i = 1;
        while($row = $result->fetch_assoc()){
            echo '<tr>
            <th scope="row">'.$i.'</th>
           
            <td><input type="text" id="" value="'.$row['catogry_page'].'" class="form-control"></td>
            <td>
               <a  onclick="delete_page('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
               <i class="ti-trash"></i>
               </a>
               <a  onclick="update_page('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Update" data-toggle="tooltip">
               <i class="ti-marker-alt"></i>

               </a>
            </td>
            </tr>';
            $i++;
        }
    }
}


// ************** GetPageData

if(isset($_REQUEST['get_page_catogry_data'])){
    $sql = "SELECT * FROM catogry_item";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $i = 1;
        while($row = $result->fetch_assoc()){
            echo '<tr>
            <th scope="row">'.$i.'</th>
            <td>'.$row['catogry_item'].' ('.$row['catogry_page'].')</td>
            <td>
               <a  onclick="delete_page_catogry('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
               <i class="ti-trash"></i>
               </a>
               <a  onclick="update_page_catogry('.$row['id'].')" class="text-danger" style="cursor:pointer;" data-original-title="Delete" data-toggle="tooltip">
                  
               <i class="ti-marker-alt"></i>

               </a>
            </td>
            </tr>';
            $i++;
        }
    }
}

// Delete Page And Ctogry

if(isset($_REQUEST['DeletePageId'])){
    $DeletePageId = $_REQUEST['DeletePageId'];
    $sql = "DELETE FROM catogry_page WHERE id = '{$DeletePageId}'";
    $result = $conn->query($sql);
}

// *************** PageCatogryId

if(isset($_REQUEST['PageCatogryId'])){
    $PageCatogryId = $_REQUEST['PageCatogryId'];
    $sql = "DELETE FROM catogry_item WHERE id = '{$PageCatogryId}'";
    $result = $conn->query($sql);
}


// AdminUpdateDetail

if(isset($_REQUEST['UpdateFirstName'])){
   

    if(($_REQUEST['UpdateFirstName'] == '') || ($_REQUEST['UpdateLastName'] == '') || ($_REQUEST['DisplayName'] == '') || ($_REQUEST['AdminEmail'] == '')
    || ($_REQUEST['AdminPass'] == '')){
        echo 'please fill all fields';
    }else{
        $AdminFirstName = $_REQUEST['UpdateFirstName'];
        $AdminLastName = $_REQUEST['UpdateLastName'];
        $DisplayName = $_REQUEST['DisplayName'];
        $AdminEmail = $_REQUEST['AdminEmail'];
        $AdminPass = $_REQUEST['AdminPass'];
        $sql = "UPDATE admin_login set first_name = '$AdminFirstName',last_name='$AdminLastName',admin_user_name='$DisplayName',admin_email='$AdminEmail',admin_password='$AdminPass' WHERE id = 1";
        $result = $conn->query($sql);
        if($result){
            echo '<alert class="alert alert-success">Update Succesfuly</alert>';
        }else{
            echo 'faild';
        }
    }
  
}

// ************* Update Admin Profile

if(isset($_FILES['AdminProfile'])){
    $AdminProfle = $_FILES['AdminProfile']['name'];
    $AdminTemp = $_FILES['AdminProfile']['tmp_name'];
    $folder = 'AdminProfile/'.$AdminProfle;
    // echo $AdminProfle . $AdminTemp;
    move_uploaded_file($AdminTemp,$folder);

    $sql = "UPDATE admin_login set admin_profile_image = '$folder' WHERE id =1";
    $result = $conn->query($sql);
    if($result){
        echo '<alert class="alert alert-success">Update Succesfuly</alert>';
    }else{
        echo '<alert class="alert alert-success">Failed</alert>';
    }

}


//******************* getPerofileImg */


if(isset($_REQUEST['getPerofileImg'])){
    $sql = "SELECT admin_profile_image FROM admin_login WHERE id =1";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        echo '<img style="height:300px;width:250px" src="'.$row['admin_profile_image'].'" >';
    }
}

?>