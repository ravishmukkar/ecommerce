-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2021 at 12:22 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `addtocart`
--

CREATE TABLE `addtocart` (
  `id` int(11) NOT NULL,
  `user_ip` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` varchar(255) NOT NULL,
  `product_size` varchar(255) NOT NULL,
  `product_price` varchar(255) NOT NULL,
  `product_images` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addtocart`
--

INSERT INTO `addtocart` (`id`, `user_ip`, `product_id`, `product_name`, `product_quantity`, `product_size`, `product_price`, `product_images`) VALUES
(107, '::1', '18', 'paint', '3', 'xl', '300', '01.jpeg,1.jpg,03.jpeg,3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `admin_user_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `first_name`, `last_name`, `admin_user_name`, `admin_email`, `admin_password`, `admin_profile_image`) VALUES
(1, 'Ravish', 'Mukkar', 'ravishmukkar', 'ravishmukkar98@gmail.com', '123456', '');

-- --------------------------------------------------------

--
-- Table structure for table `catogry_item`
--

CREATE TABLE `catogry_item` (
  `id` int(11) NOT NULL,
  `catogry_item` varchar(255) NOT NULL,
  `catogry_page` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catogry_item`
--

INSERT INTO `catogry_item` (`id`, `catogry_item`, `catogry_page`) VALUES
(1, 'reebo0k', 'jeans'),
(2, 'oppo', 'mobile'),
(3, 'vivo', 'mobile'),
(4, 'shivnaresh', 'jeans'),
(5, 'oppo a9', 'oppo');

-- --------------------------------------------------------

--
-- Table structure for table `catogry_page`
--

CREATE TABLE `catogry_page` (
  `id` int(11) NOT NULL,
  `catogry_page` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catogry_page`
--

INSERT INTO `catogry_page` (`id`, `catogry_page`) VALUES
(1, 'jeans'),
(2, 'mobile'),
(3, 'oppo');

-- --------------------------------------------------------

--
-- Table structure for table `cloth_catogry`
--

CREATE TABLE `cloth_catogry` (
  `id` int(11) NOT NULL,
  `cloth_catogry` varchar(500) NOT NULL,
  `cloth_catogry_section` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cloth_catogry`
--

INSERT INTO `cloth_catogry` (`id`, `cloth_catogry`, `cloth_catogry_section`) VALUES
(11, 'jeans', ''),
(12, 'frauk', ''),
(13, 'shirt', ''),
(14, 'paint', ''),
(20, '', ''),
(22, '', ''),
(23, '', ''),
(24, '', ''),
(25, '', ''),
(28, '', 'winter'),
(29, '', 'summer');

-- --------------------------------------------------------

--
-- Table structure for table `customer_review`
--

CREATE TABLE `customer_review` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `users_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_comment` text NOT NULL,
  `star_rating` varchar(255) NOT NULL,
  `reply_date` date NOT NULL,
  `comment_img` varchar(500) NOT NULL,
  `user_profile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_review`
--

INSERT INTO `customer_review` (`id`, `product_id`, `users_name`, `user_email`, `user_comment`, `star_rating`, `reply_date`, `comment_img`, `user_profile`) VALUES
(42, 18, 'ravi mukar', 'mukkarravish@gmail.com', 'perfect product for b uy', '5', '2021-03-04', 'comment_img/7.jpg', ''),
(43, 18, 'ravi mukare', 'mukkarravish@gmail.com', 'ravis', '3', '2021-03-04', 'comment_img/6.jpg', ''),
(44, 18, 'ravi mukare', 'mukkarravish@gmail.com', 'very poor comments', '1', '2021-03-04', 'comment_img/6.jpg', ''),
(45, 19, 'ravi mukar', 'mukkarravish@gmail.com', 'this is the amazing product', '3', '2021-03-04', 'comment_img/7.jpg', ''),
(46, 19, 'ravi mukar', 'mukkarravish@gmail.com', 'ra aa', '1', '2021-03-04', 'comment_img/7.jpg', ''),
(47, 20, 'ravish', 'ravish@gmail.com', 'this product is good', '4', '2021-03-06', 'comment_img/6.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `notification_itembox`
--

CREATE TABLE `notification_itembox` (
  `id` int(11) NOT NULL,
  `notification_number` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notification_itembox`
--

INSERT INTO `notification_itembox` (`id`, `notification_number`) VALUES
(1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `place_order`
--

CREATE TABLE `place_order` (
  `id` int(11) NOT NULL,
  `product_id` int(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` varchar(100) NOT NULL,
  `product_size` varchar(100) NOT NULL,
  `product_price` varchar(200) NOT NULL,
  `product_images` varchar(500) NOT NULL,
  `users_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `company_name` varchar(500) NOT NULL,
  `country` varchar(255) NOT NULL,
  `street_adress1` varchar(500) NOT NULL,
  `street_adress2` varchar(500) NOT NULL,
  `town` varchar(300) NOT NULL,
  `district` varchar(300) NOT NULL,
  `user_state` varchar(255) NOT NULL,
  `postcode` varchar(155) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email_adress` varchar(255) NOT NULL,
  `other_notes` text NOT NULL,
  `today_date` date NOT NULL,
  `user_ip` varchar(255) NOT NULL,
  `delivery_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `place_order`
--

INSERT INTO `place_order` (`id`, `product_id`, `product_name`, `product_quantity`, `product_size`, `product_price`, `product_images`, `users_name`, `user_email`, `first_name`, `last_name`, `company_name`, `country`, `street_adress1`, `street_adress2`, `town`, `district`, `user_state`, `postcode`, `phone`, `email_adress`, `other_notes`, `today_date`, `user_ip`, `delivery_status`) VALUES
(24, 14, 'coat', '1', 'small', '300', 'large-6.jpg,large-7.jpg,large-8.jpg,small-1.jpg,small-2.jpg,small-3.jpg,small-4.jpg', 'ravi mukare', 'ravishmukkar98@gmail.com', 'ravi', 'mukare', 'inspired you', 'India', 'kotputli', 'bsc', 'Jaipur', 'jaipur', 'Andaman and Nicobar', '303108', '07878642508', 'mukkarravish@gmail.com', 'hello my name is ravish mukkar i am a good boy', '2021-03-06', '::1', 'Processing'),
(25, 15, 'featured product', '1', 'xl', '200', 'product-72.jpg,product-73.jpg,product-74.jpg,product-75.jpg,product-76.jpg', 'ravi mukare', 'ravishmukkar98@gmail.com', 'ravi', 'mukare', 'inspired you', 'India', 'kotputli', 'bsc', 'Jaipur', 'jaipur', 'Andaman and Nicobar', '303108', '07878642508', 'mukkarravish@gmail.com', 'helo', '2021-03-06', '::1', 'Processing'),
(26, 13, 't-shirt', '1', 'xl', '300', 'b-large-1.jpg,b-large-2.jpg,b-large-3.jpg,b-large-4.jpg,b-large-9.jpg', 'ravi mukare', 'ravishmukkar98@gmail.com', 'ravi', 'mukare', 'inspired you', 'India', 'kotputli', 'bsc', 'Jaipur', 'jaipur', 'Andaman and Nicobar', '303108', '07878642508', 'mukkarravish@gmail.com', 'helo', '2021-03-06', '::1', 'Processing'),
(27, 12, 'himanshu sir', '1', 'xl', '200', 'event-custom.jpg,event-private.jpg,events-bg.jpg,services4.jpg,services5.jpg,services6.jpg', 'ravi mukare', 'ravishmukkar98@gmail.com', 'ravi', 'mukare', 'inspired you', 'India', 'kotputli', 'bsc', 'Jaipur', 'jaipur', 'Andaman and Nicobar', '303108', '07878642508', 'mukkarravish@gmail.com', 'helo', '2021-03-06', '::1', 'Processing');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_sub_text` varchar(500) NOT NULL,
  `catogry` varchar(255) NOT NULL,
  `catogry_section` varchar(255) NOT NULL,
  `product_status` varchar(255) NOT NULL,
  `product_description` text NOT NULL,
  `product_price` varchar(255) NOT NULL,
  `product_discount` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `product_brand` varchar(255) NOT NULL,
  `product_color` varchar(255) NOT NULL,
  `product_size` varchar(255) NOT NULL,
  `product_matrial` varchar(255) NOT NULL,
  `date_data` date NOT NULL,
  `product_rating` float NOT NULL,
  `total_cmts` int(100) NOT NULL,
  `product_images` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_sub_text`, `catogry`, `catogry_section`, `product_status`, `product_description`, `product_price`, `product_discount`, `meta_title`, `meta_keyword`, `product_brand`, `product_color`, `product_size`, `product_matrial`, `date_data`, `product_rating`, `total_cmts`, `product_images`) VALUES
(21, 'jeans', 'jeans', 'shirt', 'toprated', 'running', 'this is the amazing products okay', '300', '20', 'paint adidas kota', 'paint adidias', 'adidas,shiv naresh', 'red blue', '', '', '2021-05-20', 0, 0, 'gallery-2.jpg,gallery-3.jpg,gallery-4.jpg,gallery-8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `send_messege`
--

CREATE TABLE `send_messege` (
  `id` int(11) NOT NULL,
  `users_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_phone` varchar(255) NOT NULL,
  `send_messege` text NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` varchar(11) NOT NULL,
  `today_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `send_messege`
--

INSERT INTO `send_messege` (`id`, `users_name`, `user_email`, `user_phone`, `send_messege`, `order_id`, `product_id`, `today_date`) VALUES
(1, 'ravishmukkar', 'mukkarravish@gmail.com', '', 'Request for cancel Order', 16, '34', '0000-00-00'),
(2, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(3, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 20, '35', '0000-00-00'),
(4, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(5, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(6, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(7, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(8, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(9, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(10, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 23, '15', '0000-00-00'),
(11, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(12, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 23, '15', '0000-00-00'),
(13, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(14, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '0000-00-00'),
(15, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 23, '15', '2021-02-03'),
(16, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 23, '15', '2021-02-03'),
(17, 'ravishmukkar', 'mukkarravish@gmail.com', '87878642508', 'Request for cancel Order', 22, '16', '2021-02-03');

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE `user_reg` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `users_name` varchar(255) NOT NULL,
  `user_mobile` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_profile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`id`, `first_name`, `last_name`, `user_email`, `users_name`, `user_mobile`, `user_pass`, `user_profile`) VALUES
(1, 'ravish', 'mukkar', '', '', '7878642508', '', ''),
(2, 'ravi', 'mukkar', 'mukkarravish@gmail.com', 'ravishmukkar', '7878642508', '123456', ''),
(3, 'ravi', 'mukare', 'ravishmukkar98@gmail.com', 'ravi mukare', '07878642508', 'ravish', ''),
(4, 'aadarsh', 'pathak', 'ravishmukkar98@gmail.com', 'ravishmukkar', '7878642508', '123456', ''),
(5, 'anuj', 'gujjar', 'anuj@gmail.com', 'anuj', '7878642508', '123456', '');

-- --------------------------------------------------------

--
-- Table structure for table `wish_cart`
--

CREATE TABLE `wish_cart` (
  `id` int(11) NOT NULL,
  `user_ip` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quality` varchar(255) NOT NULL,
  `product_size` varchar(255) NOT NULL,
  `product_price` varchar(255) NOT NULL,
  `product_images` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addtocart`
--
ALTER TABLE `addtocart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catogry_item`
--
ALTER TABLE `catogry_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catogry_page`
--
ALTER TABLE `catogry_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloth_catogry`
--
ALTER TABLE `cloth_catogry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_review`
--
ALTER TABLE `customer_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_itembox`
--
ALTER TABLE `notification_itembox`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `place_order`
--
ALTER TABLE `place_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `send_messege`
--
ALTER TABLE `send_messege`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wish_cart`
--
ALTER TABLE `wish_cart`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addtocart`
--
ALTER TABLE `addtocart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `catogry_item`
--
ALTER TABLE `catogry_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `catogry_page`
--
ALTER TABLE `catogry_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cloth_catogry`
--
ALTER TABLE `cloth_catogry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `customer_review`
--
ALTER TABLE `customer_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `notification_itembox`
--
ALTER TABLE `notification_itembox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `place_order`
--
ALTER TABLE `place_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `send_messege`
--
ALTER TABLE `send_messege`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_reg`
--
ALTER TABLE `user_reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wish_cart`
--
ALTER TABLE `wish_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
