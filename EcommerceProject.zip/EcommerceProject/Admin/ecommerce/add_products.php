<?php include('include/header.php'); ?>
<style>

#add_catogry{
	position:absolute;
	top:20px;
	right:20px;
	z-index:9 !important;
}

</style>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">Edit</h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">e-Commerce</li>
								<li class="breadcrumb-item active" aria-current="page">Edit</li>
							</ol>
						</nav>
					</div>
				</div>
				<div class="right-title">
					<div class="d-flex mt-10 justify-content-end">
						<div class="d-lg-flex mr-20 ml-10 d-none">
							<div class="chart-text mr-10">
								<h6 class="mb-0"><small>THIS MONTH</small></h6>
								<h4 class="mt-0 text-primary">$12,125</h4>
							</div>
							<div class="spark-chart">
								<div id="thismonth"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
							</div>
						</div>
						<div class="d-lg-flex mr-20 ml-10 d-none">
							<div class="chart-text mr-10">
								<h6 class="mb-0"><small>LAST YEAR</small></h6>
								<h4 class="mt-0 text-danger">$22,754</h4>
							</div>
							<div class="spark-chart">
								<div id="lastyear"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>



<style>
/* 
.pop-up,.pop-up-catogry{
	position:fixed;
	top:0%;
	left:50%;
	transform:translate(-50%,-50%);
	background: rgba(255,255,255,3);
	box-shadow: 0 0 300px rgba(0,0,0,3);
	width:70%;
	z-index:999;
	padding: 2rem 3rem;
	height:initial;
    min-height: 400px;
	max-height:550px;
	visibility:hidden;
	opacity:0;
    transition:.4s ease-in;
	overflow-y: scroll;
}

.pop-up.active,.pop-up-catogry.active{
	visibility:visible;
	opacity:1;
	top:50%;
}
.catogry_box {
	height:100%;
}
.catogry1{
	overflow:hidden;
}

#close,#close2{
	position: absolute;
	right:5px;
	top:5px;
}*/
</style>
 


<!---     catogry Cloth ------------->
<!-- 
<div class="pop-up">
  <div class="container">
    <div class="row">
	<button class="btn btn-primary " id="close">close</button>
	  <div class="col-xl-6 col-12">
	    <li class="breadcrumb-item m-3" aria-current="page">Add New catogry </li>
		
	     <form action="" methos="post" id="add_catogry_cloth">
		   <div class="form-row">
		     <div class="form-group col-xl-12">
			    <input type="text" class="form-control" placeholder="Add A Catogry" name="add_catogry">
			 </div>
		   </div>
		    <button type="submit" class="btn btn-primary">Add Catogry</button>
		 </form>
		 <div id="get_catogry_alert" class="m-2 p-3"></div>
	  </div>
	  
	  <div class="col-xl-6 col-12">
	      <li class="breadcrumb-item m-3" aria-current="page">View All Catogry</li>
	                   <table id="productorder" class="table table-hover no-wrap product-order" data-page-size="10">
							  <thead>
								  <tr>
									   <th>S.NO</th>
									   <th>Cloth Catogry</th>
									   <th>Action</th>
									  
								  </tr>
							</thead>
			  <tbody id="get_catogry">
			     
			  </tbody>
		   </table>
	  </div>

	</div>
  </div>
</div> -->

<!--- ---  catogry ------------->


<!---     catogry  ------------->
<!-- 
<div class="pop-up-catogry">
  <div class="container">
    <div class="row">
	<button class="btn btn-primary " id="close2">close</button>

	  <div class="col-xl-6 col-12">
	    <li class="breadcrumb-item m-3" aria-current="page">Add catogry</li>
	     <form action="" methos="post" id="add_catogry_section">
		   <div class="form-row">
		     <div class="form-group col-xl-12">
			    <input type="text" class="form-control" placeholder="Add A Catogry" name="add_catogry_section">
			 </div>
		   </div>
		    <button type="submit" class="btn btn-primary">Add Catogry</button>
		 </form>
		 <div id="get_catogry_alert_section" class="m-2 p-3"></div>
	  </div>
	  
	  <div class="col-xl-6 col-12">
	                   <table id="productorder" class="table table-hover no-wrap product-order" data-page-size="10">
							  <thead>
								  <tr>
									   <th>S.NO</th>
									   <th>Cloth Catogry</th>
									   <th>Action</th>
									  
								  </tr>
							</thead>
			  <tbody id="get_catogry_section">
			     
			  </tbody>
		   </table>
	  </div>

	</div>
  </div>
</div> -->

<!--- ---  catogry ------------->




		<!-- Main content -->
		<section class="content">                
			<div class="row" style="position:relative;">
			  <div class="col-12">
			  <div id="add_catogry">
			     <!-- <button id="add-catogry-cloth" class="btn btn-success p-2">Add new Catogry</button>
			     <button id="add-catogry-section" class="btn btn-success p-2">Catogry</button> -->
			  </div>
				<div class="box">
					<div class="box-header with-border">
					  <h4 class="box-title">About Product</h4>
					</div>
				  <div class="box-body">
					<form action="" Methos="POST" id="add_product">
						<div class="form-body">
							<div class="row">
							<div class="col-md-12">
									<h4 class="box-title mt-20">Upload Image</h4>
									<div class="product-img text-left">
										<img src="images/" alt="">
										<div class="btn btn-info mb-20">
											<span>Upload Anonther Image</span>
                                            <input type="file" name="fileupload[]" multiple class="upload"> 
										</div>
										
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
									  <label class="font-weight-700 font-size-16">Product Name</label>
									  <input type="text" name="product_name" class="form-control" placeholder="Product Name">
									</div>
								</div>
								<!--/span-->
								<div class="col-md-6">
									<div class="form-group">
									   <label class="font-weight-700 font-size-16">Sub text</label>
									   <input type="text" name="product_sub_text" class="form-control" placeholder="Lorem Ipsum Text...">
									</div>
								</div>
								<!--/span-->
							</div>
							<!--/row-->
							<!--/row-->
							<div class="row">
								<div class="col-md-3">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Category Page</label>
										<select class="form-control" id="get_cloth_catogry_data" onchange="CatogryPageSelect($(this).val())" name="product_catogry" data-placeholder="Choose a Category" tabindex="1">
										
										</select>
									</div>
								</div>
								<!---select placement product ---->
								<div class="col-md-3">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Category</label>
										<select class="form-control" id="get_catogry_section_data" name="product_catogry_section" data-placeholder="Choose a Category" tabindex="1">
										   <option value="featured">Featured</option>
										   <option value="summer">Summer</option>
										   <option value="winter">Winter</option>
										</select>
									</div>
								</div>
								<!--/span-->
								<!-- <div class="col-md-3">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">For</label>
										<select class="form-control" id="get_catogry_section_data" name="product_catogry_section" data-placeholder="Choose a Category" tabindex="1">
										<option value="'.$row['cloth_catogry'].'">Men</option>
										<option value="'.$row['cloth_catogry'].'">Women</option>
										<option value="'.$row['cloth_catogry'].'">'.$row['cloth_catogry'].'</option>
										</select>
									</div>
								</div> -->
								<!--/span-->
							</div>
							<!--/row-->
							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Price</label>
										<div class="input-group">
											<div class="input-group-addon"><i class="ti-money"></i></div>
											<input type="text" name="product_price" class="form-control" placeholder="270"> </div>
									</div>
								</div>
								<!--/span-->
								<div class="col-md-4">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Oringinal Price</label>
										<div class="input-group">
											<div class="input-group-addon"><i class="ti-money"></i></div>
											<input type="text" name="product_oringinal_price" class="form-control" placeholder="270"> </div>
									</div>
								</div>
								<!--/span-->
								<div class="col-md-4">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Discount</label>
										<div class="input-group">
											<div class="input-group-addon"><i class="ti-cut"></i></div>
											<input type="text" name="product_discount" class="form-control" placeholder="50%"> </div>
									</div>
								</div>
								<!--/span-->
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Product Description</label>
										<textarea class="form-control p-20" name="product_description" rows="4"></textarea>
									</div>
								</div>
							</div>
							<!--/row-->
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Meta Title</label>
										<input type="text" name="product_meta_title" class="form-control"> </div>
								</div>
								<!--/span-->
								<div class="col-md-6">
									<div class="form-group">
										<label class="font-weight-700 font-size-16">Meta Keyword</label>
										<input type="text" name="product_meta_keyword" class="form-control"> </div>
								</div>
								<!--/span-->
								
							</div>
							<div class="row">
								<div class="col-md-12">
									<h4 class="box-title mt-40">General Info</h4>
									<div class="table-responsive">
										<table class="table no-border td-padding">
											<tbody>
												<tr>
													<td>
														<input type="text" class="form-control" name="product_brand" placeholder="Brand">
													</td>
													<!-- <td>
														<input type="text" class="form-control" placeholder="Sellar">
													</td> -->
												</tr>
												<tr>
													<!-- <td>
														<input type="text" class="form-control" placeholder="Delivery Condition">
													</td> -->
													<!-- <td>
														<input type="text"  class="form-control" placeholder="Knock Down">
													</td> -->
												</tr>
												<tr>
													<td>
														<input type="text" name="product_color" class="form-control" placeholder="Color">
													</td>
													<!-- <td>
														<input type="text" class="form-control" placeholder="Gift Pack">
													</td> -->
												</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="form-actions mt-10">
							<button type="submit" class="btn btn-primary" name="submitproduct"> <i class="fa fa-check"></i> Save</button>
							<button type="button" class="btn btn-danger">Cancel</button>
						</div>
					</form>
				  </div>
				  <div id="add_product_data"></div>
				</div>
			  </div>		  
		  </div>

		</section>
		<!-- /.content -->
	  </div>
  </div>
  <!-- /.content-wrapper -->
 
 
  <!-- /.control-sidebar -->
  
  <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php include('include/footer.php') ?>

<script>

  $('#add-catogry-cloth').click(function(){
	  $('.pop-up').toggleClass('active');
	  $('.pop-up-catogry').removeClass('active');

  })

  $('#add-catogry-section').click(function(){
	  $('.pop-up-catogry').toggleClass('active');
	  $('.pop-up').removeClass('active');
  })

  $('#close').click(function(){
	$('.pop-up').toggleClass('active');
	  $('.pop-up-catogry').removeClass('active');

  })
  $('#close2').click(function(){
	$('.pop-up-catogry').toggleClass('active');
	  $('.pop-up').removeClass('active');

  })
</script>


