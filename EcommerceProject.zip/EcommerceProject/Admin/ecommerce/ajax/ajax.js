function get_Productdata(){
    var getdata = 'getdataproducts';
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            getdata : getdata,
        },
        success : function(data,status){
            $('#GetAllProductData').html(data);
        }
    }) 
}

get_Productdata();



//getdateselect

function getdateselect(LastDate){
    var FirstDate = $('#first_date').val();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            FirstDate : FirstDate,
            LastDate : LastDate,
        },
        success : function(data,status){
            $('#GetAllProductData').html(data);
            // console.log("ravish");
            console.log(data);
        }
    }) 
    // console.log("raish");
}

$('#add_product').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            $('#add_product')[0].reset();
            $('#add_product_data').html(data);
        }
    })
})

//DeleteProductData

function delete_product(deleteproductid){
    $.ajax({
        url : 'phpfunction.php',
        type: 'POST',
        data : {
            deleteproductid : deleteproductid,
        },
        success:function(data,status){
            get_Productdata();
        }
    })
}


//EditProduct

$('#edit_product').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            $('#edit_product')[0].reset();
            $('#edit_product_data').html(data);
        }
    })
})


//EditImageproduct

$('#edit_product_image').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success : function(data,status){
            $('#edit_product_image')[0].reset();
            $('#edit_product_image_data').html(data);
        }
    })
})

//searchById


$('#searchbyid').on('keyup',function(){
    var searchbyid = $('#searchbyid').val();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            searchbyid : searchbyid,
        },
        success : function(data,status){
            $('#GetAllProductData').html(data);
        }
    })
})
 
//searchByProductName

$('#searchbyproductname').on('keyup',function(){
    var searchbyproductname = $('#searchbyproductname').val();
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            searchbyproductname : searchbyproductname,
        },
        success : function(data,status){
            $('#GetAllProductData').html(data);
        }
    })
})

//cloth_catogry_option

function cloth_catogry_option(option_cloth){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            option_cloth : option_cloth,
        },
        success : function(data,status){
            $('#GetAllProductData').html(data);
        }
    })
}


function section_catogry_option(option_section){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            option_section : option_section,
        },
        success : function(data,status){
            $('#GetAllProductData').html(data);
        }
    })
}

//**********************Get catogry

function get_catogry(){
    var get_catogry = "get_catogry";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_catogry : get_catogry,
        },
        success : function(data,status){
            $('#get_catogry').html(data);
        }
    })
}

get_catogry();


// ****************** get Ctogry Data

function get_catogry_cloth_data(){
    var get_catogry_cloth_data = "get_catogry_cloth_data";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_catogry_cloth_data : get_catogry_cloth_data,
        },
        success : function(data,status){
            $('#get_cloth_catogry_data').html(data);
        }
    })
}

get_catogry_cloth_data();


// ******************** add Catogry


$('#add_catogry_cloth').on('submit',function(e){
  e.preventDefault();
  $.ajax({
    url : 'phpfunction.php',
    type : 'POST',
    data : new FormData(this),
    contentType : false,
    catche : false,
    processData : false,
    success : function(data,status){
        $('#add_catogry_cloth')[0].reset();
        $('#get_catogry_alert').html(data);
        get_catogry();
        get_catogry_cloth_data();
    }
})
})



// ********************* delete_catogry

function delete_catogry(delete_catogry){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            delete_catogry : delete_catogry,
        },
        success : function(data,status){
          get_catogry();
          get_catogry_cloth_data();
        }
    })
}



// &&&*************************&&&&& 



//**********************Get catogry

function get_catogry_section(){
    var get_catogry_section = "get_catogry_section";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_catogry_section : get_catogry_section,
        },
        success : function(data,status){
            $('#get_catogry_section').html(data);
        }
    })
}

get_catogry_section();


// ****************** get Ctogry Data


function CatogryPageSelect(SelectCatogry){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            SelectCatogry : SelectCatogry,
        },
        success : function(data,status){
            $('#get_catogry_section_data').html(data);   
        },
    })
}


// function get_catogry_section_data(){
//     var get_catogry_section_data = "get_catogry_section_data";
//     $.ajax({
//         url : 'phpfunction.php',
//         type : 'POST',
//         data : {
//             get_catogry_section_data : get_catogry_section_data,
//         },
//         success : function(data,status){
//             $('#get_catogry_section_data').html(data);
//         }
//     })
// }

// get_catogry_section_data();


// ******************** add Catogry


$('#add_catogry_section').on('submit',function(e){
  e.preventDefault();
  $.ajax({
    url : 'phpfunction.php',
    type : 'POST',
    data : new FormData(this),
    contentType : false,
    catche : false,
    processData : false,
    success : function(data,status){
        $('#add_catogry_section')[0].reset();
        $('#get_catogry_alert_section').html(data);
        get_catogry_section();
        get_catogry_section_data();
    }
})
})



// ********************* delete_catogry

function delete_catogry_section(delete_catogry_section){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            delete_catogry_section : delete_catogry_section,
        },
        success : function(data,status){
          get_catogry_section();
          get_catogry_section_data();
        } 
    })
}



// ********************** Get All Orders ******************************


function get_all_orders(){
    var get_all_order = "get_all_order";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_all_order : get_all_order,
        },
        success : function(data,status){
          $('#get_all_orders').html(data);
        }
    })
}

get_all_orders();

// *********************** delete_order


function delete_order(order_id_delete){
    window.alert("do you want to delete this order");
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            order_id_delete : order_id_delete,
        },
        success : function(data,status){
            get_all_orders();
        },
    })
}


// Get Recent Orders

function getrecentorders() {
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_recent_orders : "get_recent_orders",
        },
        success : function(data,status){
            $('#get_recent_orders').html(data);
            get_all_orders();
        },
    })
}

getrecentorders();


// Complete Orders


function Complete_Orders() {
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            Complete_Orders : "Complete_Orders",
        },
        success : function(data,status){
            $('#get_complete_order').html(data);
            get_all_orders();
        },
    })
}

Complete_Orders();



// ****************** order_complete 

function order_complete(order_complete_id){

    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            order_complete_id : order_complete_id,
        },
        success : function(data,status){
            get_all_orders();
           Complete_Orders();
           getrecentorders();

        },
    })
}



// Get Notification

function get_notification(){

    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_notofication : "get_notification",
        },
        success : function(data,status){
          $('#get_notification').html(data);
        },
    })
}
get_notification();




// **********************   catogry code




// *************** Get All Data Page


function GetPageData(){
    var get_page_data = "get_page_data";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_page_data : get_page_data,
        },
        success : function(data,status){
          $('#GetPageData').html(data);
        }
    })
}

GetPageData();

// ************ GetPageCatogryData

function GetPageCatogryData(){
    var get_page_catogry_data = "get_page_catogry_data";
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_page_catogry_data : get_page_catogry_data,
        },
        success : function(data,status){
          $('#GetPageCatogryData').html(data);
        }
    })
}

GetPageCatogryData();

//Get page

function get_pages(){

    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            get_pages : "get_pages",
        },
        success : function(data,status){
          $('#get_pages_data').html(data);
        },
    })
}
get_pages();


// Add page 

$('#AddPage').on('submit',function(e){
    e.preventDefault();
    $.ajax({
      url : 'phpfunction.php',
      type : 'POST',
      data : new FormData(this),
      contentType : false,
      catche : false,
      processData : false,
      success : function(data,status){
        $('#page_alert').html(data);
        $('#AddPage')[0].reset();
        get_pages();
       GetPageData();

      }
  })
  })

  // ********** PageCatogry


  $('#PageCatogry').on('submit',function(e){
    e.preventDefault();
    $.ajax({
      url : 'phpfunction.php',
      type : 'POST',
      data : new FormData(this),
      contentType : false,
      catche : false,
      processData : false,
      success : function(data,status){
        $('#catogry_alert').html(data);
        $('#PageCatogry')[0].reset();
        // get_catogry_data();
      GetPageCatogryData();

      }
  })
  })




// **************** Delete Page and  Catogry Pages


function delete_page(PageId){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            DeletePageId : PageId,
        },
        success : function(data,status){
           GetPageData();
           get_pages();        
        },
    })
}

// ********************* delete_page_catogry


function delete_page_catogry(PageCatogryId){
    $.ajax({
        url : 'phpfunction.php',
        type : 'POST',
        data : {
            PageCatogryId : PageCatogryId,
        },
        success : function(data,status){
            GetPageCatogryData();    
        },
    })
}



// Update Page Data

// function update_page(UpdateId,ra){
//   console.log(UpdateId);
//   console.log(ra);
// }



// UpdateAdminProfile


$('#UpdateAdmin').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        method : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success:function(data,status){
            $('#alertDivUpdate').html("<div class='spinner-border text-success' role='status'></div>");
            setTimeout(() => {
                $('#alertDivUpdate').html(data);
            }, 2000);
        }

    })
})


function getProfileImg(){
  
    $.ajax({
        url : 'phpfunction.php',
        method : 'POST',
        data : {
            getPerofileImg : "getprofileImg"
        },
     
        success:function(data,status){
         $('#img_box').html(data);
        }

    })
   
}

getProfileImg();

/// UpdateAdminProfile
$('#UpdateAdminProfile').on('submit',function(e){
    e.preventDefault();
    $.ajax({
        url : 'phpfunction.php',
        method : 'POST',
        data : new FormData(this),
        contentType : false,
        catche : false,
        processData : false,
        success:function(data,status){
            $('#alertDivImageUpdate').html("<div class='spinner-border text-success' role='status'></div>");
            setTimeout(() => {
                $('#alertDivImageUpdate').html(data);
            }, 2000);
            getProfileImg();
            // console.log(data);
        }

    })
})

