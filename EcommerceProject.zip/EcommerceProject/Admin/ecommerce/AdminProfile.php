<?php include('include/header.php'); ?>



<style>
#add_product{
position:absolute;
bottom:4%;
left:4%;
padding: .5rem 1.6rem;
background: gold;
color:#fff;
font-size: 1.5rem;
box-shadow:  0 0 20px rgba(0,0,0,0.8);
border-radius: 10px;
z-index:999
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="d-flex align-items-center ">

         
            <div class="container">
			   <div class="row">
                   <div class="col-xl-6 p-5">
                      <form action="" method="POST" id="UpdateAdmin">
                          <div class="form-row p-3">
                              <div class="form-group col-xl-12">
                                <label>First Name</label>
                                 <input type="text" placeholder="Type Your Name" name="UpdateFirstName" value="<?php if(isset($first_name)){echo $first_name;} ?>" class="form-control">
                              </div>
                              <div class="form-group col-xl-12">
                                    <label>Last Name</label>
                                    <input type="text" placeholder="Type Your Name" name="UpdateLastName" value="<?php if(isset($last_name)){echo $last_name;} ?>" class="form-control">
                              </div>
                              <div class="form-group col-xl-12">
                                    <label>Display Name</label>
                                    <input type="text" placeholder="Your display Name" name="DisplayName" value="<?php if(isset($admin_user_name)){echo $admin_user_name;} ?>" class="form-control">
                              </div>
                              
                              <div class="form-group col-xl-12">
                                <label>Your Email</label>
                                <input type="text" placeholder="Type Your Email" name="AdminEmail" value="<?php if(isset($admin_email)){echo $admin_email;} ?>" class="form-control">
                              </div>
                              <div class="form-group col-xl-12">
                                <label>Your Password</label>
                                <input type="password" placeholder="Type Your Password" name="AdminPass" value="<?php if(isset($password)){echo $password;} ?>" class="form-control">
                              </div>
                              <div class="form-group col-xl-12">
                                  <input type="submit" class="btn btn-success" name="update" value="update">
                              </div>

                          </div>
                      </form>
                      <div id="alertDivUpdate"></div>
                   </div>
                   <div class="col-xl-6 d-flex flex-column justify-content-center align-items-center">
                       <div class="img_box p-2 "  id="img_box"></div>
                       <form action="" method="POST"  id="UpdateAdminProfile">
                           <input type="file" name="AdminProfile">
                           <input type="submit" name="submit" value="Update">
                       </form>
                   </div>
               </div>
            </div>
                
			

		  
          </div>
         </div>
		<!-- /.content -->
	  </div>
  </div>
  <!-- /.content-wrapper -->
 
 <?php include('include/footer.php'); ?>
