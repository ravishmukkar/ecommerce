 
<?php 
include('dbConnection/dbConnection.php'); 

session_start();
if(isset($_SESSION['register_login'])){
	$user_email = $_SESSION['singin_email'];
}else{
	echo "<script> location.href='login-register.php'; </script>";
}

$sql = "SELECT * FROM user_reg WHERE user_email = '{$user_email}'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$first_name = $row['first_name'];
$last_name = $row['last_name'];

$user_name = $row['users_name'];
$user_email = $row['user_email'];
$user_phone = $row['user_mobile'];
$user_pass = $row['user_pass'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

	<title>Mukkar</title>

	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="Donald - Bootstrap eCommerce Template">
	<meta name="author" content="D-THEMES">

	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/icons/favicon.png">

	<script>
		WebFontConfig = {
			google: { families: ['Open+Sans:400,600,700', 'Poppins:400,500,600,700'] }
		};
		(function (d) {
			var wf = d.createElement('script'), s = d.scripts[0];
			wf.src = 'js/webfont.js';
			wf.async = true;
			s.parentNode.insertBefore(wf, s);
		})(document);
	</script>


	<link rel="stylesheet" type="text/css" href="vendor/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.min.css">

	<!-- Plugins CSS File -->
	<link rel="stylesheet" type="text/css" href="vendor/magnific-popup/magnific-popup.min.css">

	<!-- Main CSS File -->
	<link rel="stylesheet" type="text/css" href="css/style.min.css">
</head>

<body>
	<div class="loading-overlay">
		<div class="bounce-loader">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
			<div class="bounce4"></div>
		</div>
	</div>
	<div class="page-wrapper">
	<header class="header">				
		<!-- End HeaderTop -->
			<div class="header-middle sticky-header fix-top sticky-content">
				<div class="container">
					<div class="header-left">
						<a href="#" class="mobile-menu-toggle">
							<i class="d-icon-bars2"></i>
						</a>
					</div>
					<div class="header-center">
						<a href="demo1.html" class="logo">
							<img src="images/logo.png" alt="logo" width="163" height="39" />
						</a>
						<!-- End Logo -->
						<nav class="main-nav">
						<ul class="menu">
                                    <li class="active">
                                        <a href="index.php">Home</a>
                                    </li>
									<li>
                                    <a href="product.html">Products</a>
                                    <div class="megamenu">
                                        <div class="row">

                                        <?php
                                        
                                        $sql = "SELECT * FROM catogry_page";
                                        $result = $conn->query($sql);
                                        if($result->num_rows > 0){
                                            while($row = $result->fetch_assoc()){
                                                echo '<div class="col-4 col-sm-4 col-md-3 col-lg-4">
                                                       <h4 class="menu-title">'.$row['catogry_page'].'</h4>
                                                      <ul>
                                                ';
                                                ?>
                                           <?php 
                                           
                                             $sqli = "SELECT * FROM catogry_item WHERE catogry_page = '{$row['catogry_page']}'";
                                             $resulti = $conn->query($sqli);
                                             if($resulti->num_rows > 0){
                                                 while($rowi = $resulti->fetch_assoc()){
                                                  
                                                   echo '<li><a href="product_shop.php?product_catogry='.$rowi['catogry_item'].'">'.$rowi['catogry_item'].'</a></li>';
                                                 }
                                             } 
                                           
                                           ?>
                                        <?php

                                                echo '</ul></div>';
                                            }
                                        }
                                        
                                        ?>
                                            <!-- <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Pages</h4>
                                                <ul>
                                                    <li><a href="product-simple.html">Simple Product</a></li>
                                                    <li><a href="product.html">Variable Product</a></li>
                                                    <li><a href="product-sale.html">Sale Product</a></li>
                                                    <li><a href="product-featured.html">Featured &amp; On Sale</a></li>

                                                    <li><a href="product-left-sidebar.html">With Left Sidebar</a></li>
                                                    <li><a href="product-right-sidebar.html">With Right Sidebar</a></li>
                                                    <li><a href="product-sticky-cart.html">Add Cart Sticky<span
                                                                class="tip tip-hot">Hot</span></a></li>
                                                    <li><a href="product-tabinside.html">Tab Inside</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Layouts</h4>
                                                <ul>
                                                    <li><a href="product-grid.html">Grid Images<span
                                                                class="tip tip-new">New</span></a></li>
                                                    <li><a href="product-masonry.html">Masonry</a></li>
                                                    <li><a href="product-gallery.html">Gallery Type</a></li>
                                                    <li><a href="product-full.html">Full Width Layout</a></li>
                                                    <li><a href="product-sticky.html">Sticky Info</a></li>
                                                    <li><a href="product-sticky-both.html">Left &amp; Right Sticky</a>
                                                    </li>
                                                    <li><a href="product-horizontal.html">Horizontal Thumb</a></li>

                                                    <li><a href="#">Build Your Own</a></li>
                                                </ul>
                                            </div> -->
                                            <div
                                                class="col-6 col-sm-4 col-md-3 col-lg-4 menu-banner menu-banner2 banner banner-fixed">
                                                <figure>
                                                    <img src="images/menu/banner-2.jpg" alt="Menu banner" width="221"
                                                        height="330" />
                                                </figure>
                                                <div class="banner-content x-50 text-center">
                                                    <h3 class="banner-title text-white text-uppercase">Sunglasses</h3>
                                                    <h4 class="banner-subtitle font-weight-bold text-white mb-0">$23.00
                                                        -
                                                        $120.00</h4>
                                                </div>
                                            </div>
                                            <!-- End MegaMenu -->
                                        </div>
                                    </div>
                                </li>

                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <li>
                                        <a href="about-us.html">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                  
                                    <li>
                                        <a href="wishlist.php">Wish Cart</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>
                                </ul>
						</nav>
						<span class="divider"></span>
						<!-- End Divider -->
						<div class="header-search hs-toggle">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End Header Search -->
					</div>
					<div class="header-right">
						<a class="login" href="ajax/login.html">
							<i class="d-icon-user"></i>
							<span>Login</span>
						</a>
						<!-- End Login -->
						<span class="divider"></span>
					
						<div class="dropdown cart-dropdown">
                            <a href="#" class="cart-toggle">
                                <span class="cart-label">
                                    <span class="cart-name">My Cart</span>
                                    <span class="cart-price total_amount"></span>
                                </span>
                                <i class="minicart-icon">
                                    <span class="cart-count count"></span>
                                </i>
                            </a>
                            <!-- End of Cart Toggle -->
                            <div class="dropdown-box">
                                <div class="product product-cart-header">
                                    <span class="product-cart-counts count"> items : </span>
                                    <span><a href="cart.php">View cart</a></span>
                                </div>
                                <div class="products scrollable" id="showcart">

                                   
                                    <!-- End of Cart Product -->
                                       
                                    <!-- End of Cart Product -->
                                </div>
                                <!-- End of Products  -->
                                <div class="cart-total">
                                    <label>Subtotal:</label>
                                    <span class="price total_amount"></span>
                                </div>
                                <!-- End of Cart Total -->
                                <div class="cart-action">
                                    <a href="checkout.php" class="btn btn-dark"><span>Checkout</span></a>
                                </div>
                      
                                <!-- End of Cart Action -->
                            </div>
                            <!-- End of Dropdown Box -->
                        </div>
						<div class="header-search hs-toggle mobile-search">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End of Header Search -->
					</div>
				</div>

			</div>
		</header>
		<!-- End Header -->
		<main class="main checkout">
			<!-- <div class="page-header bg-dark"
				style="background-image: url('images/shop/page-header-back.jpg'); background-color: #3C63A4;">
				<h1 class="page-title">Checkout</h1>
				<ul class="breadcrumb">
					<li><a href="demo1.html"><i class="d-icon-home"></i></a></li>
					<li>Checkout</li>
				</ul>
			</div> -->
			<!-- End PageHeader -->
			<div class="page-content pt-10 pb-10">
				<div class="step-by pt-2 pb-2 pr-4 pl-4">
					<h3 class="title title-simple title-step visited"><a href="cart.php">1. Shopping Cart</a></h3>
					<h3 class="title title-simple title-step active"><a href="checkout.php">2. Checkout</a></h3>
					<h3 class="title title-simple title-step"><a href="order.php">3. Order Complete</a></h3>
				</div>
				<div class="container mt-8">
					<form action="payment-gateway.php" class="form" id="checkout">
						<div class="row gutter-lg">
							<div class="col-lg-7 mb-6">
								<h3 class="title title-simple text-left">Billing Details</h3>
								<div class="row">
								  
									<div class="col-xs-6">
										<label>First Name *</label>
										<input type="hidden" class="form-control" value="<?php if(isset($user_name)){ echo $user_name;} ?>" name="user_name" required="" />
										<input type="hidden" class="form-control" value="<?php if(isset($user_email)){ echo $user_email;} ?>"  name="user_email" required="" />
										<input type="text" class="form-control" name="first_name_checkout" required="" />
									</div>
									<div class="col-xs-6">
										<label>Last Name *</label>
										<input type="text" class="form-control" name="last_name_checkout" required="" />
									</div>
								</div>
								<label>Company Name(Optional)</label>
								<input type="text" class="form-control" name="company_name" required="" />
								<h3 class="title title-simple text-left mt-5 mb-5">Select a delivery address</h3>
								<label>Country / Region *</label>
								<input type="text" class="form-control" name="country" required="" />
								<label>Street Address *</label>
								<input type="text" class="form-control" name="address1" required=""
									placeholder="House number and Street name" />
								<input type="text" class="form-control" name="address2" required=""
									placeholder="Appartments, suite, unit etc ..." />
								<div class="row">
									<div class="col-xs-6">
										<label>Town / City *</label>
										<input type="text" class="form-control" name="city" required="" />
									</div>
									<div class="col-xs-6">
										<label>District*</label>
										<input type="text" class="form-control" name="district" required="" />
									</div>
									<div class="col-xs-6">
										<label>State / County *</label>
										<input type="text" class="form-control" name="state" required="" />
									</div>
								</div>
								<div class="row">
									<div class="col-xs-6">
										<label>Postcode / ZIP *</label>
										<input type="text" class="form-control" name="postcode" required="" />
									</div>
									<div class="col-xs-6">
										<label>Phone *</label>
										<input type="text" class="form-control" name="phone" required="" />
									</div>
								</div>
								<label>Email address *</label>
								<input type="text" class="form-control" name="email_address" required="" />
								
								<h3 class="title title-simple text-left mb-3">Additional information</h3>
								<label>Order Notes (optional)</label>
								<textarea class="form-control" name="other_notes" cols="30" rows="6"
									placeholder="Notes about your order, e.g. special notes for delivery"></textarea>
							</div>
							<aside class="col-lg-5 sticky-sidebar-wrapper">
								<div class="sticky-sidebar" data-sticky-options="{'bottom': 50}">
									<h3 class="title title-simple text-left">Your Order</h3>
									<div class="summary mb-4">
										<table class="order-table">
											<thead>
												<tr>
													<th>Product</th>
													<th></th>
												</tr>
											</thead>
											<tbody id="checkout_cart">
												
											
												<tr class="summary-subtotal">
													<td>
														<h4 class="summary-subtitle ">Subtotal</h4>
													</td>
													<td class="summary-subtotal-price total_amount">
													</td>												
												</tr>
												<!-- <tr class="sumnary-shipping shipping-row-last">
													<td colspan="2">
														<h4 class="summary-subtitle">Shipping</h4>
														<ul>
															<li>
																<div class="custom-radio">
																	<input type="radio" id="free-shipping" name="shipping" class="custom-control-input" checked>
																	<label class="custom-control-label" for="free-shipping">Free
																		Shipping</label>
																</div>
															</li>
															<li>
																<div class="custom-radio">
																	<input type="radio" id="standard_shipping" name="shipping" class="custom-control-input">
																	<label class="custom-control-label" for="standard_shipping">Standard</label>
																</div>
															</li>
															<li>
																<div class="custom-radio">
																	<input type="radio" id="express_shipping" name="shipping" class="custom-control-input">
																	<label class="custom-control-label" for="express_shipping">Express</label>
																</div>
															</li>
														</ul>
													</td>
												</tr> -->
												<tr class="summary-subtotal">
													<td>
														<h4 class="summary-subtitle">Total</h4>
													</td>
													<td>
														<p class="summary-total-price total_amount"></p>
													</td>												
												</tr>
											</tbody>
										</table>
									
										<div class="text-danger ">
										
												    <!-- <select name="PaymentMethod" id="PaymentMethod" class="form-control">
														<option value="select payment method">Select paymet Metho</option>
														<option value="payonline">Pay Online</option>
														<option value="cashondelivery">Cash On Delivery</option>
													</select> -->

										</div>
										<p class="checkout-info">Your personal data will used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.</p>
										<button type="submit" class="btn btn-dark btn-order">Place Order</button>
									</div>
								</div>
							</aside>
						</div>
					</form>
				</div>
				<div id="checkout_success"></div>
			</div>
		</main>

		<?php include('include/footer.php'); ?>
