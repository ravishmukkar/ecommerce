<?php 

session_start();
if(isset($_SESSION['register_login'])){
    echo "<script> location.href='account.php'; </script>";
}else{
	
}
include('include/header.php')


?>
        
        <main class="main mt-lg-4">
            <div class="page-content">
                <div class="container">
                    <div class="row">
                        <aside class="col-xl-12 col-lg-12 d-flex align-items-center justify-content-center mt-5 mb-5">
                          <div class="login-popup" style="min-width:40%;">
                                    <div class="form-box">
                                        <div class="tab tab-nav-simple tab-nav-boxed form-tab">
                                            <ul class="nav nav-tabs nav-fill" role="tablist">
                                                <li class="nav-item">
                                                    <a class="nav-link active" href="#signin">Sign in</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" href="#register">Register</a>
                                                </li>
                                            </ul>
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="signin">
                                                    <form action="" id="sign_in">
                                                        <div class="form-group">
                                                            <label for="singin-email">Username or email address:</label>
                                                            <input type="text" class="form-control" id="singin_email" name="singin_email"
                                                            value="<?php if(isset($_COOKIE['signin-email'])){ echo $_COOKIE['signin-email']; } ?>" required />
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="singin-password">Password:</label>
                                                            <input type="password" class="form-control" id="singin_password" name="singin_password"
                                                              value="<?php if(isset($_COOKIE['singin_password'])){ echo $_COOKIE['singin_password']; } ?>"  required />
                                                        </div>
                                                        <div class="form-footer">
                                                            <div class="form-checkbox">
                                                                <input type="checkbox" class="custom-checkbox" id="signin-remember"
                                                                    name="signin-remember" />
                                                                <label class="form-control-label font-secondary" for="signin-remember">Remember
                                                                    me</label>
                                                            </div>
                                                            <a href="#" class="lost-link font-secondary">Lost your password?</a>
                                                        </div>
                                                        <button class="btn btn-primary btn-block" type="submit">Sign in</button>
                                                    </form>
                                                    <div class="form-choice text-center">
                                                        <label class="font-secondary">Sign in with social account</label>
                                                        <div class="social-links">
                                                            <a href="#" class="social-link social-facebook fab fa-facebook-f"></a>
                                                            <a href="#" class="social-link social-twitter fab fa-twitter"></a>
                                                            <a href="#" class="social-link social-google fab fa-google"></a>
                                                        </div>
                                                        <div id="sign_alert"></div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="register">
                                                    <form  action="" metho="POST" id="register_data">
                                                       <div class="form-group">
                                                            <label for="singin-email">First Name:</label>
                                                            <input type="text" class="form-control" id="register-email" name="first_name"
                                                                required />
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="singin-email">Last Name:</label>
                                                            <input type="text" class="form-control" id="register-email" name="last_name"
                                                                required />
                                                        </div>
                                                       <div class="form-group">
                                                            <label for="singin-email">Your Name:</label>
                                                            <input type="text" class="form-control" id="register-name" name="register_name"
                                                                required />
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="singin-email">Your Email:</label>
                                                            <input type="email" class="form-control" id="register-email" name="register_email"
                                                            required   />
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="singin-email">Your Phone Number:</label>
                                                            <input type="phone" class="form-control" id="register-phone" name="register_phone"
                                                            required   />
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="singin-password">Password:</label>
                                                            <input type="password" class="form-control" id="register-password" name="register_password"
                                                            required />
                                                        </div>
                                                        <div class="form-footer">
                                                            <div class="form-checkbox">
                                                                <input type="checkbox" class="custom-checkbox" id="register-agree" name="register-agree"
                                                                required />
                                                                <label class="form-control-label font-secondary" for="register-agree">I agree to the
                                                                    privacy policy</label>
                                                            </div>
                                                        </div>
                                                        <button class="btn btn-primary btn-block" type="submit">Sign up</button>
                                                        <div id="register_alert"></div>
                                                    </form>
                                                    <div class="form-choice text-center">
                                                        <label class="font-secondary">Sign in with social account</label>
                                                        <div class="social-links">
                                                            <a href="#" class="social-link social-facebook fab fa-facebook-f"></a>
                                                            <a href="#" class="social-link social-twitter fab fa-twitter"></a>
                                                            <a href="#" class="social-link social-google fab fa-google"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                        </aside>
                    </div>
               </div>  
           </div>
    </main>


 


<?php include('include/footer.php'); ?>