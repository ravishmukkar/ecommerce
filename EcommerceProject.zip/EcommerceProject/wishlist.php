<?php include('include/header.php'); ?>


		<main class="main">
			<div class="page-header bg-dark"
				style="background-image: url('images/shop/page-header-back.jpg'); background-color: #3C63A4;">
				<h1 class="page-title">Wishlist</h1>
				<ul class="breadcrumb">
					<li><a href="demo1.html"><i class="d-icon-home"></i></a></li>
					<li>Wishlist</li>
				</ul>
			</div>
			<!-- End PageHeader -->
			<div class="page-content pt-10 pb-10">
				<div class="container">
					<table class="shop-table wishlist-table mt-2 mb-4">
						<thead>
							<tr>
								<th class="product-name"><span>Product</span></th>
								<th>Product Name</th>
								<th>Add To Cart</th>
								<th class="product-price"><span>Price</span></th>
								<th class="product-stock-status"><span>Stock status</span></th>
								<th class="product-add-to-cart"></th>
								<th class="product-remove"></th>
							</tr>
						</thead>
						<tbody class="wishlist-items-wrapper" id="get_wish_list">

									
						</tbody>
					</table>
				</div>
			</div>
		</main>
	
	<?php include('include/footer.php'); ?>