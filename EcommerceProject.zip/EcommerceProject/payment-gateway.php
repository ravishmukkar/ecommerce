<?php

include('dbConnection/dbConnection.php');
$user_ip = getUserIp();

if(isset($_REQUEST['user_name'])){
    $sql = "SELECT * FROM addtocart WHERE user_ip = '{$user_ip}'";
    $resultitem = $conn->query($sql);
    if($resultitem->num_rows > 0){
    WHILE($row = $resultitem->fetch_assoc()){
    $product_id = $row['product_id'];
    $product_name = $row['product_name'];
    $product_quantity = $row['product_quantity'];
    $product_size = $row['product_size'];
    $product_price = $row['product_price'];
    $product_images = $row['product_images'];

    $user_name = $_REQUEST['user_name'];
    $user_email = $_REQUEST['user_email'];
    $first_name = $_REQUEST['first_name_checkout'];
    $last_name = $_REQUEST['last_name_checkout'];
    $company_name = $_REQUEST['company_name'];
    $country = $_REQUEST['country'];
    $address1 = $_REQUEST['address1'];
    $address2 = $_REQUEST['address2'];
    $city = $_REQUEST['city'];
    $district = $_REQUEST['district'];
    $state = $_REQUEST['state'];
    $postcode = $_REQUEST['postcode'];
    $phone = $_REQUEST['phone'];
    $email_address = $_REQUEST['email_address'];
    $other_notes = $_REQUEST['other_notes'];
    $today_date = date("Y.m.d"); 
    $delivery_status = "Processing";  
    }
  }
} 
?>


 <form action="success.php" method="POST"> 

<script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="rzp_test_OQQkLwI3k4em3k"
    data-amount="<?php  if(isset($product_price)){echo $product_price*100*72;} ?>"
    data-currency="INR"
    data-id="<?php echo 'OID'.rand(10,100).'END'; ?>"
    data-buttontext="Pay with Razorpay"
    data-name="Mukkar Technichol"
    data-description="This is the simple web dev project Developed By Ravish Mukkar"
    data-image="https://example.com/your_logo.jpg"
    data-prefill.name="Ravish"
    data-prefill.email="ravishmukkar98@gmail.com"
    data-theme.color="#F37254"
></script>
<input type="hidden" custom="Hidden Element" name="hidden">
<input type="hidden" name="user_name" value="<?php if(isset($user_name)){echo $user_name;} ?>">
<input type="hidden" name="user_email" value="<?php if(isset($user_email)){echo $user_email;} ?>">
<input type="hidden" name="first_name" value="<?php if(isset($first_name)){echo $first_name;} ?>">
<input type="hidden" name="last_name" value="<?php if(isset($last_name)){echo $last_name;} ?>">
<input type="hidden" name="company_name" value="<?php if(isset($company_name)){echo $company_name;} ?>">

<input type="hidden" name="country" value="<?php if(isset($country)){echo $country;} ?>">
<input type="hidden" name="address1" value="<?php if(isset($address1)){echo $address1;} ?>">
<input type="hidden" name="address2" value="<?php if(isset($address2)){echo $address2;} ?>">
<input type="hidden" name="city" value="<?php if(isset($city)){echo $city;} ?>">

<input type="hidden" name="district" value="<?php if(isset($district)){echo $district;} ?>">
<input type="hidden" name="state" value="<?php if(isset($state)){echo $state;} ?>">
<input type="hidden" name="postcode" value="<?php if(isset($postcode)){echo $postcode;} ?>">
<input type="hidden" name="phone" value="<?php if(isset($phone)){echo $phone;} ?>">

<input type="hidden" name="email_address" value="<?php if(isset($email_address)){echo $email_address;} ?>">
<input type="hidden" name="other_notes" value="<?php if(isset($other_notes)){echo $other_notes;} ?>">
<input type="hidden" name="today_date" value="<?php if(isset($today_date)){echo $today_date;} ?>">

<input type="hidden" name="delivery_status" value="<?php if(isset($delivery_status)){echo $delivery_status;} ?>">




</form>

<script> 


 
window.addEventListener('load',function(){
    var button = document.querySelector('.razorpay-payment-button');
    button.click();
})
</script>