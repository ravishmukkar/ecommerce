<?php include('dbConnection/dbConnection.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

	<title>Donald - Bootstrap eCommerce Template</title>

	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="Donald - Bootstrap eCommerce Template">
	<meta name="author" content="D-THEMES">

	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/icons/favicon.png">

	<script>
		WebFontConfig = {
			google: { families: ['Open+Sans:400,600,700', 'Poppins:400,500,600,700'] }
		};
		(function (d) {
			var wf = d.createElement('script'), s = d.scripts[0];
			wf.src = 'js/webfont.js';
			wf.async = true;
			s.parentNode.insertBefore(wf, s);
		})(document);
	</script>


	<link rel="stylesheet" type="text/css" href="vendor/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.min.css">

	<!-- Plugins CSS File -->
	<link rel="stylesheet" type="text/css" href="vendor/magnific-popup/magnific-popup.min.css">

	<!-- Main CSS File -->
	<link rel="stylesheet" type="text/css" href="css/style.min.css">
</head>

<body>
	<div class="loading-overlay">
		<div class="bounce-loader">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
			<div class="bounce4"></div>
		</div>
	</div>
	<div class="page-wrapper">
	<header class="header">				
		<!-- End HeaderTop -->
			<div class="header-middle sticky-header fix-top sticky-content">
				<div class="container">
					<div class="header-left">
						<a href="#" class="mobile-menu-toggle">
							<i class="d-icon-bars2"></i>
						</a>
					</div>
					<div class="header-center">
						<a href="demo1.html" class="logo">
							<img src="images/logo.png" alt="logo" width="163" height="39" />
						</a>
						<!-- End Logo -->
						<nav class="main-nav">
						  <ul class="menu">
                            <li class="active">
                                        <a href="demo3.html">Home</a>
                                    </li>
                                    <li>
                                        <a href="demo3-shop.html">Categories</a>
                                        <div class="megamenu">
                                            <div class="row">
                                                <div class="col-6 col-sm-4 col-md-4 col-lg-4">
                                                    <h4 class="menu-title">Variations 1</h4>
                                                    <ul>
                                                        <li><a href="product_shop.php?product_catogry=kids"><i class="d-icon-camera1"></i>kids</a></li>
                                                        <li><a href="product_shop.php?product_catogry=ladies"><i class="d-icon-camera1"></i>Ladies</a></li>
                                                        <li><a href="product_shop.php?product_catogry=gents"><i class="d-icon-camera1"></i>Gents</a></li>
                                                       
                                                    </ul>
                                                </div>
                                               
                                                <div
                                                    class="col-6 col-sm-4 col-md-4 col-lg-4 menu-banner menu-banner1 banner banner-fixed">
                                                    <figure>
                                                        <img src="images/menu/banner-1.jpg" alt="Menu banner"
                                                            width="221" height="330" />
                                                    </figure>
                                                    <div class="banner-content y-50">
                                                        <h4 class="banner-subtitle font-weight-bold text-primary ls-m">
                                                            Sale.
                                                        </h4>
                                                        <h3 class="banner-title font-weight-bold"><span
                                                                class="text-uppercase">Up to</span>70% Off</h3>
                                                        <a href="#" class="btn btn-link btn-underline">shop now<i
                                                                class="d-icon-arrow-right"></i></a>
                                                    </div>
                                                </div>
                                                <!-- End of Megamenu -->
                                            </div>
                                        </div>
									</li>
									<li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="about-us.html">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="#">Blog</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>
                            </ul>
						</nav>
						<span class="divider"></span>
						<!-- End Divider -->
						<div class="header-search hs-toggle">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End Header Search -->
					</div>
					<div class="header-right">
						<a class="login" href="ajax/login.html">
							<i class="d-icon-user"></i>
							<span>Login</span>
						</a>
						<!-- End Login -->
						<span class="divider"></span>
					
						<div class="dropdown cart-dropdown">
                            <a href="#" class="cart-toggle">
                                <span class="cart-label">
                                    <span class="cart-name">My Cart</span>
                                    <span class="cart-price total_amount"></span>
                                </span>
                                <i class="minicart-icon">
                                    <span class="cart-count count"></span>
                                </i>
                            </a>
                            <!-- End of Cart Toggle -->
                            <div class="dropdown-box">
                                <div class="product product-cart-header">
                                    <span class="product-cart-counts count"> items : </span>
                                    <span><a href="cart.php">View cart</a></span>
                                </div>
                                <div class="products scrollable" id="showcart">

                                   
                                    <!-- End of Cart Product -->
                                       
                                    <!-- End of Cart Product -->
                                </div>
                                <!-- End of Products  -->
                                <div class="cart-total">
                                    <label>Subtotal:</label>
                                    <span class="price total_amount"></span>
                                </div>
                                <!-- End of Cart Total -->
                                <div class="cart-action">
                                    <a href="checkout.html" class="btn btn-dark"><span>Checkout</span></a>
                                </div>
                      
                                <!-- End of Cart Action -->
                            </div>
                            <!-- End of Dropdown Box -->
                        </div>
						<div class="header-search hs-toggle mobile-search">
							<a href="#" class="search-toggle">
								<i class="d-icon-search"></i>
							</a>
							<form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
						</div>
						<!-- End of Header Search -->
					</div>
				</div>

			</div>
		</header>
		<!-- End Header -->
		<main class="main cart">
			<div class="page-content pt-10 pb-10">
				<div class="step-by pt-2 pb-2 pr-4 pl-4">
					<h3 class="title title-simple title-step active"><a href="cart.php">1. Shopping Cart</a></h3>
					<h3 class="title title-simple title-step"><a href="checkout.php">2. Checkout</a></h3>
					<h3 class="title title-simple title-step"><a href="order.php">3. Order Complete</a></h3>
				</div>
				<div class="container mt-8 mb-4">
					<div class="row gutter-lg">
						<div class="col-lg-8 col-md-12">
			
							<table class="shop-table cart-table mt-2">
								<thead>
									<tr>
										<th><span>Product</span></th>
										<th></th>
										<th><span>Price</span></th>
										<th><span>quantity</span></th>
										<th>Subtotal</th>
									</tr>
								</thead>
								<tbody id="get_show_cart">
								
								</tbody>
							</table>
							<div class="cart-actions mb-6 pt-6">
								
								<button type="submit" class="btn btn-md btn-icon-left"><i
										class="d-icon-refresh"></i>Update Cart</button>
							</div>

						</div>
					
						<aside class="col-lg-4 sticky-sidebar-wrapper">
							<div class="sticky-sidebar" data-sticky-options="{'bottom': 20}">
								<div class="summary mb-4">
									<h3 class="summary-title text-left">Cart Totals</h3>
									<table class="shipping">
										<tr class="summary-subtotal">
											<td>
												<h4 class="summary-subtitle">Subtotal</h4>
											</td>
											<td>
												<p class="summary-subtotal-price total_amount">$426.99</p>
											</td>												
										</tr>
										
									</table>
								<form action="checkout.php" methos="POST">	
									
									
									<a href="checkout.php" class="btn btn-dark btn-checkout">Proceed to checkout</a>
								</div>
                              </form>
							</div>
						</aside>
					</div>
				</div>
			</div>
		</main>
		
<?php include('include/footer.php'); ?>
