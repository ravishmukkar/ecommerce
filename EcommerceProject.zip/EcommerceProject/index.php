<?php include('include/header.php') ?>
        


<!-- this is ravish mkukkar gujjar -->
<!-- all code are mine --->

        <main class="main mt-lg-4">
            <div class="page-content">
                <div class="container">
                    <div class="row">
                        <aside class="col-xl-3 col-lg-4 sidebar sidebar-fixed sticky-sidebar-wrapper home-sidebar">
                            <div class="sidebar-overlay">
                                <a class="sidebar-close" href="#"><i class="d-icon-times"></i></a>
                            </div>
                            <a href="#" class="sidebar-toggle"><i class="fas fa-chevron-right"></i></a>
                            <div class="sidebar-content">
                                <div class="sticky-sidebar">
                                    <ul class="menu vertical-menu category-menu mb-4">
                                        <li><a href="product_shop.php" class="menu-title">Popular Categories</a></li>

                                        <?php
                                            $sql = "SELECT * FROM catogry_item";
                                            $result = $conn->query($sql);
                                            if($result->num_rows > 0){
                                                while ($row = $result->fetch_assoc()) {
                                                    # code...
                                                    if(!empty($row['catogry_item'])){
                                                        echo '<li><a href="product_shop.php?product_catogry='.$row['catogry_item'].'">'.$row['catogry_item'].'</a></li>';
                                                    }
                                                }
                                            }
                                        ?>
                                    </ul>
                                    <div class="banner banner-fixed overlay-zoom overlay-dark">
                                        <figure>
                                            <img src="images/demos/demo3/banner2.jpg" width="280" height="312"
                                                alt="banner" />
                                        </figure>
                                        <div class="banner-price-info font-weight-bold text-white text-uppercase">
                                            20-22<sup>th</sup> April</div>
                                        <div class="banner-content text-center w-100">
                                            <h4
                                                class="banner-subtitle d-inline-block bg-primary text-uppercase ls-normal">
                                                Ultimate Sale</h4>
                                            <h3 class="banner-title ls-l text-uppercase text-white font-weight-bold">Up
                                                to 70%</h3>
                                            <p class="mb-4 font-primary text-white lh-1">Discount Selected Items</p>
                                        </div>
                                    </div>
                                    <div class="widget widget-products" data-animation-options="{
                                        'delay': '.3s'
                                    }">
                                        <h4 class="widget-title">Our Featured</h4>
                                        <div class="widget-body">
                                            <div class="owl-carousel owl-nav-top" data-owl-options="{
                                                'items': 1,
                                                'loop': true,
                                                'nav': true,
                                                'dots': false,
                                                'margin': 20
                                            }">
                                                <div class="products-col">
                                                    <?php
                                                   $sql = "SELECT * FROM products WHERE catogry_section='featured' ORDER BY id DESC LIMIT 0,6";
                                                    $result = $conn->query($sql);
                                                    if($result->num_rows > 0){
                                                        WHILE($row = $result->fetch_assoc()){
                                                            $product_image = $row['product_images'];
                                                            $item_image_product = explode(',',$product_image);
                                                           echo ' <div class="product product-list-sm">
                                                           <figure class="product-media">
                                                               <a href="view-product.php?product_id='.$row['id'].'">
                                                                   <img src="Admin/ecommerce/images/'.$item_image_product[0].'"
                                                                       alt="product" width="100" height="100">
                                                               </a>
                                                           </figure>
                                                           <div class="product-details">
                                                               <h3 class="product-name">
                                                                   <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                                                               </h3>
                                                               <div class="product-price">
                                                                   <span class="price">$ :'.$row['product_price'].'</span>
                                                               </div>
                                                               <div class="ratings-container">
                                                                   <div class="ratings-full">
                                                                       <span class="ratings" style="width:'.$row['product_rating'].'%"></span>
                                                                       <span class="tooltiptext tooltip-top"></span>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                       </div>';
                                                       }
                                                   }
                                                    ?>
             
                                                </div>
                                                <div class="products-col">
                                                    <?php
                                                    $sql = "SELECT * FROM products WHERE catogry_section='featured' ORDER BY id DESC LIMIT 6,6";
                                                    $result = $conn->query($sql);
                                                    if($result->num_rows > 0){
                                                        WHILE($row = $result->fetch_assoc()){
                                                            $product_image = $row['product_images'];
                                                            $item_image_product = explode(',',$product_image);
                                                           echo ' <div class="product product-list-sm">
                                                           <figure class="product-media">
                                                               <a href="view-product.php?product_id='.$row['id'].'" >
                                                                   <img src="Admin/ecommerce/images/'.$item_image_product[0].'"
                                                                       alt="product" width="100" height="100">
                                                               </a>
                                                           </figure>
                                                           <div class="product-details">
                                                               <h3 class="product-name">
                                                                   <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                                                               </h3>
                                                               <div class="product-price">
                                                                   <span class="price">$ :'.$row['product_price'].'</span>
                                                               </div>
                                                               <div class="ratings-container">
                                                                   <div class="ratings-full">
                                                                       <span class="ratings" style="width:100%"></span>
                                                                       <span class="tooltiptext tooltip-top"></span>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                       </div>';
                                                        }
                                                    }
                                                    ?>
             
                                                </div>
                                             <div class="products-col">
                                                <?php
                                                    $sql = "SELECT * FROM products ORDER BY id DESC LIMIT 12,6";
                                                    $result = $conn->query($sql);
                                                    if($result->num_rows > 0){
                                                        WHILE($row = $result->fetch_assoc()){
                                                            $product_image = $row['product_images'];
                                                            $item_image_product = explode(',',$product_image);
                                                           echo ' <div class="product product-list-sm">
                                                           <figure class="product-media">
                                                               <a href="view-product.php?product_id='.$row['id'].'">
                                                                   <img src="images/demos/demo3/products/10.jpg"
                                                                       alt="product" width="100" height="100">
                                                               </a>
                                                           </figure>
                                                           <div class="product-details">
                                                               <h3 class="product-name">
                                                                   <a href="view-product.php?product_id='.$row['id'].'">Fashion Hiking Hat</a>
                                                               </h3>
                                                               <div class="product-price">
                                                                   <span class="price">$199.00</span>
                                                               </div>
                                                               <div class="ratings-container">
                                                                   <div class="ratings-full">
                                                                       <span class="ratings" style="width:100%"></span>
                                                                       <span class="tooltiptext tooltip-top"></span>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                       </div>';
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                                

                                    <div class="widget widget-testimonial" data-animation-options="{
                                        'delay': '.3s'
                                    }">
                                        <h4 class="widget-title">Testimonials</h4>
                                        <div class="widget-body">
                                            <div class="owl-carousel owl-nav-top" data-owl-options="{
                                                'items': 1,
                                                'loop': false,
                                                'nav': true,
                                                'dots': false,
                                                'margin': 20
                                            }">
                                                <div class="testimonial">
                                                    <blockquote class="comment">I am keeping my fingers on the pulse by MUKKAR every year! It gives me good sense of trend. My family likes it, too.</blockquote>
                                                    <div class="testimonial-info">
                                                        <figure class="testimonial-author-thumbnail">
                                                            <img src="images/demos/demo3/agent.png" alt="user"
                                                                width="40" height="40" />
                                                        </figure>
                                                        <cite>
                                                            Casper Dalin
                                                            <span>Investor</span>
                                                        </cite>
                                                    </div>
                                                </div>
                                                <div class="testimonial">
                                                    <blockquote class="comment">I am keeping my fingers on the pulse by MUKKAR every year! It gives me good sense of trend. My family likes it, too.</blockquote>
                                                    <div class="testimonial-info">
                                                        <figure class="testimonial-author-thumbnail">
                                                            <img src="images/demos/demo3/agent.png" alt="user"
                                                                width="40" height="40" />
                                                        </figure>
                                                        <cite>
                                                            Casper Dalin
                                                            <span>Investor</span>
                                                        </cite>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </aside>

                        <div class="col-xl-9 col-lg-8">
                            <section class="intro-section mb-3">
                                <div class="owl-carousel owl-theme row owl-dot-inner owl-dot-white intro-slider animation-slider cols-1 mb-4"
                                    data-owl-options="{
                                    'items': 1,
                                    'dots': true,
                                    'nav': false,
                                    'loop': true,
                                    'autoplay': false,
                                    'animateOut': 'fadeOutDown'
                                }">
                                    <div class="banner banner-fixed intro-slide1">
                                        <figure>
                                            <img src="images/demos/demo3/slides/1.jpg" alt="intro-banner" width="880"
                                                height="474" />
                                        </figure>
                                        <div class="banner-content y-50 slide-animate" data-animation-options="{
                                            'name': 'fadeIn',
                                            'delay': '.2s',
                                            'duration': '1s'
                                        }">
                                            <h4 class="banner-subtitle mb-2 text-white">New Collection</h4>
                                            <h2 class="banner-title mb-0 text-uppercase ls-l">Fashion Trends</h2>
                                            <p class="font-primary font-weight-semi-bold ls-l text-dark mb-3">Get Free
                                                Shipping on all orders over $75</p>
                                            <div
                                                class="banner-price-info d-flex align-items-center font-secondary font-weight-semi-bold text-uppercase text-white ml-3 mb-6">
                                                <sup class="d-inline-block font-weight-bold ls-l text-dark">up to</sup><span
                                                    class="text-primary font-weight-bold">$100</span>off</div>
                                            <a href="product_shop.php" class="btn btn-solid">Shop Now</a>
                                        </div>
                                    </div>
                                    <div class="banner banner-fixed intro-slide2">
                                        <figure>
                                            <img src="images/demos/demo3/slides/2.jpg" alt="intro-banner" width="880"
                                                height="474" />
                                        </figure>
                                        <div class="banner-content y-50 pb-10 text-right">
                                            <h4 class="banner-subtitle text-primary mb-3 slide-animate"
                                                data-animation-options="{
                                                'name': 'fadeightShorter',
                                                'duration': '1s'
                                            }">Up to 25% Off</h4>
                                            <h2 class="banner-title text-uppercase ls-l mb-0 slide-animate"
                                                data-animation-options="{
                                                'name': 'fadeightShorter',
                                                'delay': '.2s',
                                                'duration': '1s'
                                            }">For Women’s</h2>
                                            <p class="font-primary font-weight-semi-bold ls-l text-dark mb-6 slide-animate"
                                                data-animation-options="{
                                                'name': 'fadeightShorter',
                                                'delay': '.3s',
                                                'duration': '1s'
                                            }">Start at $12.00</p>
                                            <a href="product_shop.php" class="btn btn-outline btn-dark mb-2 slide-animate"
                                                data-animation-options="{
                                                'name': 'fadeightShorter',
                                                'delay': '.5s',
                                                'duration': '1s'
                                            }">Shop Now</a>
                                        </div>
                                    </div>
                                    <div class="banner banner-fixed intro-slide3">
                                        <figure>
                                            <img src="images/demos/demo3/slides/3.jpg" alt="intro-banner" width="880"
                                                height="474" />
                                        </figure>
                                        <div class="banner-content y-50 pb-3">
                                            <h4 class="banner-subtitle ls-l mb-0 slide-animate" data-animation-options="{
                                                'name': 'fadeInUpShorter',
                                                'delay': '.1s',
                                                'duration': '1s'
                                            }">For Women’s</h4>
                                            <h2 class="banner-title text-uppercase ls-m mb-1 slide-animate"
                                                data-animation-options="{
                                                'name': 'fadeInUpShorter',
                                                'delay': '.1s',
                                                'duration': '1s'
                                            }">New Shoes</h2>
                                            <p class="font-primary ls-m mb-5 text-dark text-uppercase slide-animate"
                                                data-animation-options="{
                                                'name': 'fadeInUpShorter',
                                                'delay': '.3s',
                                                'duration': '1s'
                                            }">From $19.00</p>
                                            <a href="product_shop.php" class="btn btn-dark slide-animate" data-animation-options="{
                                                'name': 'fadeInUpShorter',
                                                'delay': '.5s',
                                                'duration': '1s'
                                            }">Shop Now</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                             <div class="col-md-6 mb-4">
                                                   <div class="category category-absolute category-banner overlay-light">
                                                       <a href="product_shop.php?section_catogry='.$row['cloth_catogry_section'].'">
                                                           <figure class="category-media">
                                                               <img src="images/demos/demo3/banners/1.jpg" alt="category"
                                                                   width="430" height="189">
                                                           </figure>
                                                       </a>
                                                       <div class="category-content">
                                                           <h4 class="category-name">For Summer</h4>
                                                           <span class="category-count">
                                                               <span>6</span> Products
                                                           </span>
                                                           <a href="product_shop.php?section_catogry='summer'" class="btn btn-underline btn-link btn-sm">Shop Now<i
                                                                   class="d-icon-arrow-right"></i></a>
                                                       </div>
                                                   </div>
                                               </div>
                                               <div class="col-md-6 mb-4">
                                                   <div class="category category-absolute category-banner overlay-light">
                                                       <a href="product_shop.php?section_catogry='.$row['cloth_catogry_section'].'">
                                                           <figure class="category-media">
                                                               <img src="images/demos/demo3/banners/2.jpg" alt="category"
                                                                   width="430" height="189">
                                                           </figure>
                                                       </a>
                                                       <div class="category-content">
                                                           <h4 class="category-name">For Winter</h4>
                                                           <span class="category-count">
                                                               <span>6</span> Products
                                                           </span>
                                                           <a href="product_shop.php?section_catogry='winter'" class="btn btn-underline btn-link btn-sm">Shop Now<i
                                                                   class="d-icon-arrow-right"></i></a>
                                                       </div>
                                                   </div>
                                               </div>
                                    
                                  
                                </div>
                            </section>
                            <section class="product-wrapper mb-4">
                                <h2 class="title title-underline with-link appear-animate" data-animation-options="{
                                    'delay': '.3s'
                                }">New Arrivals<a href="product_shop.php">View more<i class="fas fa-chevron-right"></i></a></h2>
                                <div class="row gutter-xs appear-animate" data-animation-options="{
                                    'delay': '.3s'
                                }">


                               <?php
                                    $sql = "SELECT * FROM products ORDER BY id DESC LIMIT 0,28";
                                    $result = $conn->query($sql);
                                    if($result->num_rows > 0){
                                        WHILE($row = $result->fetch_assoc()){
                                            $product_image = $row['product_images'];
                                            $item_image_product = explode(',',$product_image);

                                            

                                            echo '<div class="col-md-3 col-6 mb-4">
                                            <div class="product text-center">
                                                <figure class="product-media">
                                                    <a href="view-product.php?product_id='.$row['id'].'">
                                                        <img src="Admin/ecommerce/images/'.$item_image_product[0].'" alt="product"
                                                            width="280" height="315" style="height:245px;">
                                                    </a>
                                                    <div class="product-label-group">
                                                        <label class="product-label label-sale">'.$row['product_discount'].'% off</label>
                                                    </div>
                                                    <div class="product-action-vertical">
                                                    
                                                        <a href="" onclick="addToCart('.$row['id'].')" class="btn-product-icon btn-cart" data-toggle="modal"
                                                            data-target="#addCartModal" title="Add to cart"><i
                                                                class="d-icon-bag"></i></a>
                                                        <a href="#" onclick="add_wish_cart('.$row['id'].')" class="btn-product-icon btn-wishlist"
                                                            title="Add to wishlist"><i class="d-icon-heart"></i></a>
                                                    </div>
                                                    <div class="product-action">
                                                        <a href="#"  class="btn-product btn-quickview"
                                                            title="Quick View">Quick View</a>
                                                    </div>
                                                </figure>
                                                <div class="product-details">
                                                     <div class="product-cat">
                                                        <a href="view-product.php?product_id='.$row['id'].'">categories</a>
                                                    </div>
                                                    <h3 class="product-name">
                                                        <a href="view-product.php?product_id='.$row['id'].'">'.$row['product_name'].'</a>
                                                    </h3>
                                                    <div class="product-price">
                                                        <ins class="new-price">$'.$row['product_price'].'</ins><del
                                                            class="old-price"></del>
                                                    </div>
                                                    <div class="ratings-container">
                                                        <div class="ratings-full">
                                                            <span class="ratings" style="width:'.$row['product_rating'].'%"></span>
                                                            <span class="tooltiptext tooltip-top"></span>
                                                        </div>
                                                        <a href=""view-product.php?product_id='.$row['id'].'"" class="rating-reviews">( '.$row['total_cmts'].' )</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>';
                                        }
                                    }
                                 ?>

                                </div>
                            </section>

                            <section class="banner banner-cta mb-7 text-center"
                                style="background-image: url(images/demos/demo3/banner.jpg)">
                                <div class="banner-content appear-animate" data-animation-options="{
                                    'delay': '.2s',
                                    'name': 'blurIn'
                                }">
                                    <h4 class="banner-subtitle font-weight-bold ls-s text-white text-uppercase">Coming
                                        soon</h4>
                                    <h2 class="banner-title font-weight-normal ls-m mb-2"><strong>Black Friday</strong>
                                        Sale</h2>
                                    <p class="font-primary text-dark">Get 10% off first order</p>
                                    <form action="#" method="get" class="input-wrapper input-wrapper-inline">
                                        <input type="email" class="form-control mb-4" name="email" id="email"
                                            placeholder="Email address here..." required />
                                        <button class="btn btn-dark btn-sm" type="submit">Subscribe</button>
                                    </form>
                                </div>
                            </section>

                            <section class="mb-10">
                                <div class="row">
                                    <div class="col-md-4 mb-4">
                                        <div class="widget widget-products appear-animate" data-animation-options="{
                                            'name': 'fadeInLeftShorter',
                                            'delay': '.5s'
                                        }">
                                            <h4 class="widget-title">Latest</h4>

                                            <div class="products-col" id="Latest">
                                               
                                             
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-4">
                                        <div class="widget widget-products appear-animate" data-animation-options="{
                                            'name': 'fadeIn',
                                            'delay': '.3s'
                                        }">
                                            <h4 class="widget-title">Featured</h4>
                                            <div class="products-col" id="Featured">
                                            
                                            </div>
                                        </div>
                                    </div>
                                 
                                    <div class="col-md-4 mb-4">
                                        <div class="widget widget-products appear-animate" data-animation-options="{
                                            'name': 'fadeightShorter',
                                            'delay': '.5s'
                                        }">
                                            <h4 class="widget-title">Top rated</h4>
                                            <div class="products-col" id="top_rated">
                                                
                                               
                                            </div>
                                        
                                         </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </main>


       <?php include('include/footer.php'); ?>