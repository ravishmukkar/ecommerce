<?php include('dbConnection/dbConnection.php') ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>MUKKAR</title>

    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="MUKKAR">
    <meta name="author" content="D-THEMES">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="images/icons/favicon.png">

    <script>
        WebFontConfig = {
            google: { families: ['Open+Sans:400,600,700', 'Poppins:400,600,700'] }
        };
        (function (d) {
            var wf = d.createElement('script'), s = d.scripts[0];
            wf.src = 'js/webfont.js';
            wf.async = true;
            s.parentNode.insertBefore(wf, s);
        })(document);
    </script>


    <link rel="stylesheet" type="text/css" href="vendor/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.min.css">

    <!-- Plugins CSS File -->
    <link rel="stylesheet" type="text/css" href="vendor/magnific-popup/magnific-popup.min.css">
    <link rel="stylesheet" type="text/css" href="vendor/owl-carousel/owl.carousel.min.css">

    <!-- Main CSS File -->
    <link rel="stylesheet" type="text/css" href="css/demo3.min.css">
    <link rel="stylesheet" type="text/css" href="css/pagination.css">
</head>

<body class="home">
    <div class="loading-overlay">
        <div class="bounce-loader">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
            <div class="bounce4"></div>
        </div>
    </div>
    <div class="page-wrapper">
       
        <header class="header">
            
            <!-- End of HeaderTop -->
            <div class="header-middle sticky-header fix-top sticky-content has-center">
                <div class="container">
                    <div class="header-left">
                        <a href="#" class="mobile-menu-toggle">
                            <i class="d-icon-bars2"></i>
                        </a>
                        <a href="demo3.html" class="logo d-none d-lg-block">
                            <!-- <img src="images/ravi.jpg" alt="logo" width="163" height="39" /> -->
                            <h2 class="font-weight-bold text-light">MUKKAR</h2>
                        </a>
                    </div>
                    <div class="header-center">
                        <a href="demo3.html" class="logo d-lg-none">
                            <img src="images/demos/demo3/logo.png" alt="logo" width="163" height="39" />
                        </a>
                        <!-- End of Logo -->
                        <div class="header-search hs-expanded">
                            <form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
                        </div>
                        <!-- End of Header Search -->

                        <nav class="main-nav">
                      

                        <ul class="menu">
                                    <!-- <li class="active">
                                        <a href="index.php">Home</a>
                                    </li> -->
                                    <li>
                                        <a href="index.php">Home</a>
                                    </li>
                                    
                                    <li>
                                    <a href="product.html">Products</a>
                                    <div class="megamenu">
                                        <div class="row">

                                        <?php
                                        
                                        $sql = "SELECT * FROM catogry_page";
                                        $result = $conn->query($sql);
                                        if($result->num_rows > 0){
                                            while($row = $result->fetch_assoc()){
                                                echo '<div class="col-4 col-sm-4 col-md-3 col-lg-4">
                                                       <h4 class="menu-title">'.$row['catogry_page'].'</h4>
                                                      <ul>
                                                ';
                                                ?>
                                           <?php 
                                           
                                             $sqli = "SELECT * FROM catogry_item WHERE catogry_page = '{$row['catogry_page']}'";
                                             $resulti = $conn->query($sqli);
                                             if($resulti->num_rows > 0){
                                                 while($rowi = $resulti->fetch_assoc()){
                                                  
                                                   echo '<li><a href="product_shop.php?product_catogry='.$rowi['catogry_item'].'">'.$rowi['catogry_item'].'</a></li>';
                                                 }
                                             } 
                                           
                                           ?>
                                        <?php

                                                echo '</ul></div>';
                                            }
                                        }
                                        
                                        ?>
                                            <!-- <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Pages</h4>
                                                <ul>
                                                    <li><a href="product-simple.html">Simple Product</a></li>
                                                    <li><a href="product.html">Variable Product</a></li>
                                                    <li><a href="product-sale.html">Sale Product</a></li>
                                                    <li><a href="product-featured.html">Featured &amp; On Sale</a></li>

                                                    <li><a href="product-left-sidebar.html">With Left Sidebar</a></li>
                                                    <li><a href="product-right-sidebar.html">With Right Sidebar</a></li>
                                                    <li><a href="product-sticky-cart.html">Add Cart Sticky<span
                                                                class="tip tip-hot">Hot</span></a></li>
                                                    <li><a href="product-tabinside.html">Tab Inside</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Layouts</h4>
                                                <ul>
                                                    <li><a href="product-grid.html">Grid Images<span
                                                                class="tip tip-new">New</span></a></li>
                                                    <li><a href="product-masonry.html">Masonry</a></li>
                                                    <li><a href="product-gallery.html">Gallery Type</a></li>
                                                    <li><a href="product-full.html">Full Width Layout</a></li>
                                                    <li><a href="product-sticky.html">Sticky Info</a></li>
                                                    <li><a href="product-sticky-both.html">Left &amp; Right Sticky</a>
                                                    </li>
                                                    <li><a href="product-horizontal.html">Horizontal Thumb</a></li>

                                                    <li><a href="#">Build Your Own</a></li>
                                                </ul>
                                            </div> -->
                                          
                                            <!-- End MegaMenu -->
                                        </div>
                                    </div>
                                </li>

                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <li>
                                        <a href="about-us.php">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                   
                                    <li>
                                        <a href="wishlist.php">Wish Cart</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>
                                </ul>
                        </nav>
                    </div>
                    <div class="header-right">
                        <a href="login-register.php" class="m-2 p-3">
                            <i class="d-icon-user"></i>
                            <span>Login</span>
                        </a>
                        <!-- End of Login -->
                        <span class="divider"></span>
                        <div class="dropdown cart-dropdown">
                            <a href="#" class="cart-toggle">
                                <span class="cart-label">
                                    <span class="cart-name">My Cart S</span>
                                    <span class="cart-price total_amount"></span>
                                </span>
                                <i class="minicart-icon">
                                    <span class="cart-count count"></span>
                                </i>
                            </a>
                            <!-- End of Cart Toggle -->
                            <div class="dropdown-box">
                                <div class="product product-cart-header">
                                    <span class="product-cart-counts "> items : <strong class="count"></strong> </span>
                                    <span><a href="cart.php">View cart</a></span>
                                </div>
                                <div class="products scrollable" id="showcart">

                                   
                                    <!-- End of Cart Product -->
                                       
                                    <!-- End of Cart Product -->
                                </div>
                                <!-- End of Products  -->
                                <div class="cart-total">
                                    <label>Subtotal:</label>
                                    <span class="price total_amount"></span>
                                </div>
                                <!-- End of Cart Total -->
                                <div class="cart-action">
                                    <a href="checkout.php" class="btn btn-dark"><span>Checkout</span></a>
                                </div>
                      
                                <!-- End of Cart Action -->
                            </div>
                            <!-- End of Dropdown Box -->
                        </div>

                        <div class="header-search hs-toggle mobile-search">
                            <a href="#" class="search-toggle">
                                <i class="d-icon-search"></i>
                            </a>
                            <form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
                        </div>
                        <!-- End of Header Search -->
                    </div>
                </div>
            </div>

            <div class="header-bottom d-lg-show">
                <div class="container">
                    <div class="inner-wrap">
                        <div class="header-left">
                            <nav class="main-nav">
                            <ul class="menu">
                                    <!-- <li class="active">
                                        <a href="index.php">Home</a>
                                    </li> -->
                                    <li>
                                        <a href="index.php">Home</a>
                                    </li>
                                    
                                    <li>
                                    <a href="product.html">Products</a>
                                    <div class="megamenu">
                                        <div class="row">

                                        <?php
                                        
                                        $sql = "SELECT * FROM catogry_page";
                                        $result = $conn->query($sql);
                                        if($result->num_rows > 0){
                                            while($row = $result->fetch_assoc()){
                                                echo '<div class="col-4 col-sm-4 col-md-3 col-lg-4">
                                                       <h4 class="menu-title">'.$row['catogry_page'].'</h4>
                                                      <ul>
                                                ';
                                                ?>
                                           <?php 
                                           
                                             $sqli = "SELECT * FROM catogry_item WHERE catogry_page = '{$row['catogry_page']}'";
                                             $resulti = $conn->query($sqli);
                                             if($resulti->num_rows > 0){
                                                 while($rowi = $resulti->fetch_assoc()){
                                                  
                                                   echo '<li><a href="product_shop.php?product_catogry='.$rowi['catogry_item'].'">'.$rowi['catogry_item'].'</a></li>';
                                                 }
                                             } 
                                           
                                           ?>
                                        <?php

                                                echo '</ul></div>';
                                            }
                                        }
                                        
                                        ?>
                                            <!-- <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Pages</h4>
                                                <ul>
                                                    <li><a href="product-simple.html">Simple Product</a></li>
                                                    <li><a href="product.html">Variable Product</a></li>
                                                    <li><a href="product-sale.html">Sale Product</a></li>
                                                    <li><a href="product-featured.html">Featured &amp; On Sale</a></li>

                                                    <li><a href="product-left-sidebar.html">With Left Sidebar</a></li>
                                                    <li><a href="product-right-sidebar.html">With Right Sidebar</a></li>
                                                    <li><a href="product-sticky-cart.html">Add Cart Sticky<span
                                                                class="tip tip-hot">Hot</span></a></li>
                                                    <li><a href="product-tabinside.html">Tab Inside</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                                <h4 class="menu-title">Product Layouts</h4>
                                                <ul>
                                                    <li><a href="product-grid.html">Grid Images<span
                                                                class="tip tip-new">New</span></a></li>
                                                    <li><a href="product-masonry.html">Masonry</a></li>
                                                    <li><a href="product-gallery.html">Gallery Type</a></li>
                                                    <li><a href="product-full.html">Full Width Layout</a></li>
                                                    <li><a href="product-sticky.html">Sticky Info</a></li>
                                                    <li><a href="product-sticky-both.html">Left &amp; Right Sticky</a>
                                                    </li>
                                                    <li><a href="product-horizontal.html">Horizontal Thumb</a></li>

                                                    <li><a href="#">Build Your Own</a></li>
                                                </ul>
                                            </div> -->
                                          
                                            <!-- End MegaMenu -->
                                        </div>
                                    </div>
                                </li>

                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <li>
                                        <a href="about-us.php">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                   
                                    <li>
                                        <a href="wishlist.php">Wish Cart</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="header-right">
                            <nav class="custom-menu">
                                <!-- <ul class="menu">
                                    <li>
                                        <a href="#">Limited time offer</a>
                                    </li>
                                    <li>
                                        <a href="#">Buy Donald!</a>
                                    </li>
                                </ul> -->
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- End of Header -->