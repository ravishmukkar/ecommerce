 
        <!-- End of Main -->
        <footer class="footer appear-animate" data-animation-options="{
            'delay': '.3s'
        }">
            <div class="container">
                <div class="footer-top">
                    <div class="row">
                        <div class="col-lg-3">
                            <a href="demo3.html" class="logo-footer">
                                <!-- <img src="images/logo-footer.png" alt="logo-footer" width="163" height="39" /> -->
                            <h2 class="font-weight-bold text-light">MUKKAR</h2>

                            </a>
                            <!-- End of FooterLogo -->
                        </div>
                        <div class="col-lg-9">
                            <div class="widget widget-newsletter form-wrapper form-wrapper-inline">
                                <div class="newsletter-info mx-auto mr-lg-2 ml-lg-4">
                                    <h4 class="widget-title">Subscribe to our Newsletter</h4>
                                    <p>Get all the latest information on Events, Sales and Offers.</p>
                                </div>
                                <form action="#" class="input-wrapper input-wrapper-inline">
                                    <input type="email" class="form-control" name="newsletter_email"
                                        id="newsletter_email" placeholder="Email address here..." required />
                                    <button class="btn btn-grey btn-md ml-2" type="submit">subscribe<i
                                            class="d-icon-arrow-right"></i></button>
                                </form>
                            </div>
                            <!-- End of Newsletter -->
                        </div>
                    </div>
                </div>
                <!-- End of FooterTop -->
                <div class="footer-middle">
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="widget">
                                <h4 class="widget-title">Contact Info</h4>
                                <ul class="widget-body">
                                    <li>
                                        <label>Phone:</label>
                                        <a href="#">7878642508</a>
                                    </li>
                                    <li>
                                        <label>Email:</label>
                                        <a href="#">ravishmukkar98@gmail.com</a>
                                    </li>
                                    <li>
                                        <label>Address:</label>
                                        <a href="#">Kotputli, Jaipur</a>
                                    </li>
                                    <li>
                                        <label>WORKING DAYS/HOURS</label>
                                    </li>
                                    <li>
                                        <a href="#">Mon - Sun / 9:00 AM - 8:00 PM</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- End of Widget -->
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="widget ml-lg-4">
                                <h4 class="widget-title">My Account</h4>
                                <ul class="widget-body">
                                    <li>
                                        <a href="about-us.php">About Us</a>
                                    </li>
                                    <li>
                                        <a href="product_shop.php">Product</a>
                                    </li>
                                  
                                    <li>
                                        <a href="login-register.php">Login & Register</a>
                                    </li>
                                    <li>
                                        <a href="#">Contact Us</a>
                                    </li>
                                    <li>
                                        <a href="Admin/ecommerce/admin_login.php">Admin Login</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- End of Widget -->
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="widget ml-lg-4">
                                <h4 class="widget-title">Contact Info</h4>
                                <ul class="widget-body">
                                    <li>
                                        <a href="#">About Us</a>
                                    </li>
                                    <li>
                                        <a href="#">Order History</a>
                                    </li>
                                    <li>
                                        <a href="#">Returns</a>
                                    </li>
                                    <li>
                                        <a href="#">Custom Service</a>
                                    </li>
                                    <li>
                                        <a href="#">Terms &amp; Condition</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- End of Widget -->
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="widget widget-instagram">
                                <h4 class="widget-title">Instagram</h4>
                                <figure class="widget-body row">
                                    <div class="col-3">
                                        <img src="images/instagram/01.jpg" alt="instagram 1" width="64" height="64" />
                                    </div>
                                    <div class="col-3">
                                        <img src="images/instagram/02.jpg" alt="instagram 2" width="64" height="64" />
                                    </div>
                                    <div class="col-3">
                                        <img src="images/instagram/03.jpg" alt="instagram 3" width="64" height="64" />
                                    </div>
                                    <div class="col-3">
                                        <img src="images/instagram/04.jpg" alt="instagram 4" width="64" height="64" />
                                    </div>
                                    <div class="col-3">
                                        <img src="images/instagram/05.jpg" alt="instagram 5" width="64" height="64" />
                                    </div>
                                    <div class="col-3">
                                        <img src="images/instagram/06.jpg" alt="instagram 6" width="64" height="64" />
                                    </div>
                                    <div class="col-3">
                                        <img src="images/instagram/07.jpg" alt="instagram 7" width="64" height="64" />
                                    </div>
                                    <div class="col-3">
                                        <img src="images/instagram/08.jpg" alt="instagram 8" width="64" height="64" />
                                    </div>
                                </figure>
                            </div>
                            <!-- End of Instagram -->
                        </div>
                    </div>
                </div>
                <!-- End of FooterMiddle -->
                <div class="footer-bottom">
                    <div class="footer-left">
                        <figure class="payment">
                            <img src="images/payment.png" alt="payment" width="159" height="29" />
                        </figure>
                    </div>
                    <div class="footer-center">
                        <p class="copyright">Ravish Mukkar Developed &copy; 2021. All Rights Reserved</p>
                    </div>
                    <div class="footer-right">
                        <div class="social-links">
                            <a href="#" class="social-link social-facebook fab fa-facebook-f"></a>
                            <a href="#" class="social-link social-twitter fab fa-twitter"></a>
                            <a href="#" class="social-link social-linkedin fab fa-linkedin-in"></a>
                        </div>
                    </div>
                </div>
                <!-- End of FooterBottom -->
            </div>
        </footer>
        <!-- End of Footer -->
    </div>
    <!-- Sticky Footer -->
    <div class="sticky-footer sticky-content fix-bottom">
        <a href="index.php" class="sticky-link active">
            <i class="d-icon-home"></i>
            <span>Home</span>
        </a>
        <a href="demo3-shop.html" class="sticky-link">
            <i class="d-icon-volume"></i>
            <span>Categories</span>
        </a>
        <a href="wishlist.php" class="sticky-link">
            <i class="d-icon-heart"></i>
            <span>Wishlist</span>
        </a>
        <a href="account.php" class="sticky-link">
            <i class="d-icon-user"></i>
            <span>Account</span>
        </a>
        <div class="dropdown cart-dropdown dir-up">
            <a href="cart.php" class="sticky-link cart-toggle">
                <i class="d-icon-bag"></i>
                <span>Cart</span>
            </a>
            <!-- End of Cart Toggle -->
            <div class="dropdown-box">
                <div class="product product-cart-header">
                    <span class="product-cart-counts">2 items</span>
                    <span><a href="cart.php">View cart</a></span>
                </div>
                <div class="products scrollable" id="showcart">



                
                    <!-- End of Cart Product -->
                </div>
                <!-- End of Products  -->
                <div class="cart-total">
                    <label>Subtotal:</label>
                    <span class="price">$42.00</span>
                </div>
                <!-- End of Cart Total -->
                <div class="cart-action">
                    <a href="checkout.html" class="btn btn-dark"><span>Checkout</span></a>
                </div>
                <!-- End of Cart Action -->
            </div>
            <!-- End of Dropdown Box -->
        </div>
    </div>
    <!-- Scroll Top -->
    <a id="scroll-top" href="#top" title="Top" role="button" class="scroll-top"><i class="fas fa-chevron-up"></i></a>

    <!-- MobileMenu -->
    <div class="mobile-menu-wrapper">
        <div class="mobile-menu-overlay">
        </div>
        <!-- End of Overlay -->
        <a class="mobile-menu-close" href="#"><i class="d-icon-times"></i></a>
        <!-- End of CloseButton -->
        <div class="mobile-menu-container scrollable">
                         <form action="product_shop.php" method="get" class="input-wrapper">
                                <input type="text" class="form-control" name="search" id="search"
                                    placeholder="Search your keyword..." required="">
                                <button class="btn btn-sm btn-search" type="submit"><i
                                        class="d-icon-search"></i></button>
                            </form>
            <!-- End of Search Form -->
            <ul class="mobile-menu mmenu-anim">
            <li class="active">
                                        <a href="index.php">Home</a>
                                    </li>
                                   
                                        <li>
                                            <a href="#">Product Pages</a>
                                            <ul>
                                                    <?php
                                                        // $sql = "SELECT * FROM cloth_catogry";
                                                        // $result = $conn->query($sql);
                                                        // if($result->num_rows > 0){
                                                        //     while ($row = $result->fetch_assoc()) {
                                                        //         # code...
                                                        //         if(!empty($row['cloth_catogry'])){
                                                        //             echo ' <li><a href="product_shop.php?product_catogry='.$row['cloth_catogry'].'"><i class="d-icon-camera1"></i>'.$row['cloth_catogry'].'</a></li>';
                                                        //         }
                                                        //     }
                                                        // }

                                                        $sql = "SELECT * FROM catogry_page";
                                                        $result = $conn->query($sql);
                                                        if($result->num_rows > 0){
                                                            while($row = $result->fetch_assoc()){
                                                                echo '<div class="text-light">
                                                                       <h4 class="menu-title">'.$row['catogry_page'].'</h4>
                                                                      <ul>
                                                                ';
                                                                ?>
                                                           <?php 
                                                           
                                                             $sqli = "SELECT * FROM catogry_item WHERE catogry_page = '{$row['catogry_page']}'";
                                                             $resulti = $conn->query($sqli);
                                                             if($resulti->num_rows > 0){
                                                                 while($rowi = $resulti->fetch_assoc()){
                                                                  
                                                                   echo '<li><a href="product_shop.php?product_catogry='.$rowi['catogry_item'].'"><i class="d-icon-camera1"></i>'.$rowi['catogry_item'].'</a></li>';
                                                                   
                                                                 }
                                                             } 
                                                           
                                                           ?>
                                                        <?php
                
                                                                echo '</ul></div>';
                                                            }
                                                        }
                                                    ?>
                                            </ul>
                                         </li>
                                   
                                    <li>
                                        
                                    </li>     
                                    <!-- End of Dropdown -->
                                    <li>
                                        <a href="product_shop.php">Shop</a>
                                    </li>
                                    <li>
                                        <a href="about-us.php">About Us</a>
                                    </li>
                                    <!-- End of Dropdown -->
                                  
                                    <!-- End of Dropdown -->
                                  
                                    <li>
                                        <a href="wishlist.php">Wish Cart</a>
                                        
                                    </li>
                                    <!-- End of Dropdown -->
                                   
                                    <!-- End of Dropdown -->
                                    <li>
                                    <a href="account.php">My Account</a>
                                    </li>
                                    <li>
                                    <a href="login-register.php">Login</a>
                                    </li>

                
                      
            </ul>
            <!-- End of MobileMenu -->
        </div>
    </div>





<!------================ PopUp ================ ---->



<script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="vendor/elevatezoom/jquery.elevatezoom.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <script src="vendor/owl-carousel/owl.carousel.min.js"></script>
    <script src="vendor/sticky/sticky.min.js"></script>
    <!-- Main JS File -->
    
	<script src="vendor/nouislider/nouislider.min.js"></script>

    <script src="js/main.js"></script>
    <script src="ajax/ajax.js"></script>
</body>
</html>